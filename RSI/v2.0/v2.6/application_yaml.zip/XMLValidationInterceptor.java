package $$PACKAGE_NAME$$;

import com.chase.si.controller.api.RSISession;
import com.chase.si.datahelpers.managers.ResponseContextManager;
import com.chase.si.model.repository.RSIRequest;
import com.chase.si.model.repository.ResponseContext;
import com.chase.si.util.model.FastModelFormatter;
import com.chase.config.util.MappingHelper;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.binding.Unmarshaller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import java.io.BufferedReader;
import java.io.StringReader;
import java.util.List;
import java.util.ArrayList;
$$IMPORTSTMT$$

@Component
public class XMLValidationInterceptor implements HandlerInterceptor {
	
	@Autowired
	private MappingHelper mappingHelper;
	
$$AUTOWIRED$$

    // Request is intercepted by this method before reaching the Controller
    @Override
    public boolean preHandle(final HttpServletRequest request,final HttpServletResponse response,final Object handler)
            	throws Exception {

        //* Business logic just when the request is received and intercepted by this interceptor before reaching the controller
        try {
			if("POST".equalsIgnoreCase(request.getMethod())&&request.getContentType()!=null&&request.getContentType().contains("application/xml")){
				StringBuilder xmlContent = new StringBuilder();
				try(BufferedReader reader=request.getReader()){
					String line=null;
					while((line=reader.readLine())!=null){
						xmlContent.append(line);
					}
				}
                FastModelFormatter fastModelFormatter = new FastModelFormatter();				
				RSIRequest rsiRequest = parseXmlToInputObject(xmlContent.toString());
				List<String> errors = new ArrayList<>();
				RSISession rsiSession = mappingHelper().getRsiSession(rsiRequest,errors);
				mappingHelper.mapRequestContext(rsiRequest.getRequestContext(),rsiSession);
				$$SERVICE_VALIDATE$$.validate(rsiSession);
				//check context errors before before process the request
				if(rsiSession.containsContextErrors()){
					//map session to request context
					ResponseContext responseContext = (ResponseContext) formatter.format(rsiSession,
					          ResponseContextManager.getContextMappingTree(),ResponseContext.class);
					//throw exception based on context errors
					mappingHelper.checkErrorMessage(responseContext);
				}
				if(errors.isEmpty())
					request.setAttribute("rsiSession",rsiSession);
			}			
		}
        //* If the Exception is caught, this method will return false
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
	
	private RSIRequest parseXmlToInputObject(String xmlContent) throws JAXBException{
		JAXBContext context = JAXBContext.newInstance(RSIRequest.class);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		return (RSIRequest) unmarshaller.unmarshal(new StringReader(xmlContent));
	}

    // Response is intercepted by this method before reaching the client
    @Override
    public void postHandle(final HttpServletRequest request,final HttpServletResponse response,
            	Object handler, ModelAndView modelAndView) throws Exception {        	
            HandlerInterceptor.super.postHandle(request,response,handler,modelAndView);        
    }

    // This method is called after request & response HTTP communication is done.
    @Override
    public void afterCompletion(final HttpServletRequest request,final HttpServletResponse response,
	          final Object handler,final Exception ex) throws Exception {
           HandlerInterceptor.super.afterCompletion(request,response,handler,ex);        
    }
}
