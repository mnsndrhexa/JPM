package $$PACKAGE_NAME$$;
import org.springframework.stereotype.Component;

@Component
public class MappingHelper {
	
$$SETSESSION$$	
	
	private void addToErrorList(String errorMsg,List<String> errors){
		if(errorMsg!=null&& !errors.isEmpty())
			errors.add(errorMsg);
	}
	
	public void mapRequestContext(RequestContext context,RSISession session){
	}
	
	public void checkErrorMessage(ResponseContext context,RSISession session) throws Exception{
	}

}
