package com.hex.jpmc.poc.denormalize.latest;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

public class JavaClassRefactor {

    private static final Logger logger = LogManager.getLogger(JavaClassRefactor.class);
    private static Set<String> childMethodsWithSuperSet = new HashSet<>();
    private static Map<String, Set<MethodLevelDetails>> superMethodDetails = new HashMap<>();
    private static Set<String> classesSet = new HashSet<>();

    public static void main(String[] args) throws IOException {
        // Path to the current file to process
        String currentFilePath = "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java";
        List<Path> pathList;
        try (Stream<Path> stream = Files.walk(Paths.get("C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample"))) {
            pathList = stream.map(Path::normalize).filter(Files::isRegularFile).collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        denormalizeClass(pathList, currentFilePath);
    }

    public static void denormalizeClass(List<Path> pathList, String currentFilePath) throws IOException {
        childMethodsWithSuperSet = new HashSet<>();
        List<String> parentClassesList = new ArrayList<>();
        // Parse the current class
        CompilationUnit currentCU = parseJavaFile(currentFilePath);
        TypeDeclaration currentClass = (TypeDeclaration) currentCU.types().get(0);
        int order = 1;

        // Traverse the inheritance chain
        List<ASTClassInfo> classHierarchy = new ArrayList<>();
        ASTClassInfo currentClassInfo = new ASTClassInfo(currentFilePath, currentCU, currentClass);
        Set<String> superMethodNameSet = new HashSet<>();
        File file = new File(currentFilePath);
        String className = file.getName().replace(".java", "");
        classesSet.add(className);

        superMethodDetails.put(currentFilePath, new HashSet<>());
        // Child field names for identifying duplicates when copying from parent
        Set<String> childFieldNames = new HashSet<>();
        for (BodyDeclaration body : (List<BodyDeclaration>) currentClassInfo.getClassType().bodyDeclarations()) {
            if (body instanceof FieldDeclaration) {
                FieldDeclaration field = (FieldDeclaration) body;
                for (Object fragment : field.fragments()) {
                    if (fragment instanceof VariableDeclarationFragment) {
                        VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                        childFieldNames.add(varFragment.getName().getIdentifier());
                    }
                }
            }
        }
        // Collect the methods which has super calls from the child class
        for (MethodDeclaration method : currentClass.getMethods()) {
            if (JavaClassRefactorASTUtil.containsSuperCall(method)) {
                childMethodsWithSuperSet.add(method.getName().getFullyQualifiedName());
                MethodLevelDetails methodLevelDetails = new MethodLevelDetails();
                methodLevelDetails.setSuperMethodName(method.getName().getFullyQualifiedName());
                methodLevelDetails.setSuperMethodAvailable(true);
                superMethodDetails.get(currentFilePath).add(methodLevelDetails);
                currentClassInfo.getSuperMethods().add(method);
            }
        }
        currentClassInfo.setSuperMethodDetails(superMethodDetails.get(currentFilePath));
        currentClassInfo.setOrder(order);
        classHierarchy.add(currentClassInfo);
        if (!childMethodsWithSuperSet.isEmpty()) {
            String parentClassNameStr = getParentClassName(currentClass);

            while (parentClassNameStr != null) {
                String parentFilePath = findClassFile(pathList, parentClassNameStr);
                if (parentFilePath == null) {
                    logger.debug("Parent class file not found: " + parentClassNameStr);
                    break;
                }
                parentClassesList.add(parentFilePath);
                CompilationUnit parentCU = parseJavaFile(parentFilePath);
                TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
                parentClassNameStr = getParentClassName(parentClass);
            }
            // Dynamically find and process all parent classes
            String parentClassName = getParentClassName(currentClass);
            while (parentClassName != null) {
                String parentFilePath = findClassFile(pathList, parentClassName);
                if (parentFilePath == null) {
                    logger.debug("Parent class file not found: " + parentClassName);
                    break;
                }

                CompilationUnit parentCU = parseJavaFile(parentFilePath);
                TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
                ASTClassInfo parentClassInfo = new ASTClassInfo(parentFilePath, parentCU, parentClass);
                parentClassName = null;
                parentClassInfo.setOrder(++order);
                superMethodDetails.put(parentFilePath, new HashSet<>());
                // Collect only the classes which has super calls, if not we don't need to consider that parent
                for (String childSuperMethod : childMethodsWithSuperSet) {
                    MethodLevelDetails methodLevelDetails = new MethodLevelDetails();
                    methodLevelDetails.setSuperMethodName(childSuperMethod);
                    for (MethodDeclaration method : parentClass.getMethods()) {
                        if (childSuperMethod.equals(method.getName().getFullyQualifiedName())) {
                            Set<FieldDeclaration> fieldDependencies = new HashSet<>();
                            Set<MethodDeclaration> methodDependencies = new HashSet<>();
                            JavaClassRefactorASTUtil.collectDependentMethodsAndFields(parentClass, method, methodDependencies, fieldDependencies, childFieldNames, childMethodsWithSuperSet);
                            parentClassInfo.getDependentMethods().addAll(methodDependencies);
                            parentClassInfo.getDependentFields().addAll(fieldDependencies);
                            parentClassInfo.getSuperMethods().add(method);
                            if (JavaClassRefactorASTUtil.containsSuperCall(method)) {
                                parentClassName = getParentClassName(parentClass);
                                methodLevelDetails.setSuperMethodAvailable(true);
                                break;
                            }
                        }
                    }
                    superMethodDetails.get(parentFilePath).add(methodLevelDetails);
                }
                parentClassInfo.setSuperMethodDetails(superMethodDetails.get(parentFilePath));
                classHierarchy.add(parentClassInfo);
                file = new File(parentClassInfo.getFilePath());
                className = file.getName().replace(".java", "");
                classesSet.add(className);
            }

            // Refactor the current class
            if (classHierarchy.size() > 1) { // Only proceed if there is at least one parent class
                String hierarchyClasses = classHierarchy.stream().map(ASTClassInfo::getFilePath).collect(Collectors.joining(", "));
                logger.debug("De-normalizing Classes - {}, {}", superMethodNameSet, hierarchyClasses);
//            refactorClass(classHierarchy, superMethodNameSet);
                refactorClass(classHierarchy);
                refactorSuperMethodCalls(classHierarchy);
                CompilationUnit childCU = parseJavaFile(currentFilePath);
                TypeDeclaration childClass = (TypeDeclaration) childCU.types().get(0);
                //if super method is not available but parent class is present then copy all methods and fields to child
                if (!parentClassesList.isEmpty()) {
                    ASTClassInfo childAstInfo = new ASTClassInfo(currentFilePath, childCU, childClass);
                    List<ASTClassInfo> astClassInfoList = new ArrayList<>();
                    for (int i = 0; i < classHierarchy.size(); i++) {
                        if (parentClassesList.contains(classHierarchy.get(i).getFilePath())) {
                            parentClassesList.remove(classHierarchy.get(i).getFilePath());
                        }
                    }

                    if (!parentClassesList.isEmpty()) {
                        if (childAstInfo != null)
                            astClassInfoList.add(childAstInfo);
                        for (int i = 0; i < parentClassesList.size(); i++) {
                            CompilationUnit parentCU = parseJavaFile(parentClassesList.get(i));
                            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
                            ASTClassInfo parentClassInfo = new ASTClassInfo(parentClassesList.get(i), parentCU, parentClass);
                            astClassInfoList.add(parentClassInfo);
                        }
                        if (!astClassInfoList.isEmpty())
                            refactorClassWithoutSuperCall(astClassInfoList);
                        CompilationUnit parentCU = parseJavaFile(parentClassesList.get(parentClassesList.size() - 1));
                        TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
                        AST ast = childCU.getAST();
                        ASTRewrite rewriter = ASTRewrite.create(ast);
                        JavaClassRefactorASTUtil.copyImplementedInterfaces(parentClass, childClass, rewriter);
                        // Write the refactored child class back to the disk
                        writeJavaFile(currentFilePath, childCU, rewriter);
                    }
                }
            } else {
                logger.debug("No parent class found. No refactoring needed.");
            }
        }
    }

    private static void refactorSuperMethodCalls(List<ASTClassInfo> classHierarchy) throws IOException {
        // Parse the current class
        String filePath = classHierarchy.get(0).getFilePath();
        CompilationUnit currentCU = parseJavaFile(filePath);
        TypeDeclaration currentClass = (TypeDeclaration) currentCU.types().get(0);

        // Refactor the child class
        AST ast = currentCU.getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);
        for (MethodDeclaration method : currentClass.getMethods()) {
            String methodName = method.getName().getFullyQualifiedName();
            if (JavaClassRefactorASTUtil.containsSuperCall(method)) {
                // Renames the super call to the name of the method which we provide
                String parentClassName = findParentClass4Method(classHierarchy, classHierarchy.get(0).getOrder(), methodName);
                JavaClassRefactorASTUtil.replaceSuperCalls(rewriter, method, parentClassName);
            }
        }
        // Write the refactored child class back to the disk
        writeJavaFile(filePath, currentCU, rewriter);
    }

    private static String findParentClass4Method(List<ASTClassInfo> classHierarchy, int order, String currentMethodName) {
        String parentClassName = "";
        String className = "";
        if (currentMethodName.contains("_")) {
            className = currentMethodName.substring(currentMethodName.lastIndexOf("_") + 1);
            if (classesSet.contains(className)) {
                order = order + 1;
                currentMethodName = currentMethodName.substring(0, currentMethodName.lastIndexOf("_"));
            }
        }
        for (ASTClassInfo aSTClassInfo : classHierarchy) {
            if (aSTClassInfo.getOrder() > order) {
                Set<MethodDeclaration> medhodDeclarationSet = aSTClassInfo.getSuperMethods();
                for (MethodDeclaration methodDeclaration : medhodDeclarationSet) {
                    if (methodDeclaration.getName().getFullyQualifiedName().equals(currentMethodName)) {
                        File classFile = new File(aSTClassInfo.getFilePath());
                        if (classFile.exists()) {
                            return methodDeclaration.getName().getIdentifier() + "_" + classFile.getName().replace(".java", "");
                            //break;
                        }
                    }
                }
            }
        }
        return parentClassName;
    }

    private static void refactorClass(List<ASTClassInfo> classHierarchy) throws IOException {
        ASTClassInfo childClassInfo = classHierarchy.get(0);
        // Refactor the child class
        AST ast = childClassInfo.getCompilationUnit().getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);
        for (int i = classHierarchy.size() - 1; i > 0; i--) {
            ASTClassInfo currentClassInfo = classHierarchy.get(i);
            String className = new File(currentClassInfo.getFilePath()).getName().replace(".java", "");
            // Determine the parent class name for appending to the copied methods
            String parentClassName = "";
            if ((i + 1) < classHierarchy.size())
                parentClassName = new File(classHierarchy.get(i + 1).getFilePath()).getName().replace(".java", "");

            // Add fields to the child class
            for (FieldDeclaration field : currentClassInfo.getDependentFields()) {
                FieldDeclaration copiedField = (FieldDeclaration) ASTNode.copySubtree(ast, field);
                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.getClassType(), TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertFirst(copiedField, null);
            }

            // Add super methods to the child class
            for (MethodDeclaration method : currentClassInfo.getSuperMethods()) {
                String newMethodName = method.getName().getIdentifier() + "_" + StringUtils.capitalize(className);
                // Create a copy of the method with the new name
                MethodDeclaration copiedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
                copiedMethod.setName(ast.newSimpleName(newMethodName));
                JavaClassRefactorASTUtil.removeOverrideAnnotation(rewriter, copiedMethod, "Override");
//                JavaClassRefactorASTUtil.replaceSuperCalls(rewriter, copiedMethod, method.getName().getIdentifier() + "_" + StringUtils.capitalize(parentClassName));

                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.getClassType(), TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertLast(copiedMethod, null);
            }

            // Add dependent methods to the child class
            for (MethodDeclaration method : currentClassInfo.getDependentMethods()) {
                // Create a copy of the method with the new name
                MethodDeclaration copiedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
                JavaClassRefactorASTUtil.removeOverrideAnnotation(rewriter, copiedMethod, "Override");

                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.getClassType(), TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertLast(copiedMethod, null);
            }

            // Resolve imports
            JavaClassRefactorASTUtil.resolveImports(currentClassInfo.getCompilationUnit(), childClassInfo.getCompilationUnit(), rewriter, classHierarchy);
            JavaClassRefactorASTUtil.removeParentImports(childClassInfo.getCompilationUnit(), rewriter, classHierarchy);
        }

        // Remove the `extends ParentClass` declaration from the child class
        rewriter.set(childClassInfo.getClassType(), TypeDeclaration.SUPERCLASS_TYPE_PROPERTY, null, null);

        // Remove the parent imports
        JavaClassRefactorASTUtil.removeParentImports(childClassInfo.getCompilationUnit(), rewriter, classHierarchy);

        // Remove the `Override` Annotation and replace super calls from the child class
        for (MethodDeclaration method : childClassInfo.getClassType().getMethods()) {
            JavaClassRefactorASTUtil.removeOverrideAnnotation(rewriter, method, "Override");
//            if (classHierarchy.size() > 1)
//                JavaClassRefactorASTUtil.replaceSuperCalls(rewriter, method, method.getName().getIdentifier() + "_" + StringUtils.capitalize(new File(classHierarchy.get(1).filePath).getName().replace(".java", "")));
        }

        // Write the refactored child class back to the disk
        writeJavaFile(childClassInfo.getFilePath(), childClassInfo.getCompilationUnit(), rewriter);
    }

    private static void refactorClassWithoutSuperCall(List<ASTClassInfo> classHierarchy) throws IOException {
        ASTClassInfo childClassInfo = classHierarchy.get(0);
        // Refactor the child class
        AST ast = childClassInfo.getCompilationUnit().getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);
        for (int i = classHierarchy.size() - 1; i > 0; i--) {
            ASTClassInfo currentClassInfo = classHierarchy.get(i);
            TypeDeclaration currentClass = (TypeDeclaration) currentClassInfo.getCompilationUnit().types().get(0);
            for (FieldDeclaration field : currentClass.getFields()) {
                FieldDeclaration copiedField = (FieldDeclaration) ASTNode.copySubtree(ast, field);
                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.getClassType(), TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertFirst(copiedField, null);

            }
            // Add dependent methods to the child class
            for (MethodDeclaration method : currentClass.getMethods()) {
                if (!childMethodsWithSuperSet.contains(method.getName().getFullyQualifiedName())) {
                    // Create a copy of the method with the new name
                    MethodDeclaration copiedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
                    ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.getClassType(), TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                    listRewrite.insertLast(copiedMethod, null);
                }
            }

            // Resolve imports
            JavaClassRefactorASTUtil.resolveImports(currentClassInfo.getCompilationUnit(), childClassInfo.getCompilationUnit(), rewriter, classHierarchy);
            JavaClassRefactorASTUtil.removeParentImports(childClassInfo.getCompilationUnit(), rewriter, classHierarchy);
        }
        // Write the refactored child class back to the disk
        writeJavaFile(childClassInfo.getFilePath(), childClassInfo.getCompilationUnit(), rewriter);
    }


    private static void refactorClass(List<ASTClassInfo> classHierarchy, Set<String> superMethodNameSet) throws IOException {
        ASTClassInfo childClassInfo = classHierarchy.get(0);
        Set<String> childFieldNames = new HashSet<>();
        for (BodyDeclaration body : (List<BodyDeclaration>) childClassInfo.getClassType().bodyDeclarations()) {
            if (body instanceof FieldDeclaration) {
                FieldDeclaration field = (FieldDeclaration) body;
                for (Object fragment : field.fragments()) {
                    if (fragment instanceof VariableDeclarationFragment) {
                        VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                        childFieldNames.add(varFragment.getName().getIdentifier());
                    }
                }
            }
        }

        // Refactor the child class
        AST ast = childClassInfo.getCompilationUnit().getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);
        for (int i = classHierarchy.size() - 1; i > 0; i--) {
            ASTClassInfo currentClassInfo = classHierarchy.get(i);
            String className = new File(currentClassInfo.getFilePath()).getName().replace(".java", "");
            // Determine the parent class name for appending to the copied methods
            String parentClassName = "";
            if ((i + 1) < classHierarchy.size())
                parentClassName = new File(classHierarchy.get(i + 1).getFilePath()).getName().replace(".java", "");

            // Collect methods to move from the current class
            List<MethodDeclaration> methodsToMove = new ArrayList<>();
            for (BodyDeclaration body : (List<BodyDeclaration>) currentClassInfo.getClassType().bodyDeclarations()) {
                if (body instanceof MethodDeclaration) {
                    MethodDeclaration method = (MethodDeclaration) body;
                    if (!method.isConstructor()) {
                        methodsToMove.add(method);
                    }
                }
            }
        }
    }

    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    private static void writeJavaFile(String filePath, CompilationUnit cu, ASTRewrite rewriter) throws IOException {
        Document document = new Document(readFile(filePath));
        TextEdit edits = rewriter.rewriteAST(document, null);
        try {
            edits.apply(document);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Write the updated source code back to the file
        FileWriter writer = new FileWriter(new File(filePath));
        writer.write(document.get());
        writer.close();
    }

    private static String findClassFile(List<Path> pathList, String className) {
        // Logic to dynamically locate the class file
        for (Path fileName : pathList) {
            if (fileName.toFile().getName().endsWith(className + ".java")) {
                return fileName.toFile().getAbsolutePath();
            }
        }
        return null;
    }

    private static String getParentClassName(TypeDeclaration classType) {
        if (classType.getSuperclassType() != null) {
            return classType.getSuperclassType().toString();
        }
        return null;
    }
}
