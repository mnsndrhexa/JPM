package com.hex.ast.poc;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;

import java.io.FileWriter;
import java.io.IOException;

public class DotVisitor extends ASTVisitor {
    private final FileWriter writer;

    public DotVisitor(FileWriter writer) {
        this.writer = writer;
    }

    @Override
    public void preVisit(ASTNode node) {
        try {
            // Write the current node
            writer.write("    \"" + node.hashCode() + "\" [label=\"" + node.getClass().getSimpleName() + "\"];\n");

            // Write edges to child nodes
            for (Object child : node.structuralPropertiesForType()) {
                if (child instanceof ASTNode) {
                    ASTNode childNode = (ASTNode) child;
                    writer.write("    \"" + node.hashCode() + "\" -> \"" + childNode.hashCode() + "\";\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}