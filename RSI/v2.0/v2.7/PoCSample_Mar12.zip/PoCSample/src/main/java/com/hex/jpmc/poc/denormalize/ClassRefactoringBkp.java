package com.hex.jpmc.poc.denormalize;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ClassRefactoringBkp {

    public static void main(String[] args) throws IOException {
        // Path to the current file to process
        String currentFilePath = "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java";
        List<Path> pathList;
        try (Stream<Path> stream = Files.walk(Paths.get("C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample"))) {
            pathList = stream.map(Path::normalize).filter(Files::isRegularFile).collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Parse the current class
        CompilationUnit currentCU = parseJavaFile(currentFilePath);
        TypeDeclaration currentClass = (TypeDeclaration) currentCU.types().get(0);

        // Traverse the inheritance chain
        List<ClassInfo> classHierarchy = new ArrayList<>();
        ClassInfo currentClassInfo = new ClassInfo(currentFilePath, currentCU, currentClass);
        classHierarchy.add(currentClassInfo);

        Set<String> superMethodNameSet = new HashSet<>();
        // Dynamically find and process all parent classes
        String parentClassName = getParentClassName(currentClass);
        while (parentClassName != null) {
            String parentFilePath = findClassFile(pathList, parentClassName);
            if (parentFilePath == null) {
                System.out.println("Parent class file not found: " + parentClassName);
                break;
            }

            CompilationUnit parentCU = parseJavaFile(parentFilePath);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
            classHierarchy.add(new ClassInfo(parentFilePath, parentCU, parentClass));
            parentClassName = null;
            // Collect only the classes which has super calls, if not we don't need to consider that parent
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    parentClassName = getParentClassName(parentClass);
                    break;
                }
            }
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    superMethodNameSet.add(method.getName().getFullyQualifiedName());
                }
            }
        }

        // Refactor the current class
        if (classHierarchy.size() > 1) { // Only proceed if there is at least one parent class
            refactorClass(classHierarchy, superMethodNameSet);
        } else {
            System.out.println("No parent class found. No refactoring needed.");
        }
    }

    private static void refactorClass(List<ClassInfo> classHierarchy, Set<String> superMethodNameSet) throws IOException {
        ClassInfo childClassInfo = classHierarchy.get(0);
        Set<String> childFieldNames = new HashSet<>();
        for (BodyDeclaration body : (List<BodyDeclaration>) childClassInfo.classType.bodyDeclarations()) {
            if (body instanceof FieldDeclaration) {
                FieldDeclaration field = (FieldDeclaration) body;
                for (Object fragment : field.fragments()) {
                    if (fragment instanceof VariableDeclarationFragment) {
                        VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                        childFieldNames.add(varFragment.getName().getIdentifier());
                    }
                }
            }
        }

        // Refactor the child class
        AST ast = childClassInfo.compilationUnit.getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);
        for (int i = classHierarchy.size() - 1; i > 0; i--) {
            ClassInfo currentClassInfo = classHierarchy.get(i);
            String className = new File(currentClassInfo.filePath).getName().replace(".java", "");
            // Determine the parent class name for appending to the copied methods
            String parentClassName = "";
            if ((i + 1) < classHierarchy.size())
                parentClassName = new File(classHierarchy.get(i + 1).filePath).getName().replace(".java", "");

            // Collect methods to move from the current class
            List<MethodDeclaration> methodsToMove = new ArrayList<>();
            for (BodyDeclaration body : (List<BodyDeclaration>) currentClassInfo.classType.bodyDeclarations()) {
                if (body instanceof MethodDeclaration) {
                    MethodDeclaration method = (MethodDeclaration) body;
                    if (!method.isConstructor()) {
                        methodsToMove.add(method);
                    }
                }
            }

            // Collect fields referenced in the methods to move
            Set<FieldDeclaration> fieldsToCopy = collectReferencedFields(currentClassInfo.classType, methodsToMove, childFieldNames);

            // Add fields to the child class
            for (FieldDeclaration field : fieldsToCopy) {
                FieldDeclaration copiedField = (FieldDeclaration) ASTNode.copySubtree(ast, field);
                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.classType, TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertFirst(copiedField, null);
            }

            // Add methods to the child class
            for (MethodDeclaration method : methodsToMove) {
                String newMethodName = method.getName().getIdentifier() + "_" + StringUtils.capitalize(className);
                // Create a copy of the method with the new name
                MethodDeclaration copiedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
                if (superMethodNameSet.contains(copiedMethod.getName().getFullyQualifiedName()))
                    copiedMethod.setName(ast.newSimpleName(newMethodName));
                removeOverrideAnnotation(rewriter, copiedMethod, "Override");
                replaceSuperCalls(rewriter, copiedMethod, method.getName().getIdentifier() + "_" + StringUtils.capitalize(parentClassName));

                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.classType, TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertLast(copiedMethod, null);
            }

            // Resolve imports
            resolveImports(currentClassInfo.compilationUnit, childClassInfo.compilationUnit, rewriter, classHierarchy);
            removeParentImports(childClassInfo.compilationUnit, rewriter, classHierarchy);
        }

        // Remove the `extends ParentClass` declaration from the child class
        rewriter.set(childClassInfo.classType, TypeDeclaration.SUPERCLASS_TYPE_PROPERTY, null, null);

        // Remove the parent imports
        removeParentImports(childClassInfo.compilationUnit, rewriter, classHierarchy);

        // Remove the `Override` Annotation and replace super calls from the child class
        for (MethodDeclaration method : childClassInfo.classType.getMethods()) {
            removeOverrideAnnotation(rewriter, method, "Override");
            if (classHierarchy.size() > 1)
                replaceSuperCalls(rewriter, method, method.getName().getIdentifier() + "_" + StringUtils.capitalize(new File(classHierarchy.get(1).filePath).getName().replace(".java", "")));
        }

        // Write the refactored child class back to the disk
        writeJavaFile(childClassInfo.filePath, childClassInfo.compilationUnit, rewriter);
    }

    private static void replaceSuperCalls(ASTRewrite rewriter, MethodDeclaration method, String newMethodName) {
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                AST ast = method.getAST();
                MethodInvocation newInvocation = ast.newMethodInvocation();
                newInvocation.setName(ast.newSimpleName(newMethodName));
                // Copy the arguments from the original super method invocation
                for (Object argument : node.arguments()) {
                    Expression copiedArgument = (Expression) ASTNode.copySubtree(ast, (ASTNode) argument);
                    newInvocation.arguments().add(copiedArgument);
                }
                rewriter.replace(node, newInvocation, null);
                return false;
            }
        });
    }

    private static void removeOverrideAnnotation(ASTRewrite rewriter, MethodDeclaration copiedMethod, String annotationName) {
        // Remove the specified annotation
        ListRewrite listRewrite = rewriter.getListRewrite(copiedMethod, MethodDeclaration.MODIFIERS2_PROPERTY);
        List<IExtendedModifier> modifiers = copiedMethod.modifiers();

        for (IExtendedModifier modifier : modifiers) {
            if (modifier.isAnnotation()) {
                Annotation annotation = (Annotation) modifier;
                if (annotation.getTypeName().getFullyQualifiedName().equals(annotationName)) {
                    listRewrite.remove(annotation, null); // Remove the annotation
                }
            }
        }
    }

    private static void removeParentImports(CompilationUnit childCU, ASTRewrite rewriter, List<ClassInfo> classHierarchy) {
        // Remove the parent imports
        List<ImportDeclaration> childImports = childCU.imports();

        for (ImportDeclaration importDeclaration : childImports) {
            for (ClassInfo classInfo : classHierarchy) {
                String className = new File(classInfo.filePath).getName().replace(".java", "");
                if (importDeclaration.getName().toString().contains(className)) {
                    rewriter.remove(importDeclaration, null);
                }
            }
        }
    }

    private static Set<FieldDeclaration> collectReferencedFields(TypeDeclaration parentClass, List<MethodDeclaration> methods, Set<String> childFieldNames) {
        Set<FieldDeclaration> fieldsToCopy = new HashSet<>();
        for (BodyDeclaration body : (List<BodyDeclaration>) parentClass.bodyDeclarations()) {
            if (body instanceof FieldDeclaration) {
                FieldDeclaration field = (FieldDeclaration) body;
                boolean isFieldAlreadyPresent = false;

                for (Object fragment : field.fragments()) {
                    if (fragment instanceof VariableDeclarationFragment) {
                        VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                        if (childFieldNames.contains(varFragment.getName().getIdentifier())) {
                            isFieldAlreadyPresent = true;
                            break;
                        }
                    }
                }
                if (!isFieldAlreadyPresent) {
                    for (MethodDeclaration method : methods) {
                        if (isFieldReferenced(method, field)) {
                            fieldsToCopy.add(field);
                        }
                    }
                }
            }
        }
        return fieldsToCopy;
    }

    private static boolean isFieldReferenced(MethodDeclaration method, FieldDeclaration field) {
        final boolean[] isReferenced = {false};
        field.accept(new ASTVisitor() {
            @Override
            public boolean visit(SimpleName node) {
                if (method.toString().contains(node.getIdentifier())) {
                    isReferenced[0] = true;
                }
                return false;
            }
        });
        return isReferenced[0];
    }

    private static void resolveImports(CompilationUnit parentCU, CompilationUnit childCU, ASTRewrite rewriter, List<ClassInfo> classHierarchy) {
        List<ImportDeclaration> parentImports = parentCU.imports();
        List<ImportDeclaration> childImports = childCU.imports();

        for (ImportDeclaration parentImport : parentImports) {
            boolean isAlreadyImported = false;
            for (ClassInfo classInfo : classHierarchy) {
                String className = new File(classInfo.filePath).getName().replace(".java", "");
                if (parentImport.getName().toString().contains(className)) {
                    isAlreadyImported = true;
                    break;
                }
            }
            for (ImportDeclaration childImport : childImports) {
                if (childImport.getName().getFullyQualifiedName().equals(parentImport.getName().getFullyQualifiedName())) {
                    isAlreadyImported = true;
                    break;
                }
            }
            if (!isAlreadyImported) {
                AST ast = childCU.getAST();
                ImportDeclaration newImport = (ImportDeclaration) ASTNode.copySubtree(ast, parentImport);
                ListRewrite importRewrite = rewriter.getListRewrite(childCU, CompilationUnit.IMPORTS_PROPERTY);
                importRewrite.insertLast(newImport, null);
            }
        }
    }

    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    private static void writeJavaFile(String filePath, CompilationUnit cu, ASTRewrite rewriter) throws IOException {
        Document document = new Document(readFile(filePath));
        TextEdit edits = rewriter.rewriteAST(document, null);
        try {
            edits.apply(document);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Write the updated source code back to the file
        FileWriter writer = new FileWriter(new File(filePath.replace(".java", "New.java")));
        writer.write(document.get());
        writer.close();
    }

    private static String findClassFile(List<Path> pathList, String className) {
        // Logic to dynamically locate the class file
        for (Path fileName : pathList) {
            if (fileName.toFile().getName().endsWith(className + ".java")) {
                return fileName.toFile().getAbsolutePath();
            }
        }
        return null;
    }

    private static String getParentClassName(TypeDeclaration classType) {
        if (classType.getSuperclassType() != null) {
            return classType.getSuperclassType().toString();
        }
        return null;
    }

    private static boolean containsSuperCall(MethodDeclaration method) {
        final boolean[] hasSuperCall = {false};
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                hasSuperCall[0] = true;
                return false; // No need to visit further
            }
        });
        return hasSuperCall[0];
    }

    private static Set<BodyDeclaration> resolveDependencies(TypeDeclaration parentClass, MethodDeclaration method) {
        Set<BodyDeclaration> dependencies = new HashSet<>();
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(MethodInvocation node) {
                String methodName = node.getName().getIdentifier();
                for (MethodDeclaration parentMethod : parentClass.getMethods()) {
                    if (parentMethod.getName().getIdentifier().equals(methodName)) {
                        dependencies.add(parentMethod);
                    }
                }
                return true;
            }

            @Override
            public boolean visit(SimpleName node) {
                String name = node.getIdentifier();
                for (FieldDeclaration field : parentClass.getFields()) {
                    String fieldName = field.fragments().get(0).toString();
                    if (fieldName.equals(name)) {
                        dependencies.add(field);
                    }
                }
                return true;
            }
        });
        return dependencies;
    }

    static class ClassInfo {
        String filePath;
        CompilationUnit compilationUnit;
        TypeDeclaration classType;

        ClassInfo(String filePath, CompilationUnit compilationUnit, TypeDeclaration classType) {
            this.filePath = filePath;
            this.compilationUnit = compilationUnit;
            this.classType = classType;
        }
    }
}
