package com.hex.ast.poc;

public class AppTableMapping {

	private String className;

	private String crudOperation;

	private String tableName;

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getCrudOperation() {
		return crudOperation;
	}

	public void setCrudOperation(String curdOperation) {
		this.crudOperation = curdOperation;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public int hashCode() {
		int hashcode = 0;
		hashcode += className.hashCode();
		hashcode += tableName.hashCode();
		hashcode += crudOperation.hashCode();
		return hashcode;
	}

	public boolean equals(Object obj) {
		if (obj instanceof AppTableMapping) {
			AppTableMapping ctc = (AppTableMapping) obj;

			return (ctc.getClassName().equals(this.className) && (ctc.getTableName().equals(this.tableName))
					&& (ctc.getCrudOperation().equals(this.crudOperation)));
		} else {
			return false;
		}
	}
}
