package com.hex.jpmc.poc.denormalize;

import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MultiMethodMover {

    public static void main(String[] args) throws IOException {
        // Path to the current file to process
        String parentPath = "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample";
        String currentFilePath = "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java";

        // Parse the current class
        CompilationUnit currentCU = parseJavaFile(currentFilePath);
        TypeDeclaration currentClass = (TypeDeclaration) currentCU.types().get(0);

        // Check if the class has a parent
        if (currentClass.getSuperclassType() != null) {
            String parentClassName = currentClass.getSuperclassType().toString();

            // Dynamically locate the parent class file
            String parentFilePath = locateParentClassFile(parentClassName, parentPath);
            if (parentFilePath == null) {
                System.out.println("Parent class file not found: " + parentClassName);
                return;
            }

            // Parse the parent class
            CompilationUnit parentCU = parseJavaFile(parentFilePath);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);

            // Collect methods to move from the parent class
            List<MethodDeclaration> methodsToMove = new ArrayList<>();
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    methodsToMove.add(method);
                }
            }

            // Refactor the current class
            AST ast = currentCU.getAST();
            ASTRewrite rewriter = ASTRewrite.create(ast);

            for (MethodDeclaration method : methodsToMove) {
                // Rename the method
                String newMethodName = method.getName().getIdentifier() + "_Child";

                // Create a copy of the method with the new name
                MethodDeclaration copiedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
                copiedMethod.setName(ast.newSimpleName(newMethodName));

                // Replace super() calls in the copied method
                replaceSuperCalls(rewriter, copiedMethod, newMethodName);

                // Add the copied method to the current class
                ListRewrite listRewrite = rewriter.getListRewrite(currentClass, TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertLast(copiedMethod, null);
            }

            // Remove the `extends ParentClass` declaration
            rewriter.set(currentClass, TypeDeclaration.SUPERCLASS_TYPE_PROPERTY, null, null);

            // Write the refactored file back to the disk
            writeJavaFile(currentFilePath, currentCU, rewriter);

            System.out.println("Refactoring complete for: " + currentFilePath);
        } else {
            System.out.println("No parent class found for: " + currentFilePath);
        }
    }

    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    private static void writeJavaFile(String filePath, CompilationUnit cu, ASTRewrite rewriter) throws IOException {
        Document document = new Document(readFile(filePath));
        TextEdit edits = rewriter.rewriteAST(document, null);
        try {
            edits.apply(document);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Write the updated source code back to the file
        FileWriter writer = new FileWriter(new File(filePath.replace(".java", "New.java")));
        writer.write(document.get());
        writer.close();
    }

    private static String locateParentClassFile(String parentClassName, String parentPath) {
        // Logic to dynamically locate the parent class file
        // For simplicity, assume the parent class file is in the same directory
        List<Path> pathList;
        try (Stream<Path> stream = Files.walk(Paths.get(parentPath))) {
            pathList = stream.map(Path::normalize).filter(Files::isRegularFile).collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        for (Path fileName : pathList) {
            if (fileName.toFile().getName().endsWith(parentClassName + ".java")) {
                return fileName.toFile().getAbsolutePath();
            }
        }
//        String parentFilePath = "src/" + parentClassName + ".java";
//        File parentFile = new File(parentFilePath);
        return null;
    }

    private static boolean containsSuperCall(MethodDeclaration method) {
        final boolean[] hasSuperCall = {false};
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                hasSuperCall[0] = true;
                return false; // No need to visit further
            }
        });
        return hasSuperCall[0];
    }

    private static void replaceSuperCalls(ASTRewrite rewriter, MethodDeclaration method, String newMethodName) {
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                AST ast = method.getAST();
                MethodInvocation newInvocation = ast.newMethodInvocation();
                newInvocation.setName(ast.newSimpleName(newMethodName));
                rewriter.replace(node, newInvocation, null);
                return false;
            }
        });
    }
}
