package com.hex.jpmc.poc.denormalize.latest;

import lombok.Data;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.util.HashSet;
import java.util.Set;

@Data
public class ASTClassInfo {
    private String filePath;
    private int order;
    private CompilationUnit compilationUnit;
    private TypeDeclaration classType;
    private Set<MethodLevelDetails> superMethodDetails = new HashSet<>();
    private Set<MethodDeclaration> superMethods = new HashSet<>();
    private Set<MethodDeclaration> dependentMethods = new HashSet<>();
    private Set<FieldDeclaration> dependentFields = new HashSet<>();

    public ASTClassInfo(String filePath, CompilationUnit compilationUnit, TypeDeclaration classType) {
        this.filePath = filePath;
        this.compilationUnit = compilationUnit;
        this.classType = classType;
    }
}
