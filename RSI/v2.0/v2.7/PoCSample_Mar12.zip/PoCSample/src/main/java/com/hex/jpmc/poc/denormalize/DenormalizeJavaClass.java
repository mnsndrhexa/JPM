package com.hex.jpmc.poc.denormalize;

import com.hex.ast.poc.IdentifyJavaClass;
import com.hex.ast.poc.JavaClassDetails;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DenormalizeJavaClass {

    public static void main(String[] args) {
        List<String> fileList = new ArrayList<>();
        fileList.add("C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\ExpressOnlineBaseGenericMutator.java");
        fileList.add("C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\ExpressOnlineGenericMutator.java");
        fileList.add("C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java");

        List<JavaClassDetails> allClassDetails = new ArrayList<>();
        IdentifyJavaClass identifyJavaClass = new IdentifyJavaClass();
        for (String fileName : fileList) {
            JavaClassDetails classDetails = new JavaClassDetails();
            identifyJavaClass.identifyJavaFileContent(new File(fileName), classDetails);
            allClassDetails.add(classDetails);
        }
        System.out.println(allClassDetails);
    }
}
