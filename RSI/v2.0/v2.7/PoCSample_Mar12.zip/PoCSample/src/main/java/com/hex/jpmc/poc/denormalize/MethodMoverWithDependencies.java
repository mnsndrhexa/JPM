package com.hex.jpmc.poc.denormalize;

import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class MethodMoverWithDependencies {

    public static void main(String[] args) throws IOException {
        // Paths to the source files of the parent and child classes
        String[] classPaths = {
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\ExpressOnlineBaseGenericMutator.java",  // Top-level parent
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\ExpressOnlineGenericMutator.java",  // Intermediate parent
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java"   // Last child
        };

        // Parse all classes in the hierarchy
        List<CompilationUnit> classUnits = new ArrayList<>();
        for (String classPath : classPaths) {
            classUnits.add(parseJavaFile(classPath));
        }

        // Collect methods and fields from all parent classes
        Map<MethodDeclaration, Set<BodyDeclaration>> dependencies = new HashMap<>();
        for (int i = 0; i < classUnits.size() - 1; i++) { // Exclude the last child
            CompilationUnit parentCU = classUnits.get(i);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (!method.isConstructor()) {
                    Set<BodyDeclaration> dependentElements = resolveDependencies(parentClass, method);
                    dependencies.put(method, dependentElements);
                }
            }
        }

        // Add all collected methods and fields to the last child class
        CompilationUnit lastChildCU = classUnits.get(classUnits.size() - 1);
        TypeDeclaration lastChildClass = (TypeDeclaration) lastChildCU.types().get(0);
        AST ast = lastChildClass.getAST();

        for (Map.Entry<MethodDeclaration, Set<BodyDeclaration>> entry : dependencies.entrySet()) {
            MethodDeclaration method = (MethodDeclaration) ASTNode.copySubtree(ast, entry.getKey());
            lastChildClass.bodyDeclarations().add(method);

            for (BodyDeclaration dependent : entry.getValue()) {
                if (!alreadyExists(lastChildClass, dependent)) {
                    BodyDeclaration copiedDependent = (BodyDeclaration) ASTNode.copySubtree(ast, dependent);
                    lastChildClass.bodyDeclarations().add(copiedDependent);
                }
            }
        }

        // Write the updated last child class back to the file system
        writeJavaFile(classPaths[classUnits.size() - 1], lastChildCU);

        // Optionally, remove methods and fields from parent classes and write back
//        for (int i = 0; i < classUnits.size() - 1; i++) {
//            CompilationUnit parentCU = classUnits.get(i);
//            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
//            parentClass.bodyDeclarations().removeIf(declaration -> declaration instanceof MethodDeclaration declaration instanceof FieldDeclaration);
//            writeJavaFile(classPaths[i], parentCU);
//        }
    }

    // Resolves dependencies for a given method
    private static Set<BodyDeclaration> resolveDependencies(TypeDeclaration parentClass, MethodDeclaration method) {
        Set<BodyDeclaration> dependencies = new HashSet<>();

        // Find methods and fields accessed by this method
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(MethodInvocation node) {
                String methodName = node.getName().getIdentifier();
                for (MethodDeclaration parentMethod : parentClass.getMethods()) {
                    if (parentMethod.getName().getIdentifier().equals(methodName)) {
                        dependencies.add(parentMethod);
                    }
                }
                return super.visit(node);
            }

            @Override
            public boolean visit(FieldAccess node) {
                String fieldName = node.getName().getIdentifier();
                for (FieldDeclaration field : parentClass.getFields()) {
                    VariableDeclarationFragment fragment = (VariableDeclarationFragment) field.fragments().get(0);
                    if (fragment.getName().getIdentifier().equals(fieldName)) {
                        dependencies.add(field);
                    }
                }
                return super.visit(node);
            }

            @Override
            public boolean visit(SimpleName node) {
                String name = node.getIdentifier();
                // Check for field access
                for (FieldDeclaration field : parentClass.getFields()) {
                    VariableDeclarationFragment fragment = (VariableDeclarationFragment) field.fragments().get(0);
                    if (fragment.getName().getIdentifier().equals(name)) {
                        dependencies.add(field);
                    }
                }
                return super.visit(node);
            }
        });

        return dependencies;
    }

    // Checks if a body declaration already exists in the target class
    private static boolean alreadyExists(TypeDeclaration targetClass, BodyDeclaration declaration) {
        if (declaration instanceof MethodDeclaration) {
            String methodName = ((MethodDeclaration) declaration).getName().getIdentifier();
            for (MethodDeclaration method : targetClass.getMethods()) {
                if (method.getName().getIdentifier().equals(methodName)) {
                    return true;
                }
            }
        } else if (declaration instanceof FieldDeclaration) {
            VariableDeclarationFragment fragment = (VariableDeclarationFragment) ((FieldDeclaration) declaration).fragments().get(0);
            String fieldName = fragment.getName().getIdentifier();
            for (FieldDeclaration field : targetClass.getFields()) {
                VariableDeclarationFragment targetFragment = (VariableDeclarationFragment) field.fragments().get(0);
                if (targetFragment.getName().getIdentifier().equals(fieldName)) {
                    return true;
                }
            }
        }
        return false;
    }

    // Parses a Java source file into a CompilationUnit
    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8); // Use the appropriate Java version
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    // Reads the content of a file into a String
    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    // Writes a CompilationUnit back to a file
    private static void writeJavaFile(String filePath, CompilationUnit compilationUnit) throws IOException {
        ASTRewrite rewriter = ASTRewrite.create(compilationUnit.getAST());
        Document document = new Document(compilationUnit.toString());
        TextEdit edits = rewriter.rewriteAST(document, null);
        try {
            edits.apply(document);
        } catch (BadLocationException e) {
            throw new RuntimeException(e);
        }

        Files.write(Paths.get(filePath.replace(".java", "New.java")), document.get().getBytes());
//        String updatedSource = compilationUnit.toString();
//        FileWriter writer = new FileWriter(new File(filePath.replace(".java", "New.java")));
//        writer.write(updatedSource);
//        writer.close();
    }
}