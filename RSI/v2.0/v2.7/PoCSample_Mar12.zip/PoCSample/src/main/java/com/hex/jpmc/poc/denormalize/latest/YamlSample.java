package com.hex.jpmc.poc.denormalize.latest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;

public class YamlSample {
    public static void main(String[] args) throws JsonProcessingException {
        String xml = "<XmlRequestMapping>\n" +
                "        <RequestField xmlName=\"ApplicantData\" sessionName=\"ApplicantData.session\" required=\"false\" formatter=\"com.jpmc.spring.validator.base.impl.DefaultFormatValidatorImpl\" length=\"1\"/>\n" +
                "        <RequestField xmlName=\"ApplicantData.EnterpriseID\" sessionName=\"ApplicantData.EnterpriseID\" required=\"false\" formatter=\"com.jpmc.spring.validator.base.impl.DefaultFormatValidatorImpl\" length=\"10\"/>\n" +
                "        <RequestField xmlName=\"SignerCustomers\" sessionName=\"SignerCustomers\" required=\"false\" formatter=\"com.jpmc.spring.validator.base.impl.DefaultFormatValidatorImpl\" length=\"0\"/>\n" +
                "        <RequestField xmlName=\"SignerCustomer.EnterpriseCustomer.EnterpriseID\" sessionName=\"SignerCustomers.EnterpriseCustomer.EnterpriseID\" required=\"false\" formatter=\"com.jpmc.spring.validator.base.impl.DefaultFormatValidatorImpl\" length=\"0\"/>\n" +
                "        <RequestField xmlName=\"Login\" sessionName=\"LoginID\" required=\"false\" formatter=\"com.jpmc.spring.validator.base.impl.DefaultFormatValidatorImpl\" length=\"0\"/>\n" +
                "        <RequestField xmlName=\"AuthenticateLoginID\" sessionName=\"AuthenticateLoginId\" required=\"false\" formatter=\"com.jpmc.spring.validator.base.impl.DefaultFormatValidatorImpl\" length=\"10\"/>\n" +
                "    </XmlRequestMapping>";

        XmlMapper xmlMapper = new XmlMapper();
        Object dataObject = xmlMapper.readValue(xml, Object.class);

        YAMLMapper yamlMapper = new YAMLMapper();
        String yaml = yamlMapper.writeValueAsString(dataObject);
        System.out.println(yaml);
    }
}
