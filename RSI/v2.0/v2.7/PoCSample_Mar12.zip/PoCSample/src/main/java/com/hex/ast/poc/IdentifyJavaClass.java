package com.hex.ast.poc;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jdt.core.dom.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class IdentifyJavaClass {

    private static final Logger logger = LogManager.getLogger(IdentifyJavaClass.class);

    public static void main(String[] args) throws IOException {
//        File inputFile = new File("C:\\Users\\1000022257\\Desktop\\Source\\whole\\MMS\\spring-mms-web\\src\\main\\java\\com\\journaldev\\spring\\controller\\PaymentProfileController.java");
        File inputFile = new File("C:\\Users\\1000022257\\Desktop\\Example.java");
        JavaClassDetails classDetails = new JavaClassDetails();
        new IdentifyJavaClass().identifyJavaFileContent(inputFile, classDetails);
//        System.out.println(classDetails);
    }

    public void identifyJavaFileContent(File fileName, JavaClassDetails classDetails) {
        String source = "";
        try {
            source = new String(Files.readAllBytes(Paths.get(fileName.getAbsolutePath())));
        } catch (IOException e) {
            logger.error(FunctionalUtils.getExceptionStackTrace(e));
        }
        classDetails.setPackageName("");
        classDetails.setClassName(fileName.getName().replace(".java", ""));
        classDetails.setClassFilePath(fileName.getAbsolutePath());
        if (!source.isEmpty()) {
            CompilationUnit cu = (CompilationUnit) buildAstForClass(source).createAST(null);
            if (cu.getPackage() != null)
                classDetails.setPackageName(cu.getPackage().getName().getFullyQualifiedName());
            cu.accept(new ASTVisitor() {
                @Override
                public boolean visit(ImportDeclaration node) {
                    String importStmt = node.toString();
                    importStmt = StringUtils.replace(importStmt, "import ", "");
                    importStmt = StringUtils.replace(importStmt, ";", "");
                    classDetails.getImportStatements().add(importStmt);
                    return super.visit(node);
                }

                @Override
                public boolean visit(TypeDeclaration node) {
                    List<Type> interfaces = node.superInterfaceTypes();
                    for (Type iface : interfaces) {
                        classDetails.getInterfaceNames().add(iface.toString());
                    }
                    Type extend = node.getSuperclassType();
                    if (extend != null)
                        classDetails.setExtendClassName(extend.toString());
                    return super.visit(node);
                }

                @Override
                public boolean visit(VariableDeclarationFragment node) {
                    if (node.getParent() instanceof FieldDeclaration)
                        classDetails.getInstanceVariables().put(node.getName().toString(), ((FieldDeclaration) node.getParent()).getType().toString());
                    return super.visit(node);
                }
            });
            // Create a FileWriter to write the DOT file
//            try (FileWriter writer = new FileWriter("eclipse_ast.dot")) {
//                writer.write("digraph AST {\n");
//                cu.accept(new DotVisitor(writer));
//                writer.write("}\n");
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
        }
    }

    public ASTParser buildAstForClass(String sourceContent) {
        ASTParser astParser = ASTParser.newParser(AST.JLS8);
        astParser.setSource(sourceContent.toCharArray());
        astParser.setKind(ASTParser.K_COMPILATION_UNIT);
        astParser.setBindingsRecovery(true);
        astParser.setStatementsRecovery(true);
        return astParser;
    }
}
