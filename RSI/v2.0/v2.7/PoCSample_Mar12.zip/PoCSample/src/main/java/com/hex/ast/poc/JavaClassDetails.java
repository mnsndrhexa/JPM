package com.hex.ast.poc;

import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@ToString
public class JavaClassDetails {
    private String className;
    private String classFilePath;
    private String packageName;
    private List<String> importStatements = new ArrayList<>();
    private List<String> interfaceNames = new ArrayList<>();
    private Map<String, String> instanceVariables = new HashMap<>();
    private String extendClassName;
}
