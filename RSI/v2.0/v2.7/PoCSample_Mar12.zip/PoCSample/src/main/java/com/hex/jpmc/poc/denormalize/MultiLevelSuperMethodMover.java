package com.hex.jpmc.poc.denormalize;

import org.eclipse.jdt.core.ToolFactory;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jdt.core.formatter.CodeFormatter;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

import java.io.*;
import java.util.*;

public class MultiLevelSuperMethodMover {

    public static void main(String[] args) throws IOException {
        // Paths to the source files of the classes in the hierarchy
        String[] classPaths = {
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\ExpressOnlineBaseGenericMutator.java",  // Top-level parent
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\ExpressOnlineGenericMutator.java",  // Intermediate parent
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java"   // Last child
        };

        // Parse all classes in the hierarchy
        List<CompilationUnit> classUnits = new ArrayList<>();
        for (String classPath : classPaths) {
            classUnits.add(parseJavaFile(classPath));
        }

        // Collect methods with `super()` calls and their dependencies
        Map<MethodDeclaration, Set<BodyDeclaration>> dependencies = new HashMap<>();
        Set<ImportDeclaration> importsToMove = new HashSet<>();
        for (int i = 0; i < classUnits.size() - 1; i++) { // Exclude the last child
            CompilationUnit parentCU = classUnits.get(i);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    Set<BodyDeclaration> dependentElements = resolveDependencies(parentClass, method);
                    dependencies.put(method, dependentElements);
                    importsToMove.addAll(collectImports(parentCU, dependentElements));
                }
            }
        }

        // Add all collected methods, fields, and imports to the last child class
        CompilationUnit lastChildCU = classUnits.get(classUnits.size() - 1);
        TypeDeclaration lastChildClass = (TypeDeclaration) lastChildCU.types().get(0);
        AST ast = lastChildCU.getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);

        for (Map.Entry<MethodDeclaration, Set<BodyDeclaration>> entry : dependencies.entrySet()) {
            MethodDeclaration method = entry.getKey();
            String newMethodName = method.getName().getIdentifier() + "_Child";

            // Rename the method and replace `super()` calls
            MethodDeclaration renamedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
            renamedMethod.setName(ast.newSimpleName(newMethodName));
            replaceSuperCalls(rewriter, renamedMethod, newMethodName);

            // Add the renamed method to the child class
            ListRewrite listRewrite = rewriter.getListRewrite(lastChildClass, TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
            listRewrite.insertLast(renamedMethod, null);

            // Add dependent elements (fields, methods)
            for (BodyDeclaration dependent : entry.getValue()) {
                if (!alreadyExists(lastChildClass, dependent)) {
                    BodyDeclaration copiedDependent = (BodyDeclaration) ASTNode.copySubtree(ast, dependent);
                    listRewrite.insertLast(copiedDependent, null);
                }
            }
        }

        // Add imports to the last child class
        for (ImportDeclaration importDecl : importsToMove) {
            ImportDeclaration copiedImport = (ImportDeclaration) ASTNode.copySubtree(ast, importDecl);
            ListRewrite importRewrite = rewriter.getListRewrite(lastChildCU, CompilationUnit.IMPORTS_PROPERTY);
            importRewrite.insertLast(copiedImport, null);
        }

        // Remove `extends ParentClass` from the child class
        rewriter.set(lastChildClass, TypeDeclaration.SUPERCLASS_TYPE_PROPERTY, null, null);

        // Apply the changes and write back to the file system
        writeJavaFile(classPaths[classPaths.length - 1], lastChildCU, rewriter);

        // Optionally, remove methods and fields from parent classes and write back
        for (int i = 0; i < classUnits.size() - 1; i++) {
            CompilationUnit parentCU = classUnits.get(i);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
            rewriter = ASTRewrite.create(parentCU.getAST());
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    rewriter.remove(method, null);
                }
            }
            writeJavaFile(classPaths[i], parentCU, rewriter);
        }
    }

    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8); // Use JLS8
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    private static void writeJavaFile(String filePath, CompilationUnit cu, ASTRewrite rewriter) throws IOException {
        Document document = new Document(readFile(filePath));
        TextEdit edits = rewriter.rewriteAST(document, null);
        try {
            edits.apply(document);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Format the updated source code
        String formattedCode = formatCode(document.get());
        FileWriter writer = new FileWriter(new File(filePath.replace(".java", "New.java")));
        writer.write(formattedCode);
        writer.close();
    }

    private static String formatCode(String source) {
        CodeFormatter formatter = ToolFactory.createCodeFormatter(null);
        TextEdit edit = formatter.format(CodeFormatter.K_COMPILATION_UNIT, source, 0, source.length(), 0, null);
        if (edit != null) {
            Document document = new Document(source);
            try {
                edit.apply(document);
                return document.get();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return source; // Return unformatted code if formatting fails
    }

    private static boolean containsSuperCall(MethodDeclaration method) {
        final boolean[] hasSuperCall = {false};
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                hasSuperCall[0] = true;
                return false; // No need to visit further
            }
        });
        return hasSuperCall[0];
    }

    private static void replaceSuperCalls(ASTRewrite rewriter, MethodDeclaration method, String newMethodName) {
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                AST ast = method.getAST();
                MethodInvocation newInvocation = ast.newMethodInvocation();
                newInvocation.setName(ast.newSimpleName(newMethodName));
                rewriter.replace(node, newInvocation, null);
                return false;
            }
        });
    }

    private static boolean alreadyExists(TypeDeclaration targetClass, BodyDeclaration declaration) {
        if (declaration instanceof MethodDeclaration) {
            String methodName = ((MethodDeclaration) declaration).getName().getIdentifier();
            for (MethodDeclaration method : targetClass.getMethods()) {
                if (method.getName().getIdentifier().equals(methodName)) {
                    return true;
                }
            }
        } else if (declaration instanceof FieldDeclaration) {
            FieldDeclaration field = (FieldDeclaration) declaration;
            String fieldName = field.fragments().get(0).toString();
            for (FieldDeclaration targetField : targetClass.getFields()) {
                if (targetField.fragments().get(0).toString().equals(fieldName)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static Set<BodyDeclaration> resolveDependencies(TypeDeclaration parentClass, MethodDeclaration method) {
        Set<BodyDeclaration> dependencies = new HashSet<>();
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(MethodInvocation node) {
                String methodName = node.getName().getIdentifier();
                for (MethodDeclaration parentMethod : parentClass.getMethods()) {
                    if (parentMethod.getName().getIdentifier().equals(methodName)) {
                        dependencies.add(parentMethod);
                    }
                }
                return true;
            }

            @Override
            public boolean visit(SimpleName node) {
                String name = node.getIdentifier();
                for (FieldDeclaration field : parentClass.getFields()) {
                    String fieldName = field.fragments().get(0).toString();
                    if (fieldName.equals(name)) {
                        dependencies.add(field);
                    }
                }
                return true;
            }
        });
        return dependencies;
    }

    private static Set<ImportDeclaration> collectImports(CompilationUnit cu, Set<BodyDeclaration> declarations) {
        Set<ImportDeclaration> imports = new HashSet<>();
        for (ImportDeclaration importDecl : (List<ImportDeclaration>) cu.imports()) {
            for (BodyDeclaration declaration : declarations) {
                if (importDecl.toString().contains(declaration.toString())) {
                    imports.add(importDecl);
                }
            }
        }
        return imports;
    }
}