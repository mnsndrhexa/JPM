package com.hex.jpmc.poc;

import com.hex.model.ProcessDataDescriptor;
import com.hex.model.ProcessFlow;
import com.hex.model.ResultCode;
import com.hex.model.ResultCodes;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

public class SimpleTemplateEngine {

    public String generateClass(String className, ProcessFlow processFlow) throws IOException {
        String generatedClass = "";
        if (processFlow != null) {
            List<ProcessDataDescriptor> pddList = processFlow.getProcessDataDescriptor();
            String packageName = "com.hex";
            String initiatingMethodName = String.valueOf(pddList.get(0).getStep());
            String imports = generateImports();
            String annotations = generateAnnotations(pddList);
            String methods = generateMethods(pddList);
            generateClassFromTemplate(packageName, className, initiatingMethodName, imports, annotations, methods);
        }
        return generatedClass;
    }

    public String generateImports() {
        StringBuilder importsBuilder = new StringBuilder();
        importsBuilder.append("import ").append("org.springframework.beans.factory.annotation.Autowired").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("org.springframework.stereotype.Component").append(";").append(System.lineSeparator());
        return importsBuilder.toString();
    }

    public String generateAnnotations(List<ProcessDataDescriptor> pddList) {
        StringBuilder annotationsBuilder = new StringBuilder();
        for (ProcessDataDescriptor pdd : pddList) {
            String className = pdd.getClassName();
            String variableName = className.substring(className.lastIndexOf("."));
            variableName = Character.toLowerCase(variableName.charAt(0)) + variableName.substring(1);
            annotationsBuilder.append("\t@Autowired").append(System.lineSeparator());
            annotationsBuilder.append("\tprivate ").append(className).append(" ").append(variableName).append(";").append(System.lineSeparator());
        }
        return annotationsBuilder.toString();
    }

    public String generateMethods(List<ProcessDataDescriptor> pddList) {
        StringBuilder methodBuilder = new StringBuilder();
        // Add methods with dynamic if-else conditions
        for (ProcessDataDescriptor pdd : pddList) {
            String methodName = String.valueOf(pdd.getStep());
            ResultCodes condition = pdd.getResultCodes();

            methodBuilder.append("\tpublic void ").append(methodName).append("() {").append(System.lineSeparator());
            int index = 0;
            String className = pdd.getClassName();
            String variableName = Character.toLowerCase(className.charAt(0)) + className.substring(1);
//            if (pdd.getUOWProcess() != null) {
//                methodBuilder.append("\t\t");
//            }
            methodBuilder.append("\t\tint response = ").append(variableName).append(".execute()").append(";").append(System.lineSeparator());
            for (ResultCode rc : condition.getResultCode()) {
                String conditionExpression = "response == ".concat(String.valueOf(rc.getCode()));
                if (index == 0) {
                    methodBuilder.append("\t\tif (").append(conditionExpression).append(") {").append(System.lineSeparator());
                } else {
                    methodBuilder.append("\t\telse if (").append(conditionExpression).append(") {").append(System.lineSeparator());
                }
                Integer returnCode = rc.getNextStep().intValue();
                if (returnCode != 14)
                    methodBuilder.append("\t\t\t").append(returnCode).append("();").append(System.lineSeparator());
                else
                    methodBuilder.append("\t\t\treturn;").append(System.lineSeparator());
                methodBuilder.append("\t\t}").append(System.lineSeparator());
                index++;
            }
            methodBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());
        }

        return methodBuilder.toString();
    }

    public void generateClassFromTemplate(String packageName, String className, String initiatingMethodName, String imports, String annotations, String methods) throws IOException {
        File templateLocation = new File("C:\\Amaze\\lib\\templates\\JPMC\\config\\java_template.txt");
        Path filePath = Paths.get(templateLocation.getAbsolutePath());

        String content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));

        // Define the package
        content = StringUtils.replace(content,"$PACKAGE_NAME$", packageName);

        // Define the imports
        content = StringUtils.replace(content,"$IMPORTS$", imports);

        // Define the class template
        StringBuilder classBuilder = new StringBuilder();
        classBuilder.append("@Component").append(System.lineSeparator());
        classBuilder.append("public class ").append(className).append(" {").append(System.lineSeparator());
        content = StringUtils.replace(content, "$CLASS_DEF$", classBuilder.toString());

        // Define the annotations
        content = StringUtils.replace(content, "$ANNOTATIONS$", annotations);

        // Define the initiating method
        classBuilder = new StringBuilder();
        classBuilder.append("\tpublic void execute() {").append(System.lineSeparator());
        classBuilder.append("\t\t").append(initiatingMethodName).append("();").append(System.lineSeparator());
        classBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());
        content = StringUtils.replace(content, "$INITIATOR_METHOD$", classBuilder.toString());

        // Define the child methods from ProcessDataDescriptor
        content = StringUtils.replace(content,"$METHODS$", methods);

        // Write the modified content back to the file
        // Create a FileWriter to write the DOT file
        Files.write(Paths.get("C:\\Users\\1000022257\\Desktop\\" + className.concat(".java")), content.getBytes(StandardCharsets.UTF_8));
    }

    public String generateClass(String packageName, String className, String initiatingMethodName, String imports, String annotations, String methods) {
        StringBuilder classBuilder = new StringBuilder();

        // Define the package
        classBuilder.append("package ").append(packageName).append(";").append(System.lineSeparator()).append(System.lineSeparator());

        // Define the imports
        classBuilder.append(imports).append(System.lineSeparator()).append(System.lineSeparator());

        // Define the class template
        classBuilder.append("@Component").append(System.lineSeparator());
        classBuilder.append("public class ").append(className).append(" {").append(System.lineSeparator()).append(System.lineSeparator());

        // Define the annotations
        classBuilder.append(annotations).append(System.lineSeparator());

        // Define the initiating method
        classBuilder.append("\tpublic void execute() {").append(System.lineSeparator());
        classBuilder.append("\t\t").append(initiatingMethodName).append("();").append(System.lineSeparator());
        classBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());

        // Define the child methods from ProcessDataDescriptor
        classBuilder.append(methods);

        classBuilder.append("}").append(System.lineSeparator());
        return classBuilder.toString();
    }

}
