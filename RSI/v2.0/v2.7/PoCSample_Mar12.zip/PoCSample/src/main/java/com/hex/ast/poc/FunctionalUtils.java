package com.hex.ast.poc;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import static org.apache.commons.lang3.StringUtils.*;

public class FunctionalUtils {
	private static Map<String,String> dtStyleFrmtMap = new HashMap<>();
	
	public FunctionalUtils() {
		
	}

	private static final String NEWLINE_STR = "\r\n";
	private static Logger logger = LogManager.getLogger(FunctionalUtils.class);

	public static String insertString(String originalString, String stringToBeInserted, int index) {
		StringBuffer originalWord = new StringBuffer(originalString);
		originalWord.insert(index, stringToBeInserted);
		return originalWord.toString();
	}
	
	public static String insertStmt(String target, String snippet, int index) {
//		StringBuilder result = new StringBuilder();
//		for (int i = 0; i < target.length(); i++) {
//			if (i == index) {
//				result.append(snippet);
//			}
//			result.append(target.charAt(i));
//		}
//		return result.toString();
		return target.substring(0, index) + snippet + target.substring(index); 	
	}

	public static String getName(String script, String prefix, String suffix) {
		if(!prefix.endsWith(" ")) {
			prefix = prefix + " ";
		}
		script = script + " ";
		
		if (prefix.trim().equalsIgnoreCase("ON")) {
			if (!containsIgnoreCase(script, prefix)) {
				if (containsIgnoreCase(script, " "+prefix.trim()+System.lineSeparator())) {
					prefix = " "+prefix.trim()+System.lineSeparator();
				} else if (containsIgnoreCase(script, System.lineSeparator()+prefix.trim()+" ")) {
					prefix = System.lineSeparator()+prefix.trim()+" ";
				} else if (containsIgnoreCase(script, System.lineSeparator()+prefix.trim()+System.lineSeparator())) {
					prefix = System.lineSeparator()+prefix.trim()+System.lineSeparator();
				} else if (containsIgnoreCase(script, "\t"+prefix.trim()+" ")) {
					prefix = "\t"+prefix.trim()+" ";
				} else if (containsIgnoreCase(script, "\t"+prefix.trim()+System.lineSeparator())) {
					prefix = "\t"+prefix.trim()+System.lineSeparator();
				}
			}
		}	

		String secondPart = "";
		if(containsIgnoreCase(script, prefix))
			secondPart = script.substring(indexOfIgnoreCase(script, prefix) + prefix.length(), script.length());
		else	
			secondPart = script;
		secondPart = StringUtils.stripStart(secondPart, " \t\r\n\\v\f");

		String tabName = "";
		if(containsIgnoreCase(secondPart, suffix))
			tabName = secondPart.substring(0, indexOfIgnoreCase(secondPart, suffix));
		else	
			tabName = secondPart;
		tabName = tabName.replace(";", "");
		int schemaInd = indexOf(tabName, ".");
		if (schemaInd > 0)
			tabName = split(tabName, '.')[1];
		if (tabName.contains(System.lineSeparator()) || tabName.contains("\n"))
			tabName = tabName.split("\r?\n|\r")[0];
		if(tabName.contains("(")) 
			tabName = substring(tabName, 0, indexOf(tabName,"("));
		if (tabName.contains("]") && !tabName.trim().endsWith("]"))
			tabName = tabName.substring(0, tabName.indexOf("]"));
		if (tabName.indexOf("\"",1) > 0 && !tabName.trim().endsWith("\""))
			tabName = tabName.substring(0, tabName.indexOf("\"",1));
		tabName = tabName.replace("\"", "");
		tabName = tabName.replace("[", "").replace("]", "").trim();
		return tabName;
	}

	public static String getNameForMSSQL(String script, String prefix, String suffix) {
		if(!prefix.endsWith(" ")) {
			prefix = prefix + " ";
		}
		script = script + " ";

		String secondPart = "";
		if(containsIgnoreCase(script, prefix))
			secondPart = script.substring(indexOfIgnoreCase(script, prefix) + prefix.length());
		else	
			secondPart = script;
		secondPart = StringUtils.stripStart(secondPart, " \t\r\n\\v\f");
		
		int indxOpenBrkt = secondPart.indexOf(".[");
		int indxDblQte = secondPart.indexOf(".\"");
		if (indxOpenBrkt > 0 && secondPart.indexOf("]",indxOpenBrkt) > 0) 
			return secondPart.substring(indxOpenBrkt+2, secondPart.indexOf("]",indxOpenBrkt));
		else if (indxDblQte > 0 && secondPart.indexOf("\"",indxDblQte+2) > 0) 
			return secondPart.substring(indxDblQte+2, secondPart.indexOf("\"",indxDblQte+2));

		String tabName = "";
		if(containsIgnoreCase(secondPart, suffix))
			tabName = secondPart.substring(0, indexOfIgnoreCase(secondPart, suffix));
		else	
			tabName = secondPart;
		tabName = tabName.replace(";", "");
		if (indexOf(tabName, ".") > 0)
			tabName = split(tabName, '.')[1];
		if (tabName.contains(System.lineSeparator()) || tabName.contains("\n"))
			tabName = tabName.split("\r?\n|\r")[0];
		if (tabName.contains("]") && !tabName.trim().endsWith("]"))
			tabName = tabName.substring(0, tabName.indexOf("]"));
		if (tabName.indexOf("\"",1) > 0 && !tabName.trim().endsWith("\""))
			tabName = tabName.substring(0, tabName.indexOf("\"",1));
		tabName = tabName.replace("\"", "");
		tabName = tabName.replace("[", "").replace("]", "").trim();
		return tabName;
	}

	public static String getDBObjName(String script, String prefix) {
		if(!prefix.endsWith(" ")) {
			prefix = prefix + " ";
		}
		script = script + " ";
		String secondPart = script.substring(indexOfIgnoreCase(script, prefix) + prefix.length(), script.length());
		String dbObjName = StringUtils.stripStart(secondPart, " \t\r\n\\v\f");

		if(dbObjName.contains("(")) 
			dbObjName = substring(dbObjName, 0, indexOf(dbObjName,"("));
		if(dbObjName.contains("\r")) 
			dbObjName = substring(dbObjName, 0, indexOf(dbObjName,"\r")); 
		if(dbObjName.contains("\n")) 
			dbObjName = substring(dbObjName, 0, indexOf(dbObjName,"\n")); 
		if(containsIgnoreCase(dbObjName, "RETURN")) 
			dbObjName = substring(dbObjName, 0, indexOfIgnoreCase(dbObjName,"RETURN")).trim(); 
		if(containsIgnoreCase(dbObjName, " AS")) 
			dbObjName = substring(dbObjName, 0, indexOfIgnoreCase(dbObjName," AS")).trim(); 
		
		dbObjName = dbObjName.replace(";", "");
		if (dbObjName.contains("."))
			dbObjName = split(dbObjName, '.')[1];
		dbObjName = dbObjName.replace("\"", "");
		dbObjName = dbObjName.replace("[", "").replace("]", "").trim();
		return dbObjName;
	}
	
	public static String addTextAtEndOfTableDef(String tableDefScript, String text) {	
		int indxClosingBrkt = findMatchingCloseBracket(tableDefScript);
		tableDefScript = tableDefScript.substring(0,indxClosingBrkt+1) + text + tableDefScript.substring(indxClosingBrkt+1);
		return tableDefScript;
	}
	
	public static String removeTextAtEndOfTableDef(String tableDefScript) {	
		int indxClosingBrkt = findMatchingCloseBracket(tableDefScript);
		tableDefScript = tableDefScript.substring(0,indxClosingBrkt+1) + ";";
		return tableDefScript;
	}

	public static String removePrecisionInDatatype(String script, String dataType) {
		if (containsIgnoreCase(script, dataType)) {
			String bfrDataType = script.substring(0, 
					script.toLowerCase().lastIndexOf(dataType.toLowerCase()));
			String aftrDataType = script.substring(
					script.toLowerCase().lastIndexOf(dataType.toLowerCase())+dataType.length());

			if (aftrDataType.trim().startsWith("(") && aftrDataType.contains(")"))
				aftrDataType = aftrDataType.substring(aftrDataType.indexOf(")")+1);
			script = bfrDataType + dataType.toUpperCase() + aftrDataType;
		}
		return script;
	}

	public static String removeSingleQuoteInAlias(String script) {
		String strAliasName = script.substring(indexOfIgnoreCase(script," AS '")+5);
		if (strAliasName.contains(System.lineSeparator()))
			strAliasName = strAliasName.substring(0, strAliasName.indexOf(System.lineSeparator()));
		else if (strAliasName.contains("\n"))
			strAliasName = strAliasName.substring(0, strAliasName.indexOf("\n"));
		
		if (strAliasName.contains(" "))
			strAliasName = strAliasName.substring(0, strAliasName.indexOf(" "));		
		strAliasName = strAliasName.replace("'","");
		
		script = replaceIgnoreCase(script, " AS '"+strAliasName+"'", " AS "+strAliasName);		
		return script;
	}
	
//	public static String findDBObjVal(String scriptTbl, String objType) {
//		String objInst = "";
//		String tmpLine = "";
//		if (scriptTbl.toLowerCase().contains(objType.toLowerCase()))
//			tmpLine = scriptTbl.substring(
//					scriptTbl.toLowerCase().indexOf(objType.toLowerCase())+objType.length()).trim();
//		
//		if(tmpLine.contains(" "))
//			tmpLine = tmpLine.substring(0,tmpLine.indexOf(" "));
//		if(tmpLine.contains(","))
//			tmpLine = tmpLine.substring(0,tmpLine.indexOf(","));
//		if(tmpLine.contains(";"))
//			tmpLine = tmpLine.substring(0,tmpLine.indexOf(";"));
//		if(tmpLine.contains(System.lineSeparator()))
//			tmpLine = tmpLine.substring(0,tmpLine.indexOf(System.lineSeparator()));
//		objInst = tmpLine;
//		
//		scriptTbl = scriptTbl.replaceAll("(?i)"+objType+" ", "");
//		scriptTbl = scriptTbl.replace(objInst, "");
//		
//		return scriptTbl;
//	}

	public void createAndWriteFile(String location, String fileName, String content) throws IOException {
		Path path = Paths.get(location);
		if (Files.notExists(path, new LinkOption[] { LinkOption.NOFOLLOW_LINKS })) {
	        path = Files.createDirectories(path).toFile().toPath();
	    }
		path = Paths.get(path.toString() + File.separator + fileName.trim() + ".sql");
		Files.write(path, content.getBytes());
	}

	public void createFileWithContent(List<String> tableScripts, String fileWithPath, boolean isAppend) throws IOException {
        Path file = Paths.get(fileWithPath);
		if (Files.notExists(file, new LinkOption[] { LinkOption.NOFOLLOW_LINKS })) {
			file = Files.createFile(file).toFile().toPath();
		}
        if (isAppend){
            Files.write(file, tableScripts, StandardOpenOption.APPEND);
        } else {
            Files.write(file, tableScripts);
        }
    }

	public void writeToFile(String location, String fileName, String content, boolean isAppend) throws IOException {
        String fileWithPath = location + File.separator + fileName + ".sql";
        Path file = Paths.get(fileWithPath);
        if (isAppend){
            Files.write(file, content.getBytes(), StandardOpenOption.APPEND);
        } else {
            Files.write(file, content.getBytes());
        }
    }

	public static String getExceptionStackTrace(Exception e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

	public void writeMigratedDBObjects(String migratedDDLPath, String schemaFolder, String ddlFile, 
			String script, String objectName) throws IOException {
		createAndWriteFile(migratedDDLPath, objectName, script);
		if(ddlFile != null) {
			writeToFile(schemaFolder, ddlFile, script, true);
			writeToFile(schemaFolder, ddlFile, String.join(System.lineSeparator(), NEWLINE_STR), true);
		}
	}

	public void writeMigratedConstraints(List<String> constraintScripts, String fileWithPath, String schemaFolder, String ddlFile) throws IOException {
		createFileWithContent(constraintScripts, fileWithPath, true);
		String folderFilename = substring(fileWithPath, indexOfIgnoreCase(fileWithPath, "DDL"+File.separator) + 4);
		if(containsIgnoreCase(folderFilename, "Tables")) {
			writeToFile(schemaFolder, ddlFile, String.join(System.lineSeparator(), constraintScripts), true);
			writeToFile(schemaFolder, ddlFile, String.join(System.lineSeparator(), NEWLINE_STR), true);
		}
	}
	
	public static String getNamesCorrected(String name) {
		name = trim(name);
		name = replaceIgnoreCase(name, "^", "_");
		name = replaceIgnoreCase(name, "<", "_");
		name = replaceIgnoreCase(name, "/", "_");
		name = replaceIgnoreCase(name, "*", "_");
		name = replaceIgnoreCase(name, "#", "_");
		name = replaceIgnoreCase(name, "$", "_");
		name = replaceIgnoreCase(name, "+", "_");
		name = replaceIgnoreCase(name, "!", "_");
		name = replaceIgnoreCase(name, "%", "_");
		name = replaceIgnoreCase(name, ">", "_");
		name = replaceIgnoreCase(name, "`", "_");
		name = replaceIgnoreCase(name, "'", "_");
		name = replaceIgnoreCase(name, "|", "_");
		name = replaceIgnoreCase(name, "{", "_");
		name = replaceIgnoreCase(name, "}", "_");
		name = replaceIgnoreCase(name, "?", "_");
		name = replaceIgnoreCase(name, "\"", "_");
		name = replaceIgnoreCase(name, "=", "_");
		name = replaceIgnoreCase(name, ":", "_");
		name = replaceIgnoreCase(name, "@", "_");
		name = replaceIgnoreCase(name, " ", "_");
		name = replaceIgnoreCase(name, "\n", "_");
		return name;
	}

	public static void createDBExcelFile(String location, String fileName, String[] headers, HashMap<String,HashSet<String>> appMap) {
		try (OutputStream fileOut = new FileOutputStream(location + fileName)) {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("ApplicationMapping");

			CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
			cellStyle.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
			cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			cellStyle.setFont(workbook.createFont());

			// Create a Row
			Row headerRow = sheet.createRow(0);
			for (int rn=0; rn<headers.length; rn++) {
				Cell cell = headerRow.createCell(rn);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(headers[rn]);
			}

			int rowNo = 0;
			Iterator<String> appMappingItr = appMap.keySet().iterator();
			while (appMappingItr.hasNext()) {
				rowNo++;
				String appName = appMappingItr.next();
				Row r = sheet.createRow(rowNo);
				r.createCell(0).setCellValue(appName);
				String concateSchemas = String.join(",", appMap.get(appName));
				r.createCell(1).setCellValue(concateSchemas);
			}

			// Resize all columns to fit the content size
	        for(int i = 0; i < headers.length; i++) {
	            sheet.autoSizeColumn(i);
	        }
			workbook.write(fileOut);
			workbook.close();
		} catch(IOException e) {
			logger.error("Exception while creating DB excel file: " + e.getMessage());
		}
	}

	public static void createCRUDExcelFile(String location, String fileName, String[] headers, List<AppTableMapping> appMap) {
		try (OutputStream fileOut = new FileOutputStream(location + fileName)) {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("ApplicationMapping");

			CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
			cellStyle.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
			cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			cellStyle.setFont(workbook.createFont());

			// Create a Row
			Row headerRow = sheet.createRow(0);
			for (int rn=0; rn<headers.length; rn++) {
				Cell cell = headerRow.createCell(rn);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(headers[rn]);
			}

			int rowNo = 0;
			for (AppTableMapping app : appMap) {
				rowNo++;
				Row r = sheet.createRow(rowNo);
				r.createCell(0).setCellValue(app.getClassName());
				r.createCell(1).setCellValue(app.getTableName());
				r.createCell(2).setCellValue(app.getCrudOperation());
			}
			// Resize all columns to fit the content size
	        for(int i = 0; i < headers.length; i++) {
	            sheet.autoSizeColumn(i);
	        }
			workbook.write(fileOut);
			workbook.close();
		} catch(IOException e) {
			logger.error("Exception while creating DB excel file: " + e.getMessage());
		}
	}

	public static String formatTextForSearching(String script, String word) {		
		script = replaceIgnoreCase(script, System.lineSeparator()+word, System.lineSeparator()+" "+word);
		script = replaceIgnoreCase(script, "\n"+word, "\n "+word);
		script = replaceIgnoreCase(script, "\r"+word, "\r "+word);
		script = replaceIgnoreCase(script, "\t"+word, "\t "+word);
		script = replaceIgnoreCase(script, word+System.lineSeparator(), word+" "+System.lineSeparator());
		script = replaceIgnoreCase(script, word+"\n", word+" \n");
		script = replaceIgnoreCase(script, word+"\r", word+" \r");
		script = replaceIgnoreCase(script, word+"\t", word+" \t");
		
		return script;
	}
	
	public static String handleCreateTempTable(String script) {		
		if (containsIgnoreCase(script, "CREATE TABLE #")) {
			String firstPart = script.substring(0, indexOfIgnoreCase(script, "CREATE TABLE #"));					
			String nextPart = script.substring(indexOfIgnoreCase(script, "CREATE TABLE #")+14);
			
			nextPart = addTextAtEndOfTableDef(nextPart, " ON COMMIT DROP ");
			script = firstPart + "CREATE TEMP TABLE " + nextPart;
		}
		return script;
	}
	
	public static String convertDBSystemFunctions(String script, String funcName) {		
		if (containsIgnoreCase(script, funcName) && script.contains("(") && script.contains(")")) {
			String orgFunc = script.substring(indexOfIgnoreCase(script, funcName));
			int indxClosingBrkt = findMatchingCloseBracket(orgFunc);
			orgFunc = orgFunc.substring(0, indxClosingBrkt+1);

			if (orgFunc.contains(",")) {
				String param1 = substring(orgFunc, orgFunc.indexOf("(")+1, orgFunc.indexOf(",")).trim();
				String param2 = substring(orgFunc, orgFunc.indexOf(",")+1, indxClosingBrkt).trim();
				String param3 = param2;
				if (param3.contains(",") && (funcName.equalsIgnoreCase("DATEADD")
						|| funcName.equalsIgnoreCase("DATEDIFF")
						|| funcName.equalsIgnoreCase("IIF"))) {
					param2 = substring(param3, 0, param3.indexOf(",")).trim();
					param3 = substring(param3, param3.indexOf(",")+1).trim();
				}
				
				String replaceFunc = "";
			//	if (funcName.equalsIgnoreCase("CONVERT"))
			//		replaceFunc = "CAST(" + param2 + " AS " + param1 + ")";
			//	else 
				if (funcName.equalsIgnoreCase("CHARINDEX"))
					replaceFunc = "STRPOS(" + param2 + ", " + param1 + ")";
				else if (funcName.equalsIgnoreCase("LOCATE"))
					replaceFunc = "POSITION(" + param1 + " IN " + param2 + ")";
				else if (funcName.equalsIgnoreCase("IDENTITY"))
					replaceFunc = "GENERATED ALWAYS AS IDENTITY(START WITH " + param1 + " INCREMENT BY " + param2 + ")";
				else if (funcName.equalsIgnoreCase("DATEPART"))
					replaceFunc = "DATE_PART('" + param1 + "', " + param2 + ")";
				else if (funcName.equalsIgnoreCase("DATEADD")) {
					if (param1.equalsIgnoreCase("'dd'") || param1.equalsIgnoreCase("dd"))
						param1 = "day";
					else if (param1.equalsIgnoreCase("'mm'") || param1.equalsIgnoreCase("mm"))
						param1 = "month";
					else if (param1.equalsIgnoreCase("'yy'") || param1.equalsIgnoreCase("yy"))
						param1 = "year";
					else if (param1.equalsIgnoreCase("'hh'") || param1.equalsIgnoreCase("hh"))
						param1 = "hour";
					else if (param1.equalsIgnoreCase("'mi'") || param1.equalsIgnoreCase("mi"))
						param1 = "minute";
					else if (param1.equalsIgnoreCase("'ss'") || param1.equalsIgnoreCase("ss"))
						param1 = "second";
					replaceFunc = param3 + " + INTERVAL '" + param2 + " " + param1 + "'";
				} else if (funcName.equalsIgnoreCase("DATEDIFF"))
					replaceFunc = "EXTRACT(" + param1 + " FROM " + param3 + " - " + param2 + ")";
				else if (funcName.equalsIgnoreCase("IIF"))
					replaceFunc = "CASE WHEN " + param1 + " THEN " + param2 + " ELSE " + param3 + " END";
					
				script = script.replace(orgFunc, replaceFunc);
			}
		}
		return script;
	}
	
	public static String transformDBFunctionConvert(String scriptLine) {
		if (containsIgnoreCase(scriptLine, "CONVERT")) {
			StringBuilder builder = new StringBuilder();
			String[] splits = scriptLine.split("CONVERT");
			builder.append(splits[0]);
			if (splits.length > 1) {
				for (int j = 1; j < splits.length; j++) {
					String convrtPart = splits[j];
					if (convrtPart.contains("(") && convrtPart.contains(")") 
							&& convrtPart.indexOf(')') > convrtPart.indexOf('(')) {
						int indxClosingBrkt = findMatchingCloseBracket(convrtPart);			
						String params = convrtPart.substring(convrtPart.indexOf('(') + 1, indxClosingBrkt);
						String afterFunc = convrtPart.substring(indxClosingBrkt);
						if (params.contains(",")) {
							String param1 = "";
							String param2 = "";
							if (params.contains(")") &&  (params.indexOf(",") < params.indexOf(")"))
									&& (params.indexOf(",", params.indexOf(")")) > 0)) {
								param1 = params.substring(0, params.indexOf(",", params.indexOf(")"))).trim();
								param2 = params.substring(params.indexOf(",", params.indexOf(")"))+1).trim();
							} else {
								param1 = params.substring(0, params.indexOf(',')).trim();
								param2 = params.substring(params.indexOf(',')+1).trim();
							}
							String param3 = param2;
							if (param3.contains(",")) {
								param2 = substring(param3, 0, param3.indexOf(",")).trim();
								param3 = substring(param3, param3.indexOf(",")+1).trim();
								
								if (containsIgnoreCase(param1, "CHAR")) {
									String newParam3 = convertStyleToDateFormat(param3);
									if (isBlank(newParam3))
										newParam3 = param3;
									builder.append("TO_CHAR(").append(param2).append(",'")
											.append(newParam3).append("'").append(afterFunc);
								} else if (containsIgnoreCase(param1, "DATE")) {
									String newParam3 = convertStyleToDateFormat(param3);
									if (isBlank(newParam3))
										newParam3 = param3;
									builder.append("TO_TIMESTAMP(").append(param2).append(",'")
											.append(newParam3).append("'").append(afterFunc);
								} else {
									builder.append("CAST(").append(param2).append(param3).append(" AS ").append(param1)
											.append(afterFunc);
								}
							} else {
								builder.append("CAST(").append(param2).append(" AS ").append(param1)
										.append(afterFunc);
							}
						}
					} else {
						builder.append("CAST").append(convrtPart);
					}
				}
			}
			scriptLine = builder.toString();
		}
		return scriptLine;
	}

	private static String convertStyleToDateFormat(String dtStyle) {
		if (dtStyleFrmtMap.isEmpty()) {
			dtStyleFrmtMap.put("101", "MM/DD/YYYY");
			dtStyleFrmtMap.put("110", "MM-DD-YYYY");      // 32
			dtStyleFrmtMap.put("32", "MM-DD-YYYY");
			dtStyleFrmtMap.put("111", "YYYY/MM/DD");
			dtStyleFrmtMap.put("23", "YYYY-MM-DD");
			dtStyleFrmtMap.put("121", "YYYY-MM-DD HH24:MI:SSxFF3");	 // 25
			dtStyleFrmtMap.put("25", "YYYY-MM-DD HH24:MI:SSxFF3");
			dtStyleFrmtMap.put("120", "YYYY-MM-DD HH24:MI:SS");        // 20
			dtStyleFrmtMap.put("20", "YYYY-MM-DD HH24:MI:SS");
			dtStyleFrmtMap.put("27", "MM-DD-YYYY HH24:MI:SSxFF3");
			dtStyleFrmtMap.put("114", "HH24:MI:SSxFF3");     // 14
			dtStyleFrmtMap.put("14", "HH24:MI:SSxFF3");
			dtStyleFrmtMap.put("108", "HH24:MI:SS");      // 24, 8
			dtStyleFrmtMap.put("24", "HH24:MI:SS");
			dtStyleFrmtMap.put("8", "HH24:MI:SS");
			dtStyleFrmtMap.put("113", "DD Mon YYYY HH24:MI:SSxFF3");
			dtStyleFrmtMap.put("106", "DD Mon YYYY");
			dtStyleFrmtMap.put("109", "Mon DD YYYY HH24:MI:SSxFF3");
			dtStyleFrmtMap.put("100", "Mon DD YYYY HH24:MI");
			dtStyleFrmtMap.put("107", "Mon DD, YYYY");
			dtStyleFrmtMap.put("1", "MM/DD/YY");
			dtStyleFrmtMap.put("10", "MM-DD-YY");
			dtStyleFrmtMap.put("11", "YY/MM/DD");
			dtStyleFrmtMap.put("6", "DD-Mon-YY");
			dtStyleFrmtMap.put("7", "Mon DD, YY");
		}

		String dtFormat = dtStyleFrmtMap.get(dtStyle);
		if (isBlank(dtFormat)) {
			for (Map.Entry<String,String> entFrmtStyl : dtStyleFrmtMap.entrySet()) {
				if (containsIgnoreCase(entFrmtStyl.getKey(), dtStyle)) {
					dtFormat = entFrmtStyl.getValue();
					break;
				}
			}
		}
		
		return dtFormat;
	}
	
	public static int findMatchingCloseBracket(String script) {	
		int indxMatchingBrkt = script.length()-1;
		if(script.contains("(") && script.contains(")")) {				
			int indxOpenBrkt = script.indexOf("(");
			int openBrktsCount = 0;
			for (int i=indxOpenBrkt; i<script.length(); ++i) {
				if(script.charAt(i) == '(') 
					++openBrktsCount;
				else if (script.charAt(i) == ')')
					--openBrktsCount;
				
				if (openBrktsCount == 0) {
					indxMatchingBrkt = i;
					break;
				}
			}	
		}
		return indxMatchingBrkt;
	}

}
