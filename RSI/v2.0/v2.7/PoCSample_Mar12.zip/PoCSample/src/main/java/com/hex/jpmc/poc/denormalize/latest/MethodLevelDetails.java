package com.hex.jpmc.poc.denormalize.latest;

import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class MethodLevelDetails {
    private String classFileName;
    private String superMethodName;
    private boolean superMethodAvailable;
    private Set<String> dependentMethods = new HashSet<>();
}
