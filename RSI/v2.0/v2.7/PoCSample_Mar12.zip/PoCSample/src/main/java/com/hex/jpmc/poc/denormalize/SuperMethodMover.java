package com.hex.jpmc.poc.denormalize;

import org.eclipse.jdt.core.dom.*;
import java.io.*;
import java.util.*;

public class SuperMethodMover {

    public static void main(String[] args) throws IOException {
        // Paths to the source files of the parent and child classes
        String[] classPaths = {
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\ExpressOnlineBaseGenericMutator.java",  // Top-level parent
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\ExpressOnlineGenericMutator.java",  // Intermediate parent
                "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java"   // Last child
        };

        // Parse all classes in the hierarchy
        List<CompilationUnit> classUnits = new ArrayList<>();
        for (String classPath : classPaths) {
            classUnits.add(parseJavaFile(classPath));
        }

        // Collect methods with `super()` calls and their dependencies
        Map<MethodDeclaration, Set<BodyDeclaration>> dependencies = new HashMap<>();
        Set<ImportDeclaration> importsToMove = new HashSet<>();
        for (int i = 0; i < classUnits.size() - 1; i++) { // Exclude the last child
            CompilationUnit parentCU = classUnits.get(i);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    Set<BodyDeclaration> dependentElements = resolveDependencies(parentClass, method);
                    dependencies.put(method, dependentElements);
                    importsToMove.addAll(collectImports(parentCU, dependentElements));
                }
            }
        }

        // Add all collected methods, fields, and imports to the last child class
        CompilationUnit lastChildCU = classUnits.get(classUnits.size() - 1);
        TypeDeclaration lastChildClass = (TypeDeclaration) lastChildCU.types().get(0);
        AST ast = lastChildCU.getAST();

        for (Map.Entry<MethodDeclaration, Set<BodyDeclaration>> entry : dependencies.entrySet()) {
            MethodDeclaration method = entry.getKey();
            String newMethodName = method.getName().getIdentifier() + "_Child";

            // Rename the method and replace `super()` calls
            MethodDeclaration renamedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
            renamedMethod.setName(ast.newSimpleName(newMethodName));
            replaceSuperCalls(renamedMethod, newMethodName);

            // Add the renamed method to the child class
            lastChildClass.bodyDeclarations().add(renamedMethod);

            // Add dependent elements (fields, methods)
            for (BodyDeclaration dependent : entry.getValue()) {
                if (!alreadyExists(lastChildClass, dependent)) {
                    BodyDeclaration copiedDependent = (BodyDeclaration) ASTNode.copySubtree(ast, dependent);
                    lastChildClass.bodyDeclarations().add(copiedDependent);
                }
            }
        }

        // Add imports to the last child class
        for (ImportDeclaration importDecl : importsToMove) {
            ImportDeclaration copiedImport = (ImportDeclaration) ASTNode.copySubtree(ast, importDecl);
            lastChildCU.imports().add(copiedImport);
        }

        // Remove `extends ParentClass` from the child class
        lastChildClass.setSuperclassType(null);

        // Write the updated last child class back to the file system
        writeJavaFile(classPaths[classUnits.size() - 1], lastChildCU);

        // Optionally, remove methods and fields from parent classes and write back
//        for (int i = 0; i < classUnits.size() - 1; i++) {
//            CompilationUnit parentCU = classUnits.get(i);
//            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
//            parentClass.bodyDeclarations().removeIf(declaration -> declaration instanceof MethodDeclaration && containsSuperCall((MethodDeclaration) declaration));
//            writeJavaFile(classPaths[i], parentCU);
//        }
    }

    // Parses a Java source file into a CompilationUnit
    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8); // Use the appropriate Java version
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    // Reads the content of a file into a String
    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    // Writes a CompilationUnit back to a file
    private static void writeJavaFile(String filePath, CompilationUnit compilationUnit) throws IOException {
        String updatedSource = compilationUnit.toString();
        FileWriter writer = new FileWriter(new File(filePath.replace(".java", "New.java")));
        writer.write(updatedSource);
        writer.close();
    }

    // Checks if a method contains a `super()` call
    private static boolean containsSuperCall(MethodDeclaration method) {
        final boolean[] hasSuperCall = {false};
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                hasSuperCall[0] = true;
                return false; // No need to visit further
            }
        });
        return hasSuperCall[0];
    }

    // Replaces `super()` calls with calls to the renamed method
    private static void replaceSuperCalls(MethodDeclaration method, String newMethodName) {
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                AST ast = method.getAST();
                MethodInvocation newInvocation = ast.newMethodInvocation();
                newInvocation.setName(ast.newSimpleName(newMethodName));
                ASTNode parent = node.getParent();
                if (parent instanceof ExpressionStatement) {
                    ((ExpressionStatement) parent).setExpression(newInvocation);
                } else if (parent instanceof ReturnStatement) {
                    ((ReturnStatement) parent).setExpression(newInvocation);
                }
                return false;
            }
        });
    }

    // Checks if a body declaration already exists in the target class
    private static boolean alreadyExists(TypeDeclaration targetClass, BodyDeclaration declaration) {
        if (declaration instanceof MethodDeclaration) {
            String methodName = ((MethodDeclaration) declaration).getName().getIdentifier();
            for (MethodDeclaration method : targetClass.getMethods()) {
                if (method.getName().getIdentifier().equals(methodName)) {
                    return true;
                }
            }
        } else if (declaration instanceof FieldDeclaration) {
            VariableDeclarationFragment fragment = (VariableDeclarationFragment) ((FieldDeclaration) declaration).fragments().get(0);
            String fieldName = fragment.getName().getIdentifier();
            for (FieldDeclaration field : targetClass.getFields()) {
                VariableDeclarationFragment targetFragment = (VariableDeclarationFragment) field.fragments().get(0);
                if (targetFragment.getName().getIdentifier().equals(fieldName)) {
                    return true;
                }
            }
        }
        return false;
    }

    // Resolves dependencies for a given method
    private static Set<BodyDeclaration> resolveDependencies(TypeDeclaration parentClass, MethodDeclaration method) {
        Set<BodyDeclaration> dependencies = new HashSet<>();
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(MethodInvocation node) {
                String methodName = node.getName().getIdentifier();
                for (MethodDeclaration parentMethod : parentClass.getMethods()) {
                    if (parentMethod.getName().getIdentifier().equals(methodName)) {
                        dependencies.add(parentMethod);
                    }
                }
                return true;
            }

            @Override
            public boolean visit(SimpleName node) {
                String name = node.getIdentifier();
                for (FieldDeclaration field : parentClass.getFields()) {
                    VariableDeclarationFragment fragment = (VariableDeclarationFragment) field.fragments().get(0);
                    if (fragment.getName().getIdentifier().equals(name)) {
                        dependencies.add(field);
                    }
                }
                return true;
            }
        });
        return dependencies;
    }

    // Collects imports required for a set of body declarations
    private static Set<ImportDeclaration> collectImports(CompilationUnit cu, Set<BodyDeclaration> declarations) {
        Set<ImportDeclaration> imports = new HashSet<>();
        for (ImportDeclaration importDecl : (List<ImportDeclaration>) cu.imports()) {
            for (BodyDeclaration declaration : declarations) {
                if (importDecl.toString().contains(declaration.toString())) {
                    imports.add(importDecl);
                }
            }
        }
        return imports;
    }
}
