package com.hex.jpmc.poc.denormalize;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ClassRefactorer {

    public static void main(String[] args) throws IOException {
        // Path to the current file to process
        String parentPath = "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample";
        String currentFilePath = "C:\\Users\\1000022257\\Desktop\\Source\\RSI\\ExpressOnlineSample\\src\\main\\java\\com\\jpmc\\spring\\validator\\base\\impl\\ExpressOnlineMutator.java";
        List<Path> pathList;
        try (Stream<Path> stream = Files.walk(Paths.get(parentPath))) {
            pathList = stream.map(Path::normalize).filter(Files::isRegularFile).collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Parse the current class
        CompilationUnit currentCU = parseJavaFile(currentFilePath);
        TypeDeclaration currentClass = (TypeDeclaration) currentCU.types().get(0);

        // Traverse the inheritance chain
        List<ClassInfo> classHierarchy = new ArrayList<>();
        ClassInfo currentClassInfo = new ClassInfo(currentFilePath, currentCU, currentClass);
        classHierarchy.add(currentClassInfo);

        // Dynamically find and process all parent classes
        String parentClassName = getParentClassName(currentClass);
        while (parentClassName != null) {
            String parentFilePath = findClassFile(pathList, parentClassName);
            if (parentFilePath == null) {
                System.out.println("Parent class file not found: " + parentClassName);
                break;
            }

            CompilationUnit parentCU = parseJavaFile(parentFilePath);
            TypeDeclaration parentClass = (TypeDeclaration) parentCU.types().get(0);
            classHierarchy.add(new ClassInfo(parentFilePath, parentCU, parentClass));
            parentClassName = null;
            // Collect only the classes which has super calls, if not we don't need to consider that parent
            for (MethodDeclaration method : parentClass.getMethods()) {
                if (containsSuperCall(method)) {
                    parentClassName = getParentClassName(parentClass);
                    break;
                }
            }
        }

        // Refactor the current class
        if (classHierarchy.size() > 1) { // Only proceed if there is at least one parent class
            refactorClassHierarchy(classHierarchy);
        } else {
            System.out.println("No parent class found. No refactoring needed.");
        }
    }

    private static void refactorClassHierarchy(List<ClassInfo> classHierarchy) throws IOException {
        // Process all intermediate classes (excluding the top-most parent)
        ClassInfo childClassInfo = classHierarchy.get(0);

        // Refactor the child class
        AST ast = childClassInfo.compilationUnit.getAST();
        ASTRewrite rewriter = ASTRewrite.create(ast);
        for (int i = classHierarchy.size() - 1; i > 0; i--) {
            ClassInfo currentClassInfo = classHierarchy.get(i);
            String className = new File(currentClassInfo.filePath).getName().replace(".java", "");

            // Collect methods to move from the current class
            List<MethodDeclaration> methodsToMove = new ArrayList<>();
            //                if (containsSuperCall(method)) {
            //                }
            methodsToMove.addAll(Arrays.asList(currentClassInfo.classType.getMethods()));

            for (MethodDeclaration method : methodsToMove) {
                // Rename the method
                String newMethodName = method.getName().getIdentifier() + StringUtils.capitalize(className);

                // Create a copy of the method with the new name
                MethodDeclaration copiedMethod = (MethodDeclaration) ASTNode.copySubtree(ast, method);
                copiedMethod.setName(ast.newSimpleName(newMethodName));
                removeOverrideAnnotation(rewriter, copiedMethod);

                // Replace super() calls in the copied method
                replaceSuperCalls(rewriter, copiedMethod, newMethodName);

                // Add the copied method to the child class
                ListRewrite listRewrite = rewriter.getListRewrite(childClassInfo.classType, TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
                listRewrite.insertLast(copiedMethod, null);
            }
        }

        // Remove the `extends ParentClass` declaration from the child class
//        if (i == 1) { // Only for the direct child of the top-most parent
        rewriter.set(childClassInfo.classType, TypeDeclaration.SUPERCLASS_TYPE_PROPERTY, null, null);
//        }

        for (MethodDeclaration method : childClassInfo.classType.getMethods()) {
            removeOverrideAnnotation(rewriter, method);
        }

        // Write the refactored child class back to the disk
        writeJavaFile(childClassInfo.filePath, childClassInfo.compilationUnit, rewriter);
    }

    private static void removeOverrideAnnotation(ASTRewrite rewriter, MethodDeclaration copiedMethod) {
        // Remove the specified annotation
        ListRewrite listRewrite = rewriter.getListRewrite(copiedMethod, MethodDeclaration.MODIFIERS2_PROPERTY);
        List<IExtendedModifier> modifiers = copiedMethod.modifiers();

        for (IExtendedModifier modifier : modifiers) {
            if (modifier.isAnnotation()) {
                Annotation annotation = (Annotation) modifier;
                if (annotation.getTypeName().getFullyQualifiedName().equals("Override")) {
                    listRewrite.remove(annotation, null); // Remove the annotation
                }
            }
        }
    }

    private static CompilationUnit parseJavaFile(String filePath) throws IOException {
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setSource(readFile(filePath).toCharArray());
        parser.setResolveBindings(true);
        return (CompilationUnit) parser.createAST(null);
    }

    private static String readFile(String filePath) throws IOException {
        FileReader reader = new FileReader(filePath);
        StringBuilder content = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        return content.toString();
    }

    private static void writeJavaFile(String filePath, CompilationUnit cu, ASTRewrite rewriter) throws IOException {
        Document document = new Document(readFile(filePath));
        TextEdit edits = rewriter.rewriteAST(document, null);
        try {
            edits.apply(document);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Write the updated source code back to the file
        FileWriter writer = new FileWriter(new File(filePath.replace(".java", "New.java")));
        writer.write(document.get());
        writer.close();
    }

    private static String findClassFile(List<Path> pathList, String className) {
        // Logic to dynamically locate the class file
        // For simplicity, assume the class file is in the same directory
        for (Path fileName : pathList) {
            if (fileName.toFile().getName().endsWith(className + ".java")) {
                return fileName.toFile().getAbsolutePath();
            }
        }
//        String classFilePath = "src/" + className + ".java";
//        File classFile = new File(classFilePath);
//        return classFile.exists() ? classFilePath : null;
        return null;
    }

    private static String getParentClassName(TypeDeclaration classType) {
        if (classType.getSuperclassType() != null) {
            return classType.getSuperclassType().toString();
        }
        return null;
    }

    private static boolean containsSuperCall(MethodDeclaration method) {
        final boolean[] hasSuperCall = {false};
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                hasSuperCall[0] = true;
                return false; // No need to visit further
            }
        });
        return hasSuperCall[0];
    }

    private static void replaceSuperCalls(ASTRewrite rewriter, MethodDeclaration method, String newMethodName) {
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                AST ast = method.getAST();
                MethodInvocation newInvocation = ast.newMethodInvocation();
                newInvocation.setName(ast.newSimpleName(newMethodName));
                rewriter.replace(node, newInvocation, null);
                return false;
            }
        });
    }

    static class ClassInfo {
        String filePath;
        CompilationUnit compilationUnit;
        TypeDeclaration classType;

        ClassInfo(String filePath, CompilationUnit compilationUnit, TypeDeclaration classType) {
            this.filePath = filePath;
            this.compilationUnit = compilationUnit;
            this.classType = classType;
        }
    }
}