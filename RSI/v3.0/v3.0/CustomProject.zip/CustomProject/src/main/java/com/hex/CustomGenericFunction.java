package com.hex;

import com.hex.svcloader.GenericFunction;

public class CustomGenericFunction implements GenericFunction {
    @Override
    public void execute() {
        System.out.println("Executing CustomGenericFunction");
    }
}
