package com.jpmc.rsi.model;

import com.hex.amaze.engine.core.service.ServiceDependencyImageGenerationService;
import com.hex.amaze.engine.core.util.ObjectHolder;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class XMLToPojoFr {

	private static final Logger logger = LogManager.getLogger(XMLToPojoFr.class);

	/*
	 * public static void main(String args[]) throws Exception { try {
	 * 
	 * File file = new
	 * File("C:\\Users\\1000020564\\Downloads\\Fr\\processFlow.xml"); JAXBContext
	 * context = JAXBContext.newInstance(ServiceDataDescriptor.class); Unmarshaller
	 * unmarshaller = context.createUnmarshaller(); ServiceDataDescriptor account =
	 * (ServiceDataDescriptor) unmarshaller.unmarshal(file); Map<String, String>
	 * frXmlClassMap = new HashedMap<>();
	 * 
	 * frXmlClassMap.put(account.getValidator(), account.getValidator()); //
	 * frXmlClassMap.put(account.getValidator());
	 * frXmlClassMap.put(account.getProcessFlow().getPdd().get(0).getClassName(),
	 * account.getProcessFlow().getPdd().get(0).getClassName());
	 * frXmlClassMap.put(account.getXmlRequestMapping().getRequestField().get(0).
	 * getFormatter(),
	 * account.getXmlRequestMapping().getRequestField().get(0).getFormatter());
	 * frXmlClassMap.put(account.getProcessFlow().getPdd().get(1).getUOWProcess().
	 * getMutator(),
	 * account.getProcessFlow().getPdd().get(1).getUOWProcess().getMutator()); }
	 * catch (Exception e) { e.printStackTrace(); } }
	 */

	public void findClassInFrXml(File fileName, Map<String, JpmcModelDto> jpmXmlVsClassMappings) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(ServiceDataDescriptor.class);
			System.setProperty("javax.xml.accessExternalDTD", "all");
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			unmarshaller.unmarshal(fileName);
			jpmXmlVsClassMappings.put(fileName.getAbsolutePath(), new JpmcModelDto());
		} catch (JAXBException e) {
			logger.debug("{} is not a valid file", fileName);
		}
	}

	public void populateXmlData(Map<String, JpmcModelDto> jpmXmlVsClassMappings, ObjectHolder objectHolder,
                                Map targetMap, Long reportID) {
		IdentifyJpmcCode identifyJpmcCode = new IdentifyJpmcCode();
		// JPMC specific code
		try {
			for (Entry<String, JpmcModelDto> entry : jpmXmlVsClassMappings.entrySet()) {
				String xmlFileName = entry.getKey();
				JpmcModelDto jpmcModelDto = new JpmcModelDto();
				Set<String> associatedClasses = identifyJpmcCode.identifyAssociatedClasses(xmlFileName);
				Map<String, Set<String>> parentForAssociatedClassesMap = identifyJpmcCode
						.identifyParentOfAssociatedClasses(associatedClasses, objectHolder);
				jpmcModelDto.setParentForAssociatedClasses(parentForAssociatedClassesMap);
				jpmcModelDto.setAssociatedClasses(associatedClasses);
				jpmXmlVsClassMappings.put(xmlFileName, jpmcModelDto);
			}

			if (CollectionUtils.isNotEmpty(objectHolder.getCsProjServiceDependencyList())) {
				ServiceDependencyImageGenerationService serviceDependencyImageGenerationService = new ServiceDependencyImageGenerationService();
				// serviceDependencyImageGenerationService.setServiceDependencyList(objectHolder.getCsProjServiceDependencyList());
				String imageName = serviceDependencyImageGenerationService.createGraph(
						objectHolder.getCsProjServiceDependencyList(), reportID, targetMap, objectHolder,
						"csprojDependency");
				if (imageName != null) {
					objectHolder.setCsprojDependencyImgName(imageName);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception on while generate csProj dependency graph" + e.getMessage());
		}
	}

	public void generateMicroServiceJPMC(File fileName, String targetLocation, String className, String packageName, List<Path> pathList, ObjectHolder objectHolder) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(ServiceDataDescriptor.class);
			System.setProperty("javax.xml.accessExternalDTD", "all");

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			jaxbUnmarshaller.unmarshal(fileName);
			ServiceDataDescriptor parent = (ServiceDataDescriptor) jaxbUnmarshaller.unmarshal(fileName);		
			SimpleTemplateEngine engine = new SimpleTemplateEngine();
			// Define methods and their conditions
			if (parent != null) {
				String newFilePath = targetLocation + File.separator + className + ".java";
				engine.generateClass(className, parent, newFilePath, packageName,objectHolder);
			}
		} catch (IOException | JAXBException e) {
			logger.debug("{} is not a valid file", fileName);
		}
	}
}