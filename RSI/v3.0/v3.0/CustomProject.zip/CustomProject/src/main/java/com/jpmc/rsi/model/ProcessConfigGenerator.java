package com.jpmc.rsi.model;

import com.hex.amaze.dbreplatforming.core.util.FunctionalUtils;
import com.hex.amaze.engine.core.dto.ReportGenerationDataDTO;
import com.hex.amaze.engine.core.util.AmazeFileUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class ProcessConfigGenerator {
    private static final Logger logger = LogManager.getLogger(ProcessConfigGenerator.class);

    public synchronized void generate(List<ProcessDataDescriptor> processDataDescriptorList, String packageName) {
        try {
            StringBuilder classBuilder = new StringBuilder();
            // Define the package
            packageName = packageName + ".config";
            classBuilder.append("\tpackage ").append(packageName).append(";").append(System.lineSeparator()).append(System.lineSeparator());

            // Define the imports
            classBuilder.append("\timport com.chase.rsi.config.model.service.Fld;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.config.model.service.ForkThreads;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.config.model.service.ProcessDataDescriptor;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.config.model.service.UOWProcess;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.config.model.service.UOWRequestMapping;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.config.model.service.UOWResponseMapping;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.config.model.service.WaitThreads;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.request.ExpressOnlineProfileMutator;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.request.ListUserMutator;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.rsi.validator.ExpressOnlineProfileServiceValidator;").append(System.lineSeparator());
            classBuilder.append("\timport com.chase.si.datahelpers.managers.ProcessDescriptor;").append(System.lineSeparator());
            classBuilder.append("\timport jakarta.annotation.PostConstruct;").append(System.lineSeparator());
            classBuilder.append("\timport org.springframework.beans.factory.annotation.Autowired;").append(System.lineSeparator());
            classBuilder.append("\timport org.springframework.context.annotation.Bean;").append(System.lineSeparator());
            classBuilder.append("\timport org.springframework.context.annotation.Configuration;").append(System.lineSeparator()).append(System.lineSeparator());

            classBuilder.append("\t@Configuration").append(System.lineSeparator());
            classBuilder.append("\tpublic class ProcessConfiguration {").append(System.lineSeparator()).append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate com.chase.rsi.service.expressonlineprofile.pfm.AuthenticateLiginIDCheck authenticateLiginIDCheck;").append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate com.chase.rsi.pfm.processes.SoapUOWProcess soapUOWProcess;").append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate com.chase.rsi.customer.pfm.AllSignersProcessedCheck allSignersProcessedCheck;").append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate com.chase.rsi.customer.pfm.NextSignerToProcess nextSignerToProcess;").append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate ExpressOnlineProfileServiceValidator defaultFormatValidator;").append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate ExpressOnlineProfileMutator expressOnlineProfileMutator;").append(System.lineSeparator());
            classBuilder.append("\t@Autowired").append(System.lineSeparator());
            classBuilder.append("\tprivate ListUserMutator listUserMutator;").append(System.lineSeparator()).append(System.lineSeparator());

            // Define the methods
            BigInteger step = null;
            String name = null;
            String className = null;
            BigInteger version = null;
            String description = null;
            BigInteger minorVersion = null;
            String mutator = null;
            BigInteger errorBehaviour = null;
            String messageLogger = null;
            for (ProcessDataDescriptor processDataDescriptor : processDataDescriptorList) {
                step = processDataDescriptor.getStep();
                name = processDataDescriptor.getName();
                className = processDataDescriptor.getClassName();
                version = processDataDescriptor.getVersion();
                description = processDataDescriptor.getDescription();
                classBuilder.append("\t@Bean(name=\"" + step + "\")").append(System.lineSeparator());
                classBuilder.append("\tpublic ProcessDataDescriptor step" + step + "() { ").append(System.lineSeparator());
                classBuilder.append("\t\tProcessDataDescriptor processDataDescriptor = new ProcessDataDescriptor();").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setStep(\"" + step + "\");").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setName(\"" + name + "\");").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setClassName(\"" + className + "\");").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setVersion(\"" + version + "\");").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setDescription(\"" + description + "\");").append(System.lineSeparator());
                classBuilder.append("\t\tForkThreads forkThreads = new ForkThreads();").append(System.lineSeparator());
                classBuilder.append("\t\tWaitThreads waitThreads = new WaitThreads();").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setForkThreads(forkThreads);").append(System.lineSeparator());
                classBuilder.append("\t\tprocessDataDescriptor.setWaitThreads(waitThreads);").append(System.lineSeparator());
                UOWProcess uOWProcess = processDataDescriptor.getUOWProcess();
                if (uOWProcess != null) {
                    name = uOWProcess.getUowName();
                    version = uOWProcess.getVersion();
                    minorVersion = uOWProcess.getMinorVersion();
                    mutator = uOWProcess.getMutator();
                    errorBehaviour = uOWProcess.getErrorBehavior();
                    messageLogger = uOWProcess.getMessageLogger();
                    classBuilder.append("\t\tUOWProcess uOWProcess = new UOWProcess();").append(System.lineSeparator());
                    classBuilder.append("\t\tuOWProcess.setUoWName(\"" + name + "\");").append(System.lineSeparator());
                    classBuilder.append("\t\tuOWProcess.setVersion(\"" + version + "\");").append(System.lineSeparator());
                    classBuilder.append("\t\tuOWProcess.setMinorVersion(\"" + minorVersion + "\");").append(System.lineSeparator());
                    classBuilder.append("\t\tuOWProcess.setMutator(\"" + mutator + "\");").append(System.lineSeparator());
                    classBuilder.append("\t\tuOWProcess.setErrorBehaviour(\"" + errorBehaviour + "\");").append(System.lineSeparator());
                    classBuilder.append("\t\tuOWProcess.setMessageLogger(\"" + messageLogger + "\");").append(System.lineSeparator());
                    if (uOWProcess.getUOWRequestMapping() != null) {
                        UOWRequestMapping uOWRequestMapping = new UOWRequestMapping();
                        classBuilder.append("\t\tUOWRequestMapping uOWRequestMapping = new UOWRequestMapping();").append(System.lineSeparator());
                        classBuilder.append("\t\tuOWProcess.setUOWRequestMapping(uOWRequestMapping);").append(System.lineSeparator());
                    }
                    if (uOWProcess.getUOWResponseMapping() != null) {
                        UOWResponseMapping uOWResponseMapping = new UOWResponseMapping();
                        classBuilder.append("\t\tUOWRequestMapping uOWResponseMapping = new UOWResponseMapping();").append(System.lineSeparator());
                        classBuilder.append("\t\tuOWProcess.setUOWResponseMapping(uOWResponseMapping);").append(System.lineSeparator());
                    }
                    classBuilder.append("\t\tprocessDataDescriptor.setUOWProcess(uOWProcess);").append(System.lineSeparator());
                }

                classBuilder.append("\t\treturn processDataDescriptor;").append(System.lineSeparator());
                classBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());
            }

            classBuilder.append("\tpostConstruct").append(System.lineSeparator());
            classBuilder.append("\tpublic void setUp(){").append(System.lineSeparator());
            classBuilder.append("\t\t//convert processDataDescriptor to ProcessDescriptor using ProcessflowDataGatherer").append(System.lineSeparator());
            classBuilder.append("\t\t//Add Service definition to ServiceManager").append(System.lineSeparator());
            classBuilder.append("\t}").append(System.lineSeparator());

            // Define class end
            classBuilder.append("}").append(System.lineSeparator());
            String projectPath = AmazeFileUtil.getCurrentDirectory();
            projectPath = projectPath + File.separator + "lib" + File.separator + "JPMC_Temp";
            File tempFile = new File(projectPath);
            if (tempFile.exists())
                tempFile.delete();
            AmazeFileUtil.createDirectory(projectPath);
            projectPath = projectPath + File.separator + "ProcessConfiguration.java";
            Files.write(Paths.get(projectPath), classBuilder.toString().getBytes(StandardCharsets.UTF_8));

        } catch (Exception ex) {
            logger.error(FunctionalUtils.getExceptionStackTrace(ex));
        }
    }

    public synchronized void generateInterceptor(String packageName, String validatorClass, String requestStmtLines, ServiceDataDescriptor parentNode) {

        try {
            String projectPath = AmazeFileUtil.getCurrentDirectory();
            String tempPath = projectPath + File.separator + "lib" + File.separator + "templates" + File.separator + "JPMC" + File.separator + "XMLValidationInterceptor.java";
            Path filePath = Paths.get(tempPath);
            String content = Files.lines(filePath, StandardCharsets.UTF_8)
                    .collect(Collectors.joining(System.lineSeparator()));

            packageName = packageName + ".config";

            // Define the package
            content = StringUtils.replace(content, "$$PACKAGE_NAME$$", packageName);

            String prepareLine = "import " + validatorClass;
            prepareLine = prepareLine + (";") + (System.lineSeparator());
            content = StringUtils.replace(content, "$$IMPORTSTMT$$", prepareLine);

            //Autowire
            String classNameStr = "";
            String validatorClassVar = "";
            classNameStr = validatorClass.contains(".") ? validatorClass.substring(validatorClass.lastIndexOf(".") + 1) : validatorClass;
            validatorClassVar = Character.toLowerCase(classNameStr.charAt(0)) + classNameStr.substring(1);
            StringBuilder annotationsSb = new StringBuilder();
            annotationsSb.append("\t@Autowired").append(System.lineSeparator());
            annotationsSb.append("\tprivate ").append(classNameStr).append(" ").append(validatorClassVar).append(";").append(System.lineSeparator());
            content = StringUtils.replace(content, "$$AUTOWIRED$$", annotationsSb.toString());

            //Request Object setup
            //content = StringUtils.replace(content,"$$RequestSetup$$", requestStmtLines.toString());

            //session prepare
            //String sessionContent=prepareSessionObject(parentNode);
            //content = StringUtils.replace(content,"$$SESSIONPREMETHOD$$", sessionContent);

            content = StringUtils.replace(content, "$$SERVICE_VALIDATE$$", validatorClassVar);

            //session prepare
            String sessionContent = prepareSessionObject(parentNode);
            content = StringUtils.replace(content, "$$SESSIONPREMETHOD$$", sessionContent);

            projectPath = projectPath + File.separator + "lib" + File.separator + "JPMC_Temp";
            AmazeFileUtil.createDirectory(projectPath);
            projectPath = projectPath + File.separator + "XMLValidationInterceptor.java";
            Files.write(Paths.get(projectPath), content.getBytes(StandardCharsets.UTF_8));
            generateMappingHelper(parentNode, packageName);
        } catch (Exception ex) {
            logger.error(FunctionalUtils.getExceptionStackTrace(ex));
        }
    }

    public synchronized void generateMappingHelper(ServiceDataDescriptor parentNode, String packageName) throws IOException {
        String projectPath = AmazeFileUtil.getCurrentDirectory();
        String tempPath = projectPath + File.separator + "lib" + File.separator + "templates" + File.separator + "JPMC" + File.separator + "MappingHelper.java";
        Path filePath = Paths.get(tempPath);
        String content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));

        packageName = packageName + ".interceptor.util";

        // Define the package
        content = StringUtils.replace(content, "$$PACKAGE_NAME$$", packageName);

        //session prepare
        String sessionContent = prepareSessionObject(parentNode);
        content = StringUtils.replace(content, "$$SETSESSION$$", sessionContent);

        String responseContent = buildResponse(parentNode);
        content = StringUtils.replace(content, "$$BUILD_RESPONSE$$", responseContent);
        String requestClass=parentNode.getName();
        String responseClass= requestClass.replace("Request", "Response");
        String classVar= Character.toLowerCase(responseClass.charAt(0)) + responseClass.substring(1);
        responseContent=responseClass +" "+classVar+"= new "+responseClass+"();";
        content = StringUtils.replace(content, "$$RESPONSE_ENTRY$$", responseContent);
        projectPath = projectPath + File.separator + "lib" + File.separator + "JPMC_Temp" + File.separator + "util";
        AmazeFileUtil.createDirectory(projectPath);
        projectPath = projectPath + File.separator + "MappingHelper.java";
        Files.write(Paths.get(projectPath), content.getBytes(StandardCharsets.UTF_8));
    }

    public synchronized void generateSoapProcessClass(File targetPath, Map<String, Map<String, String>> soapPropertyMap, ReportGenerationDataDTO reportGenerationDataDTO) throws IOException {
        String projectPath = AmazeFileUtil.getCurrentDirectory();
        File sourceFile = new File(projectPath + File.separator + "lib" + File.separator + "templates" + File.separator + "JPMC" + File.separator + "SoapUOWProcess.java");
        Path filePath = sourceFile.toPath();
        String content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));
        String prepareData = "";
        String classNameVar = "";
        String className = "";
        StringBuilder varDeclarationSB = new StringBuilder();
        StringBuilder methodContentSB = new StringBuilder();
        StringBuilder constructSb = new StringBuilder();
        StringBuilder thisSb = new StringBuilder();
        List<String> portTypeList = new ArrayList<>();
        //List<String> rpcMethodList = new ArrayList<>();
        String soapRequest="";
        int index = 0;
        for (Map.Entry<String, Map<String, String>> soapMap : soapPropertyMap.entrySet()) {
            String step = soapMap.getKey();
            String portType = "";
            String rpcMethod = "";            
            for (Map.Entry<String, String> soapProps : soapMap.getValue().entrySet()) {
                if (soapProps.getKey().equals("LOCAL_PART")) {
                    className = soapProps.getValue();
                    prepareData = Character.toLowerCase(className.charAt(0)) + className.substring(1);
                    portTypeList.add(prepareData);
                    classNameVar = prepareData;
                    //varDeclarationSB.append("\tprivate final " + className + " " + classNameVar + ";").append(System.lineSeparator());
                    //constructSb.append("@Autowired @Lazy @Qualifier(\"$$STUB_FACTORY$$\") " + className + " " + classNameVar + ",").append(System.lineSeparator());
                    thisSb.append("\t\tthis." + classNameVar + " = " + classNameVar + ";").append(System.lineSeparator());
                }
                if (soapProps.getKey().equals("STUB_FACTORY")) {
                    prepareData = soapProps.getValue();
                    if (prepareData.contains("#"))
                        prepareData = prepareData.substring(prepareData.indexOf("#") + 1);
                    prepareData = prepareData.replace("get", "");
                    className=prepareData;
                    if(className.contains("Port"))
                    	className=className.substring(0, className.indexOf("Port")+4);
                    className=className+"Type";
                    constructSb.append("@Autowired @Lazy @Qualifier(\""+prepareData+"\") " + className + " " + classNameVar + ",").append(System.lineSeparator());		
                    varDeclarationSB.append("\tprivate final " + className + " " + classNameVar + ";").append(System.lineSeparator());
                    //constructSb.replace(constructSb.indexOf("$$STUB_FACTORY$$"), constructSb.indexOf("$$STUB_FACTORY$$") + 16, prepareData);
                }
                if (soapProps.getKey().equals("RPC_METHOD")) {
                   // rpcMethodList.add(soapProps.getValue());
                    rpcMethod = soapProps.getValue();
                }
                if (soapProps.getKey().equals("RPC_PARAM1")) {
                	soapRequest = soapProps.getValue(); 
                    if(soapRequest.contains("."))
                    	soapRequest=soapRequest.substring(soapRequest.lastIndexOf(".")+1);
                }
            }
            // SOAP Execute Method part
            if (index == 0) {
                methodContentSB.append("\t\tif(step==").append(step).append("){").append(System.lineSeparator());
                methodContentSB.append("\t\t\t"+soapRequest+" soapRequest = new "+soapRequest+"();").append(System.lineSeparator());
                methodContentSB.append("\t\t\tsoapResponse=").append(classNameVar).append(".").append(rpcMethod).append("(soapRequest);").append(System.lineSeparator());
                methodContentSB.append("\t\t}").append(System.lineSeparator());
            } else {
                methodContentSB.append("\t\telse if(step==").append(step).append("){").append(System.lineSeparator());
                methodContentSB.append("\t\t\t"+soapRequest+" soapRequest = new "+soapRequest+"();").append(System.lineSeparator());
                methodContentSB.append("\t\t\tsoapResponse=").append(classNameVar).append(".").append(rpcMethod).append("(soapRequest);").append(System.lineSeparator());
                methodContentSB.append("\t\t}").append(System.lineSeparator());
            }
            index++;
        }

        String result = constructSb.toString();
        result = result.substring(0, result.lastIndexOf(",")) + " ) {";
        result = result + System.lineSeparator() + thisSb;

        // Define class level variable
        content = StringUtils.replace(content, "$$VAR_DEC$$", varDeclarationSB.toString());
        content = StringUtils.replace(content, "$$CONSTRUCTOR$$", result);
        content = StringUtils.replace(content, "$$STEP_CALL$$", methodContentSB.toString());
        targetPath = new File(targetPath + File.separator + "com" + File.separator + "chase" + File.separator + "process");
        AmazeFileUtil.createDirectory(targetPath.getAbsolutePath());
        targetPath = new File(targetPath + File.separator + "SoapUOWProcess.java");
        Files.write(targetPath.toPath(), content.getBytes(StandardCharsets.UTF_8));

        // SoapUOWProcessUtil class generation
        sourceFile = new File(projectPath + File.separator + "lib" + File.separator + "templates" + File.separator + "JPMC" + File.separator + "SoapUOWProcessUtil.java");
        filePath = sourceFile.toPath();
        content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));

        targetPath = new File(targetPath.getParentFile().getAbsolutePath() + File.separator + "SoapUOWProcessUtil.java");
        Files.write(targetPath.toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    public synchronized void generateSoapProcessClass(File targetPath, List<Map<String, String>> soapMapList, List<String> soapUOWProcessStepList) throws IOException {
        String projectPath = AmazeFileUtil.getCurrentDirectory();
        File sourceFile = new File(projectPath + File.separator + "lib" + File.separator + "templates" + File.separator + "JPMC" + File.separator + "SoapUOWProcess.java");
        Path filePath = sourceFile.toPath();
        String content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));
        String prepareData = "";
        String className = "";
        StringBuilder sb = new StringBuilder();
        StringBuilder constructSb = new StringBuilder();
        StringBuilder thisSb = new StringBuilder();
        List<String> portTypeList = new ArrayList<>();
        List<String> rpcMethodList = new ArrayList<>();
        for (Map<String, String> soapMap : soapMapList) {
            for (Map.Entry<String, String> soapProps : soapMap.entrySet()) {
                if (soapProps.getKey().equals("LOCAL_PART")) {
                    className = soapProps.getValue();
                    prepareData = Character.toLowerCase(className.charAt(0)) + className.substring(1);
                    portTypeList.add(prepareData);
                    sb.append("\tprivate final " + className + " " + prepareData + ";").append(System.lineSeparator());

                    constructSb.append("\t\t     @Autowired @Lazy @Qualifier(\"$$STUB_FACTORY$$\") " + className + " " + prepareData + ",").append(System.lineSeparator());

                    thisSb.append("\t\tthis." + prepareData + " = " + prepareData + ";").append(System.lineSeparator());


                }
                if (soapProps.getKey().equals("STUB_FACTORY")) {
                    prepareData = soapProps.getValue();
                    if (prepareData.contains("#"))
                        prepareData = prepareData.substring(prepareData.indexOf("#") + 1);
                    prepareData = prepareData.replace("get", "");
                    constructSb.replace(constructSb.indexOf("$$STUB_FACTORY$$"), constructSb.indexOf("$$STUB_FACTORY$$") + 16, prepareData);
                }
                if (soapProps.getKey().equals("RPC_METHOD"))
                    rpcMethodList.add(soapProps.getValue());
            }
        }

        String result = constructSb.toString();
        result = result.substring(0, result.lastIndexOf(",")) + " ) {";
        result = result + System.lineSeparator() + thisSb;

        // Define class level variable
        content = StringUtils.replace(content, "$$VAR_DEC$$", sb.toString());
        content = StringUtils.replace(content, "$$CONSTRUCTOR$$", result);
        sb = new StringBuilder();
        if (soapUOWProcessStepList != null && !soapUOWProcessStepList.isEmpty()) {
            int i = 0;
            logger.debug("soapUOWProcessStepList - {}, {}, {}", soapUOWProcessStepList, portTypeList, rpcMethodList);
            for (String step : soapUOWProcessStepList) {
                String portType = !portTypeList.isEmpty() && i < portTypeList.size() ? portTypeList.get(i) : "";
                String rpcMethod = !rpcMethodList.isEmpty() && i < rpcMethodList.size() ? rpcMethodList.get(i) : "";
                if (i == 0) {
                    sb.append("\t\tif(step==" + step + "){").append(System.lineSeparator());
                    sb.append("\t\t\tsoapResponse=" + portType + "." + rpcMethod + "(soapRequest);").append(System.lineSeparator());
                    sb.append("\t\t}").append(System.lineSeparator());
                } else {
                    sb.append("\t\telse if(step==" + step + "){").append(System.lineSeparator());
                    sb.append("\t\t\tsoapResponse=" + portType + "." + rpcMethod + "(soapRequest);").append(System.lineSeparator());
                    sb.append("\t\t}").append(System.lineSeparator());
                }
                i++;
            }
        }
        content = StringUtils.replace(content, "$$STEP_CALL$$", sb.toString());
        targetPath = new File(targetPath + File.separator + "com" + File.separator + "chase" + File.separator + "process");
        AmazeFileUtil.createDirectory(targetPath.getAbsolutePath());
        targetPath = new File(targetPath + File.separator + "SoapUOWProcess.java");
        Files.write(targetPath.toPath(), content.getBytes(StandardCharsets.UTF_8));

        // SoapUOWProcessUtil class generation

        sourceFile = new File(projectPath + File.separator + "lib" + File.separator + "templates" + File.separator + "JPMC" + File.separator + "SoapUOWProcessUtil.java");
        filePath = sourceFile.toPath();
        content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));

        targetPath = new File(targetPath.getParentFile().getAbsolutePath() + File.separator + "SoapUOWProcessUtil.java");
        Files.write(targetPath.toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    public synchronized void generateJavaClassFromXml(Map<String, File> jpmcXmlVsSourceClassMap, Map<String, File> serviceMap, Map<String, String> serviceAppMap, File projectFile) {
        try {
            String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
            String libPath = projectFolderPath + File.separator + "lib" + File.separator;
            projectFolderPath = projectFolderPath + File.separator + "output" + File.separator + "MacroServices" + File.separator + projectFile.getName();
            Iterator<String> serviceIterator = serviceMap.keySet().iterator();
            while (serviceIterator.hasNext()) {
                String serviceFolder = null;
                String serviceName = serviceIterator.next();
                if (serviceAppMap.containsKey(serviceName)) {
                    serviceFolder = serviceAppMap.get(serviceName);
                }
                serviceFolder = serviceFolder != null ? serviceFolder : serviceName;
                File directory = null;
                if (serviceFolder != null) {
                    directory = new File(projectFolderPath + File.separator + serviceFolder + File.separator + "src" + File.separator + "main"
                            + File.separator + "java");
                    if (!directory.exists())
                        AmazeFileUtil.createDirectory(directory.getPath());
                }

                File xmlFileInput = jpmcXmlVsSourceClassMap.get(serviceMap.get(serviceName).getAbsolutePath());
                if (xmlFileInput != null && directory != null) {
                    String xsdName = AmazeFileUtil.getProgramName(xmlFileInput) + ".xsd";
                    Process process1 = Runtime.getRuntime().exec("java -jar " + libPath + "trang.jar " + xmlFileInput + " " + xsdName);
                    //Process process1=Runtime.getRuntime().exec("java -jar \""+libPath+"trang.jar\" "+xmlFileInput+" "+xsdName);
                    BufferedReader inStream = new BufferedReader(new InputStreamReader(process1.getErrorStream()));
                    String classPath = directory.getAbsolutePath();
                    Process process2 = Runtime.getRuntime().exec("xjc -p com.chase.rsi.config.model.service -d " + classPath + " " + xsdName);
                    BufferedReader inStream1 = new BufferedReader(new InputStreamReader(process2.getErrorStream()));
                }
            }

        } catch (Exception ex) {
            logger.error(FunctionalUtils.getExceptionStackTrace(ex));
        }
    }

    public synchronized void generateJavaClassFromXml() {
        try {
            String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
            File directory = new File(projectFolderPath);
            String libPath = projectFolderPath + File.separator + "lib" + File.separator;
            File xmlFileInput = new File("D:\\JPMC_POC\\temp\\UOWDataDescriptor.xml");
            if (xmlFileInput != null && directory != null) {
                String xsdName = AmazeFileUtil.getProgramName(xmlFileInput) + ".xsd";
                Process process1 = Runtime.getRuntime().exec("java -jar " + libPath + "trang.jar " + xmlFileInput + " " + xsdName);
                //Process process1=Runtime.getRuntime().exec("java -jar \""+libPath+"trang.jar\" "+xmlFileInput+" "+xsdName);
                BufferedReader inStream = new BufferedReader(new InputStreamReader(process1.getErrorStream()));
                System.out.println("Hi " + inStream.readLine());
                String classPath = directory.getAbsolutePath();
                Process process2 = Runtime.getRuntime().exec("xjc -p com.jpmc.rsi.model.xml -d " + classPath + " " + xsdName);
                BufferedReader inStream1 = new BufferedReader(new InputStreamReader(process2.getErrorStream()));
                System.out.println("Hi11 " + inStream1.readLine());
            }


        } catch (Exception ex) {
            logger.error(FunctionalUtils.getExceptionStackTrace(ex));
        }
    }

    public static void main(String args[]) {
        new ProcessConfigGenerator().generateJavaClassFromXml();
    }

    private String buildResponse(ServiceDataDescriptor parentNode) {
        StringBuilder methodBuilder = new StringBuilder();
        methodBuilder.append("\tprivate List buildServiceResponse() { ").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("List fields = new ArrayList();").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("try{").append(System.lineSeparator());
        XmlResponseMapping xmlResponseMapping = parentNode.getXmlResponseMapping();
        if (xmlResponseMapping != null && xmlResponseMapping.getResponseField() != null) {
            for (ResponseField responseField : xmlResponseMapping.getResponseField()) {
                String xmlName = responseField.getXmlName();
                String sessionName = responseField.getSessionName();
                methodBuilder.append("\t\t\t").append("fields.add(new XMLMapping(\"" + xmlName + "\", \"" + sessionName + "\", false, false, false));").append(System.lineSeparator());
            }
        }
        methodBuilder.append("\t\t").append("}").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("catch(GathererException e){").append(System.lineSeparator());
        methodBuilder.append("\t\t\t").append("throw new RuntimeException(e);").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("}").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("return fields;").append(System.lineSeparator());
        methodBuilder.append("\t}").append(System.lineSeparator());
        return methodBuilder.toString();
    }

    private String prepareSessionObject(ServiceDataDescriptor parentNode) {
        StringBuilder methodBuilder = new StringBuilder();
        methodBuilder.append("\tpublic RSISession getRsiSession(final RSIRequest rsiRequest, final List<String> errors) { ").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("ServiceRequest request = rsiRequest.getServiceRequest();").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("RSISession rsiSession = new RSISessionImpl();").append(System.lineSeparator());
        methodBuilder.append("\t\t").append("$$FORMATTER_DEC$$").append(System.lineSeparator());
        String requestStr = parentNode.getName();
        String requestVar = Character.toLowerCase(requestStr.charAt(0)) + requestStr.substring(1);
        String prepareLine = requestStr + "  " + requestVar + " = ( " + requestStr + ") rsiRequest.getServiceRequest();";
        methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
        prepareLine = "rsiSession.setRSIRequest(rsiRequest);";
        methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
        prepareLine = "rsiSession.setServiceName(\"" + requestStr + "\");";
        methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
        String version = parentNode.getVersion().toString();
        prepareLine = "rsiSession.setServiceVersion(\"" + version + "\");";
        methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
        XmlRequestMapping xmlRequestMapping = parentNode.getXmlRequestMapping();
        List<RequestField> requestFields = xmlRequestMapping.getRequestField();
        String xmlName = "";
        String sessionName = "";
        String prepareWord = "";
        String collectionClassVar = "";
        String formatter = "";
        String formatterVar = "";
        Set<String> ifCheckSet = new HashSet<>();
        if (!requestFields.isEmpty()) {
            for (RequestField requestField : requestFields) {
                xmlName = requestField.getXmlName();
                sessionName = requestField.getSessionName();
                String length = requestField.getLength();
                formatter = requestField.getFormatter();
                if (formatter.contains("."))
                    formatterVar = formatter.substring(formatter.lastIndexOf(".") + 1);
                formatterVar = Character.toLowerCase(formatterVar.charAt(0)) + formatterVar.substring(1);
                if(xmlName.endsWith("*"))
                	continue;
                if (xmlName.contains(".") && xmlName.contains("*")) {
                    String attribute = "";
                    String className = "";
                    String collectionClass = xmlName.substring(0, xmlName.indexOf("*"));
                    String getClass = requestVar + ".get" + collectionClass + "()";
                    collectionClassVar = Character.toLowerCase(collectionClass.charAt(0)) + collectionClass.substring(1) + "List";
                    prepareLine = "List<" + collectionClass + "> " + collectionClassVar + " = " + getClass + ";";
                    methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
                    methodBuilder.append("\t\tint index=1;").append(System.lineSeparator());
                    String loopVariableName = collectionClassVar.replace("List", "");
                    prepareLine = "for(" + collectionClass + " " + loopVariableName + ": " + collectionClassVar + ") {";
                    methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());

                    attribute = xmlName.substring(xmlName.lastIndexOf(".") + 1);
                    className = xmlName.substring(0, xmlName.lastIndexOf("."));
                    className = className.substring(className.lastIndexOf(".") + 1);
                    prepareLine = "if(" + loopVariableName + "!=null && ";
                    prepareWord = loopVariableName + ".get" + className + "()!=null){";
                    //prepareWord=var+".get"+prepareWord+"() !=null){";
                    prepareLine = prepareLine + prepareWord;
                    methodBuilder.append("\t\t\t").append(prepareLine).append(System.lineSeparator());
                    prepareLine = "String key = \"" + loopVariableName + "\" + index + \"." + xmlName.substring(xmlName.indexOf(".") + 1) + ".\";";
                    methodBuilder.append("\t\t\t\t").append(prepareLine).append(System.lineSeparator());
                    //prepareWord =xmlName.substring(xmlName.lastIndexOf(".")+1);
                    prepareLine = "String attribute= key + \"" + attribute + "\";";
                    methodBuilder.append("\t\t\t\t").append(prepareLine).append(System.lineSeparator());
                    prepareWord = xmlName.substring(xmlName.indexOf(".") + 1);
                    prepareWord = "get" + prepareWord;
                    prepareWord = prepareWord.replace(".", "().get") + "()";
                    prepareWord = loopVariableName + "." + prepareWord;
                    prepareLine = "rsiSession.put(attribute," + prepareWord + "!=null?String.valueOf(" + prepareWord + "):\"\");";
                    methodBuilder.append("\t\t\t\t").append(prepareLine).append(System.lineSeparator());

                    prepareLine = "addToErrorList(" + formatterVar + ".validate(attribute,rsiSession.get(attribute)," + length + "),errors);";
                    methodBuilder.append("\t\t\t\t").append(prepareLine).append(System.lineSeparator());
                    methodBuilder.append("\t\t\t}").append(System.lineSeparator());
                    methodBuilder.append("\t\t}").append(System.lineSeparator());
                } else if (xmlName.contains(".") && !xmlName.contains("*")) {
                    prepareLine = xmlName.substring(0, xmlName.indexOf("."));
                    if (!ifCheckSet.contains(xmlName.substring(0, xmlName.indexOf(".")))) {
                        ifCheckSet.add(xmlName.substring(0, xmlName.indexOf(".")));
                        prepareLine = "if(" + requestVar + ".get" + prepareLine + "()!=null){";
                        methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
                    }
                    prepareWord = xmlName.replace(".", "().get");
                    prepareWord = requestVar + ".get" + prepareWord + "()";
                    prepareLine = "rsiSession.put(\"" + sessionName + "\"," + prepareWord + "!=null?String.valueOf(" + prepareWord + "):\"\");";
                    methodBuilder.append("\t\t\t").append(prepareLine).append(System.lineSeparator());
                    prepareLine = "addToErrorList(" + formatterVar + ".validate(\"" + xmlName + "\",rsiSession.get(\"" + sessionName + "\")," + length + "), errors);";
                    methodBuilder.append("\t\t\t").append(prepareLine).append(System.lineSeparator());
                    methodBuilder.append("\t\t}").append(System.lineSeparator());
                } else {
                    prepareWord = requestVar + ".get" + xmlName + "()";
                    prepareLine = "rsiSession.put(\"" + sessionName + "\", String.valueOf(" + prepareWord + "));";
                    methodBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
                }
            }
        }
        formatter = formatter.contains(".") ? formatter.substring(formatter.lastIndexOf(".") + 1) : formatter;
        prepareWord = formatter + " " + formatterVar + " = new " + formatter + "();";
        methodBuilder.append("\t\treturn rsiSession;").append(System.lineSeparator());
        methodBuilder.append("\t}").append(System.lineSeparator());
        methodBuilder.replace(methodBuilder.indexOf("$$FORMATTER_DEC$$"), methodBuilder.indexOf("$$FORMATTER_DEC$$") + 17, prepareWord);
        return methodBuilder.toString();

    }

}
