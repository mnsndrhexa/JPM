package com.jpmc.rsi.model;

import com.hex.amaze.dbreplatforming.core.util.FunctionalUtils;
import com.hex.amaze.engine.core.ast.JavaClassDetails;
import com.hex.amaze.engine.core.util.AmazeFileUtil;
import com.hex.amaze.engine.core.util.ObjectHolder;
import com.hex.amaze.engine.util.SharedContext;
import com.jpmc.rsi.model.xml.UOWDataDescriptor;
import com.jpmc.rsi.model.xml.UOWHelpers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IdentifyJpmcCode {
	private static final Logger logger = LogManager.getLogger(IdentifyJpmcCode.class);

	public ServiceDataDescriptor identifyXml(String xmlFileName) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(ServiceDataDescriptor.class);
		System.setProperty("javax.xml.accessExternalDTD", "all");

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		Object object = jaxbUnmarshaller.unmarshal(new File(xmlFileName));
		ServiceDataDescriptor parent = (ServiceDataDescriptor) jaxbUnmarshaller.unmarshal(new File(xmlFileName));
		return parent;
	}

	public Set<String> identifyAssociatedClasses(String xmlFileName) throws JAXBException {
		Set<String> associatedClasses = new HashSet<>();
		ServiceDataDescriptor parent = identifyXml(xmlFileName);
		associatedClasses.add(parent.getValidator());
		List<RequestField> requestFields = parent.getXmlRequestMapping().getRequestField();
		for (RequestField rf : requestFields) {
			associatedClasses.add(rf.getFormatter());
		}
		ProcessFlow processFlow = parent.getProcessFlow();
		List<ProcessDataDescriptor> pddList = processFlow.getProcessDataDescriptor();
		for (ProcessDataDescriptor pdd : pddList) {
			String className = pdd.getClassName();
			if(className.endsWith("SoapUOWProcess")) {
				className="com.chase.process.SoapUOWProcess";
			}
			associatedClasses.add(className);
			if (pdd.getUOWProcess() != null) {
				UOWProcess uowProcess = pdd.getUOWProcess();
				associatedClasses.add(uowProcess.getMutator());
			}
		}
		return associatedClasses;
	}

	public Map<String, Set<String>> identifyParentOfAssociatedClasses(Set<String> associatedClasses,
			ObjectHolder objectHolder) throws JAXBException {

		List<Path> pathList = objectHolder.getPathList();
		Map<String, JavaClassDetails> classDetailsMap = objectHolder.getClassDetailsMap();
		Map<String, Set<String>> mappingMap = new HashMap<>();
		for (String fqcn : associatedClasses) {
			Set<String> parentOfAssociatedClasses = new HashSet<>();
			Map<String, String> parentOfAssociatedClassMap = new HashMap<>();
			identifyParent(pathList, classDetailsMap, parentOfAssociatedClasses, fqcn, parentOfAssociatedClassMap);
			mappingMap.put(fqcn, parentOfAssociatedClasses);
		}
		return mappingMap;
	}

	private void identifyParent(List<Path> pathList, Map<String, JavaClassDetails> classDetailsMap,
			Set<String> parentOfAssociatedClasses, String className, Map<String, String> parentOfAssociatedClassMap) {
		for (Path path : pathList) {
			String pattern = "";
			if(className.contains("."))
				pattern = className.replace(".", File.separator).concat(".java");
			else
				pattern = File.separator+className +".java";
			File importedFile = path.toFile();
			// Matcher matcher = pattern.matcher(importedFile.getAbsolutePath());
			if (importedFile.getAbsolutePath().contains(pattern)) {
				JavaClassDetails classDetail = classDetailsMap.get(importedFile.getAbsolutePath());
				if (classDetail != null && classDetail.getExtendClassName() != null
						&& !classDetail.getExtendClassName().isEmpty()) {
					identifyParent(pathList, classDetailsMap, parentOfAssociatedClasses,
							classDetail.getExtendClassName(), parentOfAssociatedClassMap);
				}
				if (classDetail != null && classDetail.getInterfaceNames() != null
						&& !classDetail.getInterfaceNames().isEmpty()) {
					for (String iface : classDetail.getInterfaceNames())
						identifyParent(pathList, classDetailsMap, parentOfAssociatedClasses, iface, parentOfAssociatedClassMap);
				}
				parentOfAssociatedClasses.add(importedFile.getAbsolutePath());
			}
		}
	}

	public Map<String, Map<String, String>> identifySoapProperty(String xmlFileName, SharedContext sharedContext, Set<File> filesToBeCopiedToOutput) throws JAXBException, IOException {
		Map<String, String> uowProcessXmlMap = new HashMap<>();
		ServiceDataDescriptor parent = identifyXml(xmlFileName);
		String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
		ProcessFlow processFlow = parent.getProcessFlow();
		List<ProcessDataDescriptor> pddList = processFlow.getProcessDataDescriptor();
		Map<String, Map<String, String>> soapPropertyMap = new HashMap<>();
		for (ProcessDataDescriptor pdd : pddList) {
			String step = String.valueOf(pdd.getStep());
			if (pdd.getUOWProcess() != null) {
				UOWProcess uowProcess = pdd.getUOWProcess();
				String uowXmlName = uowProcess.getUowName() + "-" + uowProcess.getVersion() + "." + uowProcess.getMinorVersion() + ".xml";
				uowProcessXmlMap.put(step, xmlFileName);
				String soapPropertyPrefix = null;
				List<File> fileList = findFiles(Paths.get(projectFolderPath + File.separator + "input"), uowXmlName);

				if (!fileList.isEmpty()) {
					for (File file : fileList) {
						filesToBeCopiedToOutput.add(file);
						soapPropertyPrefix = getSoapPropertyPrefix(file);
					}
				}
				String[] extensions = {".properties"};
				List<File> propertFileList = findFiles(Paths.get(sharedContext.getProjectFile().getAbsolutePath()), extensions);
				if (propertFileList != null && !propertFileList.isEmpty() && soapPropertyPrefix != null && !soapPropertyPrefix.isEmpty()) {
					for (File file : propertFileList) {
						try (InputStream libStream = Files.newInputStream(Paths.get(file.getAbsolutePath()));) {
							Properties properties = new Properties();
							properties.load(libStream);
							Set<Object> keySet = properties.keySet();
							for (Object key : keySet) {
								if (key.toString().trim().contains(soapPropertyPrefix)) {
									filesToBeCopiedToOutput.add(file);
									Map<String, String> soapPropertiesMap = populateSoapDataMap(file, soapPropertyPrefix);
									soapPropertyMap.put(step, soapPropertiesMap);
									for (Map.Entry<String, String> soapProps : soapPropertiesMap.entrySet()) {
										if (soapProps.getKey().equals("WSDL_RESOURCE")) {
											String wsdlName = soapProps.getValue();
											if (wsdlName.contains("/"))
												wsdlName = wsdlName.substring(wsdlName.lastIndexOf("/") + 1);
											if (wsdlName.contains("."))
												wsdlName = wsdlName.substring(0, wsdlName.lastIndexOf("."));
											for (Path path : sharedContext.getPathList()) {
												String fileName = path.toFile().getName();
												if (fileName.contains("."))
													fileName = fileName.substring(0, fileName.indexOf("."));
												if (fileName.contains(wsdlName))
													filesToBeCopiedToOutput.add(path.toFile());
											}
										}
									}
									break;
								}
							}
						}
					}
				}
			}
		}
		logger.debug("SoapProperty - {}", soapPropertyMap);
		return soapPropertyMap;
	}

	public void identifySoapPropertyPrefix(SharedContext sharedContext) throws IOException {
		String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
		Map<String, String> soapPropertyPrefixMap = new HashMap<>();
		List<File> filesToBeCopiedToOutput = new ArrayList<>();
		Map<String, Map<String, String>> uowProcessXmlMap = sharedContext.getObjectHolder().getUowProcessXmlMap();
//        String serviceFileName = serviceFile.getName().replace(".java", "");
		if (!uowProcessXmlMap.isEmpty()) {
			String soapPropertyPrefix = null;
			for (Map.Entry<String, Map<String, String>> uowProcess : uowProcessXmlMap.entrySet()) {
				String className = uowProcess.getKey();
				Map<String, String> uowProcessXmlSet = uowProcessXmlMap.get(className);

				if (!uowProcessXmlSet.isEmpty()) {
					for (Map.Entry<String, String> uow : uowProcessXmlSet.entrySet()) {
						List<File> fileList = findFiles(Paths.get(projectFolderPath + File.separator + "input"), uow.getValue());

						if (!fileList.isEmpty()) {
							for (File file : fileList) {
//                            File destination = new File(resourceTargetDir.getAbsolutePath() + File.separator + file.getName());
//                            Files.copy(file.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
								filesToBeCopiedToOutput.add(file);
								soapPropertyPrefix = getSoapPropertyPrefix(file);
								logger.debug("SoapPropertyPrefix {}", soapPropertyPrefix);
								if (soapPropertyPrefix != null && !soapPropertyPrefix.isEmpty()) {
									soapPropertyPrefixMap.put(uowProcess.getKey(), soapPropertyPrefix);
								}
							}
						}
					}
				}
			}
		}

		Map<String, Map<String, String>> soapPropertyMap = new HashMap<>();
		if (!soapPropertyPrefixMap.isEmpty()) {
			List<String> soapPrefixList = new ArrayList<>();
			String[] extensions = {".properties"};
			List<File> filteredFiles = new ArrayList<>();
			List<File> propertFileList = findFiles(Paths.get(sharedContext.getProjectFile().getAbsolutePath()), extensions);
			if (propertFileList != null && !propertFileList.isEmpty()) {
				for (File file : propertFileList) {
					try (InputStream libStream = new FileInputStream(file.getAbsolutePath());) {
						Properties properties = new Properties();
						properties.load(libStream);
						for (Map.Entry<String, String> soapProperty : soapPropertyPrefixMap.entrySet()) {
							String soapPropertyPrefix = soapProperty.getValue();
							Set<Object> keySet = properties.keySet();
							for (Object key : keySet) {
								if (key.toString().trim().contains(soapPropertyPrefix)) {
									filteredFiles.add(file);
									if (sharedContext.getSoapPropertyPrefixMap().containsKey(file.getAbsolutePath())) {
										soapPrefixList = sharedContext.getSoapPropertyPrefixMap().get(file.getAbsolutePath());
										soapPrefixList.add(soapPropertyPrefix);
									} else {
										soapPrefixList = new ArrayList<>();
										soapPrefixList.add(soapPropertyPrefix);
									}
									sharedContext.getSoapPropertyPrefixMap().put(file.getAbsolutePath(), soapPrefixList);
									Map<String, String> soapPropertiesMap = populateSoapDataMap(file, soapPropertyPrefix);
									soapPropertyMap.put(soapProperty.getKey(), soapPropertiesMap);
									for (Map.Entry<String, String> soapProps : soapPropertiesMap.entrySet()) {
										if (soapProps.getKey().equals("WSDL_RESOURCE")) {
											String wsdlName = soapProps.getValue();
											if (wsdlName.contains("/"))
												wsdlName = wsdlName.substring(wsdlName.lastIndexOf("/") + 1);
											if (wsdlName.contains("."))
												wsdlName = wsdlName.substring(0, wsdlName.lastIndexOf("."));
											for (Path path : sharedContext.getPathList()) {
												String fileName = path.toFile().getName();
												if (fileName.contains("."))
													fileName = fileName.substring(0, fileName.indexOf("."));
												if (fileName.contains(wsdlName))
													filteredFiles.add(path.toFile());
											}
										}
									}
									break;
								}
							}
						}
					}
				}
			}
			sharedContext.setFilteredFiles(filesToBeCopiedToOutput);
			sharedContext.getFilteredFiles().addAll(filteredFiles);
		}
	}

	private Map<String, String> populateSoapDataMap(File file, String soapPropertyPrefix) {
		Map<String, String> soapMap = new HashMap<>();
		try (InputStream libStream = Files.newInputStream(Paths.get(file.getAbsolutePath()));) {
			Properties properties = new Properties();
			properties.load(libStream);
			Set<Object> keySet = properties.keySet();
			for (Object key : keySet) {
				if (key.toString().trim().contains(soapPropertyPrefix)) {
					if (key.toString().trim().contains("timeout")) {
						soapMap.put("TIME_OUT", properties.get(key).toString());
					}
					if (key.toString().trim().contains("url")) {
						soapMap.put("URL", properties.get(key).toString());
					}
					if (key.toString().trim().contains("stub.factory")) {
						soapMap.put("STUB_FACTORY", properties.get(key).toString());
					}
					if (key.toString().trim().contains("rpc.method")) {
						soapMap.put("RPC_METHOD", properties.get(key).toString());
					}
					if (key.toString().trim().contains("rpc.param1")) {
						soapMap.put("RPC_PARAM1", properties.get(key).toString());
					}
					if (key.toString().trim().contains("wsdlResource")) {
						soapMap.put("WSDL_RESOURCE", properties.get(key).toString());
					}
					if (key.toString().trim().contains("localPart")) {
						soapMap.put("LOCAL_PART", properties.get(key).toString());
					}
				}
			}
		} catch (Exception e) {
			logger.error(FunctionalUtils.getExceptionStackTrace(e));
		}
		return soapMap;
	}

	private String getSoapPropertyPrefix(File file) {
		String soapPropertyPrefix = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(UOWDataDescriptor.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			UOWDataDescriptor uowDataDescriptor = (UOWDataDescriptor) unmarshaller.unmarshal(file);
			UOWHelpers uowHelpers = uowDataDescriptor.getUOWHelpers();
			if (uowHelpers != null)
				soapPropertyPrefix = uowHelpers.getSoapPropertyPrefix();
			String messengerName = uowHelpers.getMessengerName();

		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
		logger.debug("SoapPropertyPrefix {}", soapPropertyPrefix);
		return soapPropertyPrefix;
	}

	private List<File> findFiles(Path path, String[] fileExtensions) throws IOException {
		if (!Files.isDirectory(path)) {
			throw new IllegalArgumentException("Path must be a directory!");
		}
		List<File> fileList;
		try (Stream<Path> walk = Files.walk(path)) {
			fileList = walk
					.filter(p -> !Files.isDirectory(p)&&isEndWith(p.toString().toLowerCase(),fileExtensions))
					.map(Path::toFile)
					.collect(Collectors.toList());
		}
		return fileList;
	}

	private List<File> findFiles(Path path, String fileExtension) throws IOException {
		if (!Files.isDirectory(path)) {
			throw new IllegalArgumentException("Path must be a directory!");
		}
		List<File> fileList;
		try (Stream<Path> walk = Files.walk(path)) {
			fileList = walk
					.filter(p -> !Files.isDirectory(p)&&p.toFile().getAbsolutePath().endsWith(fileExtension))   // not a directory
					.map(Path::toFile)
					.collect(Collectors.toList());
		}
		return fileList;
	}

	private boolean isEndWith(String file, String[] fileExtensions) {
		boolean result = false;
		for (String fileExtension : fileExtensions) {
			if (file.endsWith(fileExtension)) {
				result = true;
				break;
			}
		}
		return result;
	}
}
