package com.jpmc.rsi.model;

import com.jpmc.rsi.model.ProcessFlow;
import com.jpmc.rsi.model.ResultCodes;
import com.jpmc.rsi.model.ServiceDataDescriptor;
import com.jpmc.rsi.model.SimpleTemplateEngine;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class GenerateJavaFromPDD {

    public static void main(String[] args) throws JAXBException, IOException {
        File xmlFile = new File("C:\\Users\\1000022257\\Desktop\\Source\\whole\\MMS\\spring-mms-web\\ExpressOnline.xml");
//        File xmlFile = new File("C:\\Users\\1000022257\\Desktop\\Source\\whole\\MMS\\spring-mms-web\\pom.xml");

        JAXBContext jaxbContext = JAXBContext.newInstance(com.jpmc.rsi.model.ServiceDataDescriptor.class);
        System.setProperty("javax.xml.accessExternalDTD", "all");

        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        Object object = jaxbUnmarshaller.unmarshal(xmlFile);
        com.jpmc.rsi.model.ServiceDataDescriptor parent = (ServiceDataDescriptor) jaxbUnmarshaller.unmarshal(xmlFile);

        //JAXBElement<ExpressProMService> jaxbElement = (JAXBElement<ExpressProMService>) object;

//        if (jaxbElement.getValue() != null)
//            parent = jaxbElement.getValue();

        ProcessFlow processFlow = parent.getProcessFlow();

        com.jpmc.rsi.model.SimpleTemplateEngine engine = new SimpleTemplateEngine();
        // Define methods and their conditions
        Map<String, ResultCodes> methods = new LinkedHashMap<>();
        String generatedClass = "";
        String targetLocation = "C:\\Users\\1000022257\\Desktop\\" + xmlFile.getName().replace(".xml", ".java");
        if (processFlow != null) {
            //generatedClass = engine.generateClass(xmlFile.getName().replace(".xml", ""), parent, targetLocation, "com.hex");
        }
        // Create a FileWriter to write the DOT file
//        try (FileWriter writer = new FileWriter("C:\\Users\\1000022257\\Desktop\\" + xmlFile.getName().replace(".xml", ".java"))) {
//            writer.write(generatedClass);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
    }
}
