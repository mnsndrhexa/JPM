package com.jpmc.rsi.model;

import com.hex.amaze.dbreplatforming.core.util.FunctionalUtils;
import com.hex.amaze.engine.core.util.AmazeFileUtil;
import com.hex.amaze.engine.core.util.ObjectHolder;
import com.jpmc.rsi.model.xml.UOWDataDescriptor;
import com.jpmc.rsi.model.xml.UOWHelpers;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SimpleTemplateEngine {
	private static final Logger logger = LogManager.getLogger(SimpleTemplateEngine.class);
    Set<String> refClassesSet = new HashSet<>();
    Map<String,String> resourceAnnotationVarMap = new HashMap<>();
    Set<String> uowProcessXmlSet=new HashSet<>();
    Map<String, String> uowProcessXmlMap = new HashMap<>();
    List<String> soapUOWProcessStepList = new ArrayList<>();

    public String generateClass(String className, ServiceDataDescriptor parent, String targetLocation, String packageName, ObjectHolder objectHolder) throws IOException {
        String generatedClass = "";
        ProcessFlow processFlow = parent.getProcessFlow();
        if (processFlow != null) {
            String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
            File templateLocation = new File(projectFolderPath + File.separator + "lib\\templates\\JPMC\\java_template.txt");
            List<ProcessDataDescriptor> pddList = processFlow.getProcessDataDescriptor();
            String initiatingMethodName = "step_" + String.valueOf(pddList.get(0).getStep());
            String imports = generateImports();
            String annotations = generateAnnotations(pddList);
            String methods = generateMethods(pddList);
            generateClassFromTemplate(packageName, className, initiatingMethodName, imports, annotations, methods, templateLocation, targetLocation, parent);
//            objectHolder.getUowProcessXmlMap().put(className, uowProcessXmlSet);
            objectHolder.getUowProcessXmlMap().put(className, uowProcessXmlMap);
            objectHolder.setSoapUOWProcessStepList(soapUOWProcessStepList);
            logger.debug("SimpleTemplateEngine - {}, {}", className, soapUOWProcessStepList);
            //ProcessConfigGenerator processConfigGenerator=new ProcessConfigGenerator();
            //processConfigGenerator.generate(pddList,packageName);
        }
        return generatedClass;
    }

    public String generateImports() {
        StringBuilder importsBuilder = new StringBuilder();
        importsBuilder.append("import ").append("com.chase.rsi.config.model.uow.*").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.rsi.controller.RSISessionImpl").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.si.controller.api.RSISession").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.si.datahelpers.GathererException").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.si.datahelpers.Mapping").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.si.datahelpers.UOWDataGatherer").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.si.model.repository.*").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("com.chase.si.uow.descriptor.*").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("jakarta.xml.bind.*").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("org.springframework.beans.factory.annotation.Autowired").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("org.springframework.beans.factory.annotation.Value").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("org.springframework.stereotype.Service").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("import org.springframework.core.io.Resource").append(";").append(System.lineSeparator());
        importsBuilder.append("import ").append("import java.io.IOException").append(";").append(System.lineSeparator());
        return importsBuilder.toString();
    }

    public String generateAnnotations(List<ProcessDataDescriptor> pddList) {
        StringBuilder annotationsBuilder = new StringBuilder();
        Set<String> addedClassesSet = new HashSet<>();
        for (ProcessDataDescriptor pdd : pddList) {
            String className = pdd.getClassName();
            if (!addedClassesSet.contains(className)) {
            	if(className.endsWith("SoapUOWProcess"))
            		className="com.chase.process.SoapUOWProcess";
                String variableName = className.substring(className.lastIndexOf(".") + 1);
                variableName = Character.toLowerCase(variableName.charAt(0)) + variableName.substring(1);
                annotationsBuilder.append("\t@Autowired").append(System.lineSeparator());
                annotationsBuilder.append("\tprivate ").append(className).append(" ").append(variableName).append(";").append(System.lineSeparator());
                addedClassesSet.add(className);
            }
        }
        //annotationsBuilder.append("\t@Autowired").append(System.lineSeparator());
       // annotationsBuilder.append("\tprivate ").append("RSIRequest rsiRequest").append(";").append(System.lineSeparator());
        return annotationsBuilder.toString();
    }

    public String generateMethods(List<ProcessDataDescriptor> pddList) {
        StringBuilder methodBuilder = new StringBuilder();
        String variableName = "";
        // Add methods with dynamic if-else conditions
        for (ProcessDataDescriptor pdd : pddList) {
            String methodName = "step_" + String.valueOf(pdd.getStep());
            ResultCodes condition = pdd.getResultCodes();
            String step = String.valueOf(pdd.getStep());
            methodBuilder.append("\tprivate void ").append(methodName).append("(RSISession session, int step) throws ProcessException {").append(System.lineSeparator());
            UOWProcess uOWProcess = pdd.getUOWProcess();
            String className = pdd.getClassName();
            variableName = className.substring(className.lastIndexOf(".") + 1);
            String  classVariableName = Character.toLowerCase(variableName.charAt(0)) + variableName.substring(1);
            String mutatorClass = "";            
            if (uOWProcess != null) {
            	String xmlFileName=uOWProcess.getUowName()+"-"+uOWProcess.getVersion()+"."+uOWProcess.getMinorVersion()+".xml";
            	soapUOWProcessStepList.add(pdd.getStep().toString());
            	uowProcessXmlSet.add(xmlFileName);
                uowProcessXmlMap.put(step, xmlFileName);
                mutatorClass = uOWProcess.getMutator();
                refClassesSet.add(mutatorClass);
                variableName = mutatorClass;
                if (variableName.contains("."))
                    variableName = variableName.substring(variableName.lastIndexOf(".") + 1);
                variableName = Character.toLowerCase(variableName.charAt(0)) + variableName.substring(1);
                //UOWRequestMapping uOWRequestMapping = uOWProcess.getUOWRequestMapping();
                //Fld fld = null; 
                resourceAnnotationVarMap.put("step_"+pdd.getStep()+"_uow_descriptor",xmlFileName);
                methodBuilder.append("\t\tUOWDescriptor uowDescriptor = (UOWDescriptor) parseXmlToInputObject(step_"+pdd.getStep()+"_uow_descriptor"+"); ").append(System.lineSeparator());
                methodBuilder.append("\t\tMapping inputMap = new Mapping(uowDescriptor.getName(),uowDescriptor.getMajorVersion(),uowDescriptor.getMinorVersion());")
                                                                                   .append(System.lineSeparator());
                if(uOWProcess.getUOWRequestMapping()!=null&&uOWProcess.getUOWRequestMapping().getFld()!=null)
                       methodBuilder.append("\t\tinputMap.put(\""+uOWProcess.getUOWRequestMapping().getFld().getXmlName()+"\",\""
                                               +uOWProcess.getUOWRequestMapping().getFld().getSessionName()+"\");").append(System.lineSeparator());
                methodBuilder.append("\t\tMapping outputMap = new Mapping(uowDescriptor.getName(),uowDescriptor.getMajorVersion(),uowDescriptor.getMinorVersion());").append(System.lineSeparator());
                //if(uOWProcess.getUOWResponseMapping()!=null&&uOWProcess.getUOWResponseMapping().getFld()!=null)
               // methodBuilder.append("\t\toutputMap.put("+uOWProcess.getUOWResponseMapping().getFld().getXmlName()+","
                                       // +uOWProcess.getUOWResponseMapping().getFld().getSessionName()+");").append(System.lineSeparator());
                String messengerName=getMessengerName(xmlFileName);
                methodBuilder.append("\t\tString messengerName = \""+messengerName+"\";").append(System.lineSeparator());
                methodBuilder.append("\t\tint  response = "+classVariableName+".execute(session, "+pdd.getStep()+",uowDescriptor,"+variableName+",inputMap,outputMap,messengerName);").append(System.lineSeparator());
                /*if (uOWRequestMapping != null) {
                    methodBuilder.append("\t\tUOWRequest request = new UOWRequest; ").append(System.lineSeparator());
                    fld = uOWRequestMapping.getFld();
                    if (fld != null) {
                        methodBuilder.append("\t\trequest.set(\"" + fld.getXmlName() + ",session.get(\"" + fld.getSessionName() + "\"));").append(System.lineSeparator());
                    }
                    if (variableName.contains("."))
                        variableName = variableName.substring(variableName.lastIndexOf(".") + 1);
                    variableName = Character.toLowerCase(variableName.charAt(0)) + variableName.substring(1);
                    methodBuilder.append("\t\t" + variableName + ".mutateInput(request, session));").append(System.lineSeparator());
                }*/
            }else {            	
            	methodBuilder.append("\t\tint response = ").append(classVariableName).append(".execute(session," + step + ")").append(";").append(System.lineSeparator());
            }
            int index = 0;            
            
           // methodBuilder.append("\t\tint response = ").append(variableName).append(".execute(session," + step + ")").append(";").append(System.lineSeparator());
            for (ResultCode rc : condition.getResultCode()) {
                String conditionExpression = "response == ".concat(String.valueOf(rc.getCode()));
                if (index == 0) {
                    methodBuilder.append("\t\tif (").append(conditionExpression).append(") {").append(System.lineSeparator());
                } else {
                    methodBuilder.append("\t\telse if (").append(conditionExpression).append(") {").append(System.lineSeparator());
                }
                Integer returnCode = rc.getNextStep().intValue();
                if (returnCode != 14)
                    methodBuilder.append("\t\t\t").append("step_" + returnCode).append("(session," + returnCode + ");").append(System.lineSeparator());
                else
                    methodBuilder.append("\t\t\treturn;").append(System.lineSeparator());
                methodBuilder.append("\t\t}").append(System.lineSeparator());
                index++;
            }
            methodBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());
        }
        logger.debug("SimpleTemplateEngine - {}", soapUOWProcessStepList);
        constructXmlParseMethod(methodBuilder);
        return methodBuilder.toString();
    }
    
    private void constructXmlParseMethod(StringBuilder methodBuilder) {
    	methodBuilder.append("\tprivate Object parseXmlToInputObject").append("(Resource resource) {").append(System.lineSeparator());
    	methodBuilder.append("\t\ttry{").append(System.lineSeparator());
    	methodBuilder.append("\t\t\tif(resource.exists()){").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t\tJAXBContext jaxbContext = JAXBContext.newInstance(UOWDataDescriptor.class,"
    			+ "UOWHelpers.class,FixedRequest.class,FixedResponse.class);").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t\tUnmarshaller unmarshaller = jaxbContext.createUnmarshaller();").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t\tUOWDataDescriptor uowDataDescriptor = (UOWDataDescriptor) unmarshaller.unmarshal(resource.getFile());").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t\tUOWDataGatherer gatherer  = new UOWDataGatherer();").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t\tUOWDescriptor descriptor  = gatherer.createUOWDescriptor(uowDataDescriptor,null);").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t\treturn descriptor;").append(System.lineSeparator());
    	methodBuilder.append("\t\t\t}").append(System.lineSeparator());
    	methodBuilder.append("\t\t}catch(JAXBException | IOException | GathererException e){").append(System.lineSeparator());
    	methodBuilder.append("\t\t\tthrow new RuntimeException(e);").append(System.lineSeparator());
    	methodBuilder.append("\t\t}").append(System.lineSeparator());
    	methodBuilder.append("\t\treturn null;").append(System.lineSeparator());
    	methodBuilder.append("\t}").append(System.lineSeparator());
    }

    public void generateClassFromTemplate(String packageName, String className, String initiatingMethodName, String imports, String annotations, String methods, File templateLocation,
                                          String targetLocation, ServiceDataDescriptor parentNode) throws IOException {
        Path filePath = Paths.get(templateLocation.getAbsolutePath());

        String content = Files.lines(filePath, StandardCharsets.UTF_8)
                .collect(Collectors.joining(System.lineSeparator()));

        // Define the package
        content = StringUtils.replace(content, "$PACKAGE_NAME$", packageName);

        // Define the imports
        //content = StringUtils.replace(content,"$IMPORTS$", imports);

        // Define the class template
        StringBuilder classBuilder = new StringBuilder();
        classBuilder.append("/* Created by Amaze */").append(System.lineSeparator());
        classBuilder.append("@Service").append(System.lineSeparator());
        classBuilder.append("public class ").append(className).append(" {").append(System.lineSeparator());
        content = StringUtils.replace(content, "$CLASS_DEF$", classBuilder.toString());

        // Define the annotations
        // content = StringUtils.replace(content, "$ANNOTATIONS$", annotations);

        // Define the initiating method
        classBuilder = new StringBuilder();
        String requestClass = parentNode.getCategory();
        classBuilder.append("\tpublic RSIResponse execute(RSISession session) throws ProcessException{").append(System.lineSeparator());
        //classBuilder.append("\t\t").append("ServiceRequest request = rsiRequest.getServiceRequest();").append(System.lineSeparator());
        //classBuilder.append("\t\t").append("RSISession session = new RSISessionImpl();").append(System.lineSeparator());
        XmlRequestMapping xmlRequestMapping = parentNode.getXmlRequestMapping();
        List<RequestField> requestFields = xmlRequestMapping.getRequestField();
        String xmlName = "";
        String sessionName = "";
        String formatter = "";
        String length = "";
        String prepareLine = "";
        String classNameStr = "";
        String classVar = "";
        StringBuilder annotationsSb = new StringBuilder();
        StringBuilder importStmtSb = new StringBuilder();
        StringBuilder validateSb=new StringBuilder();
        String validatorClass=parentNode.getValidator();
       /* if (CollectionUtils.isNotEmpty(requestFields)) {
           for (RequestField requestField : requestFields) {
                xmlName = requestField.getXmlName();
                sessionName = requestField.getSessionName();
                length = requestField.getLength();
                formatter = requestField.getFormatter();
                //refClassesSet.add(formatter);
                validatorClass=formatter;
                classNameStr = formatter;
                if (classNameStr.contains("."))
                    classNameStr = classNameStr.substring(classNameStr.lastIndexOf(".") + 1);
                classVar = formatFirstLetterLowerCase(classNameStr);
                prepareLine = classVar + ".validate(\"" + sessionName + "\",request.get(\"" + xmlName + "\")," + length + ");";
                validateSb.append("\t\t").append(prepareLine).append(System.lineSeparator());
            }
            formatter = parentNode.getValidator();
            refClassesSet.add(formatter);
            classNameStr = formatter;
            if (classNameStr.contains("."))
                classNameStr = classNameStr.substring(classNameStr.lastIndexOf(".") + 1);
            classVar = formatFirstLetterLowerCase(classNameStr);
            for (RequestField requestField : requestFields) {
                xmlName = requestField.getXmlName();
                sessionName = requestField.getSessionName();
                prepareLine = "session.set(\"" + sessionName + "\",request.get(\"" + xmlName + "\"));";
                classBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
            }
            prepareLine = classVar + ".validate(session);";
            classBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());*/
            for (String classNameLoop : refClassesSet) {
                importStmtSb.append("\timport ").append(classNameLoop).append(";").append(System.lineSeparator());
                if (classNameLoop.contains("."))
                    classNameStr = classNameLoop.substring(classNameLoop.lastIndexOf(".") + 1);
                classVar = formatFirstLetterLowerCase(classNameStr);
                annotationsSb.append("\t@Autowired").append(System.lineSeparator());
                annotationsSb.append("\tprivate ").append(classNameStr).append(" ").append(classVar).append(";").append(System.lineSeparator());
            }
       // }
        String step = initiatingMethodName.replace("step_", "");
        classBuilder.append("\t\t").append(initiatingMethodName).append("(session," + step + ");").append(System.lineSeparator());
        classBuilder.append("\t\t").append("try{").append(System.lineSeparator());
        classBuilder.append("\t\t\t").append("Object response = mappingHelper.format(session);").append(System.lineSeparator());
        classBuilder.append("\t\t\t").append("return mappingHelper.buildRsiResponse(response);").append(System.lineSeparator());
        classBuilder.append("\t\t").append("}catch(Exception ex) {").append(System.lineSeparator());
        classBuilder.append("\t\t\t").append("throw new RuntimeException(ex);").append(System.lineSeparator());
        classBuilder.append("\t\t").append("}").append(System.lineSeparator());
        /*prepareLine = "Response response = new Response();";
        classBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
        XmlResponseMapping xmlResponseMapping = parentNode.getXmlResponseMapping();
        List<ResponseField> responseFields = xmlResponseMapping.getResponseField();
        if (CollectionUtils.isNotEmpty(responseFields)) {
            for (ResponseField responseField : responseFields) {
                xmlName = responseField.getXmlName();
                sessionName = responseField.getSessionName();
                prepareLine = "response.set(\"" + xmlName + "\",session.get(\"" + sessionName + "\"));";
                classBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
            }
        }
        prepareLine = "return response;"; */
       // classBuilder.append("\t\t").append(prepareLine).append(System.lineSeparator());
        classBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());
        content = StringUtils.replace(content, "$INITIATOR_METHOD$", classBuilder.toString());

        // Define the annotations
        for(Map.Entry<String, String> entry : resourceAnnotationVarMap.entrySet()) {
//        	annotationsSb.append("\t@Autowired").append(System.lineSeparator());
        	annotationsSb.append("\t@Value(\"classpath:").append(entry.getValue()).append("\")").append(System.lineSeparator());
        	annotationsSb.append("\tprivate Resource").append(" ").append(entry.getKey()).append(";").append(System.lineSeparator());
        }
        annotationsSb.append("\t@Autowired").append(System.lineSeparator());
    	annotationsSb.append("\tprivate ").append("MappingHelper mappingHelper;").append(System.lineSeparator());
        annotations = annotations + annotationsSb.toString();        
        content = StringUtils.replace(content, "$ANNOTATIONS$", annotations);

        // Define the imports
        importStmtSb.append("\timport ").append(validatorClass).append(";").append(System.lineSeparator());
        importStmtSb.append("\timport com.chase.si.service.exception.ProcessException;").append(System.lineSeparator());
        importStmtSb.append("\timport com.chase.config.interceptor.util.MappingHelper;").append(System.lineSeparator());
        imports = imports + importStmtSb.toString();
        content = StringUtils.replace(content, "$IMPORTS$", imports);

        // Define the child methods from ProcessDataDescriptor
        content = StringUtils.replace(content, "$METHODS$", methods);

        // Write the modified content back to the file
        // Create a FileWriter to write the DOT file
        new File(targetLocation).createNewFile();
        Files.write(Paths.get(targetLocation), content.getBytes(StandardCharsets.UTF_8));
        new ProcessConfigGenerator().generateInterceptor(packageName,validatorClass,validateSb.toString(),parentNode);
    }

    public String generateClass(String packageName, String className, String initiatingMethodName, String imports, String annotations, String methods) {
        StringBuilder classBuilder = new StringBuilder();

        // Define the package
        classBuilder.append("package ").append(packageName).append(";").append(System.lineSeparator()).append(System.lineSeparator());

        // Define the imports
        classBuilder.append(imports).append(System.lineSeparator()).append(System.lineSeparator());

        // Define the class template
        classBuilder.append("@Component").append(System.lineSeparator());
        classBuilder.append("public class ").append(className).append(" {").append(System.lineSeparator()).append(System.lineSeparator());

        // Define the annotations
        classBuilder.append(annotations).append(System.lineSeparator());

        // Define the initiating method
        classBuilder.append("\tpublic void execute() {").append(System.lineSeparator());
        classBuilder.append("\t\t").append(initiatingMethodName).append("();").append(System.lineSeparator());
        classBuilder.append("\t}").append(System.lineSeparator()).append(System.lineSeparator());

        // Define the child methods from ProcessDataDescriptor
        classBuilder.append(methods);

        classBuilder.append("}").append(System.lineSeparator());
        return classBuilder.toString();
    }

    private String getMessengerName(String xmlFileName) {
    	String messengerName="";
    	Set<String> xmlSet=new HashSet<>();
    	xmlSet.add(xmlFileName);
    	try{
    		String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
    		List<File> fileList=AmazeFileUtil.findFiles(Paths.get(projectFolderPath + File.separator + "input"), xmlSet);
    		if(fileList!=null&&!fileList.isEmpty()) 
    			messengerName=getMessengerName(fileList.get(0));
    		
    	}catch(Exception ex) {
    		logger.error(FunctionalUtils.getExceptionStackTrace(ex));
    	}
    	
    	return messengerName;
    }
    
    private String getMessengerName(File file) {
		String messengerName=null;
		try{
			JAXBContext jaxbContext = JAXBContext.newInstance(UOWDataDescriptor.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			UOWDataDescriptor uowDataDescriptor = (UOWDataDescriptor) unmarshaller.unmarshal(file);
			UOWHelpers uowHelpers=uowDataDescriptor.getUOWHelpers();
			if(uowHelpers!=null)
				messengerName=uowHelpers.getMessengerName();
			
			
		}catch(JAXBException  e){
			throw new RuntimeException(e);
		}		
		logger.debug("messengerName {}",messengerName);
	  return messengerName;
	}

    private static String formatFirstLetterLowerCase(String str) {
        if (str.length() > 1) {
            String s1 = str.substring(0, 1).toLowerCase();
            return s1 + str.substring(1);
        }
        return str;
    }

}
