package com.jpmc.rsi.model;

import com.jpmc.rsi.model.ASTClassInfo;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class JavaClassRefactorASTUtil {

    public static boolean containsSuperCall(MethodDeclaration method) {
        final boolean[] hasSuperCall = {false};
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                hasSuperCall[0] = true;
                return false; // No need to visit further
            }
        });
        return hasSuperCall[0];
    }

    public static boolean isFieldReferenced(MethodDeclaration method, FieldDeclaration field) {
        final boolean[] isReferenced = {false};
        field.accept(new ASTVisitor() {
            @Override
            public boolean visit(SimpleName node) {
                if (method.toString().contains(node.getIdentifier())) {
                    isReferenced[0] = true;
                }
                return false;
            }
        });
        return isReferenced[0];
    }

    public static void collectDependentMethodsAndFields(TypeDeclaration parentClass, MethodDeclaration targetMethod, Set<MethodDeclaration> dependentMethods,
                                                        Set<FieldDeclaration> dependentFields, Set<String> childFieldNames, Set<String> childMethodsWithSuperSet) {
        // Collect fields referenced in the target method
        targetMethod.accept(new ASTVisitor() {
            @Override
            public boolean visit(SimpleName node) {
                // Check if the node refers to a field in the parent class
                for (BodyDeclaration body : (List<BodyDeclaration>) parentClass.bodyDeclarations()) {
                    if (body instanceof FieldDeclaration) {
                        FieldDeclaration field = (FieldDeclaration) body;
                        for (Object fragment : field.fragments()) {
                            if (fragment instanceof VariableDeclarationFragment) {
                                VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
//                                if (node.getIdentifier().equals(varFragment.getName().getIdentifier())) {
                                    if (!childFieldNames.contains(varFragment.getName().getIdentifier()))
                                        dependentFields.add(field);
//                                }
                            }
                        }
                    }
                }
                return super.visit(node);
            }

            @Override
            public boolean visit(MethodInvocation node) {
                // Check if the node refers to a method in the parent class
                for (BodyDeclaration body : (List<BodyDeclaration>) parentClass.bodyDeclarations()) {
                    if (body instanceof MethodDeclaration) {
                        MethodDeclaration method = (MethodDeclaration) body;
//                        if (node.getName().getIdentifier().equals(method.getName().getIdentifier())) {
                            if (!dependentMethods.contains(method) && !childMethodsWithSuperSet.contains(method.getName().getFullyQualifiedName()) && !method.isConstructor()) {
                                dependentMethods.add(method);
                                // Recursively collect dependencies for the referenced method
                                collectDependentMethodsAndFields(parentClass, method, dependentMethods, dependentFields, childFieldNames, childMethodsWithSuperSet);
                            }
//                        }
                    }
                }
                return super.visit(node);
            }
        });
    }

    public static void collectDependentMethodsAndFields(TypeDeclaration parentClass, MethodDeclaration targetMethod, Set<MethodDeclaration> dependentMethods,
                                                        Set<FieldDeclaration> dependentFields) {
        // Collect fields referenced in the target method
        targetMethod.accept(new ASTVisitor() {
            @Override
            public boolean visit(SimpleName node) {
                // Check if the node refers to a field in the parent class
                for (BodyDeclaration body : (List<BodyDeclaration>) parentClass.bodyDeclarations()) {
                    if (body instanceof FieldDeclaration) {
                        FieldDeclaration field = (FieldDeclaration) body;
                        for (Object fragment : field.fragments()) {
                            if (fragment instanceof VariableDeclarationFragment) {
                                VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;

                                dependentFields.add(field);

                            }
                        }
                    }
                }
                return super.visit(node);
            }

            @Override
            public boolean visit(MethodInvocation node) {
                for (BodyDeclaration body : (List<BodyDeclaration>) parentClass.bodyDeclarations()) {
                    if (body instanceof MethodDeclaration) {
                        MethodDeclaration method = (MethodDeclaration) body;

                        if ( !method.isConstructor()) {
                            dependentMethods.add(method);
                            // Recursively collect dependencies for the referenced method
                            //collectDependentMethodsAndFields(parentClass, method, dependentMethods, dependentFields);
                        }
//}
                    }
                }
                return super.visit(node);
            }
        });
    }

    public static Set<FieldDeclaration> collectReferencedFields(TypeDeclaration parentClass, List<MethodDeclaration> methods, Set<String> childFieldNames) {
        Set<FieldDeclaration> fieldsToCopy = new HashSet<>();
        for (BodyDeclaration body : (List<BodyDeclaration>) parentClass.bodyDeclarations()) {
            if (body instanceof FieldDeclaration) {
                FieldDeclaration field = (FieldDeclaration) body;
                boolean isFieldAlreadyPresent = false;

                for (Object fragment : field.fragments()) {
                    if (fragment instanceof VariableDeclarationFragment) {
                        VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                        if (childFieldNames.contains(varFragment.getName().getIdentifier())) {
                            isFieldAlreadyPresent = true;
                            break;
                        }
                    }
                }
                if (!isFieldAlreadyPresent) {
                    for (MethodDeclaration method : methods) {
                        if (isFieldReferenced(method, field)) {
                            fieldsToCopy.add(field);
                        }
                    }
                }
            }
        }
        return fieldsToCopy;
    }

    public static Set<BodyDeclaration> resolveDependencies(TypeDeclaration parentClass, MethodDeclaration method) {
        Set<BodyDeclaration> dependencies = new HashSet<>();
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(MethodInvocation node) {
                String methodName = node.getName().getIdentifier();
                for (MethodDeclaration parentMethod : parentClass.getMethods()) {
                    if (parentMethod.getName().getIdentifier().equals(methodName)) {
                        dependencies.add(parentMethod);
                    }
                }
                return true;
            }

            @Override
            public boolean visit(SimpleName node) {
                String name = node.getIdentifier();
                for (FieldDeclaration field : parentClass.getFields()) {
                    String fieldName = field.fragments().get(0).toString();
                    if (fieldName.equals(name)) {
                        dependencies.add(field);
                    }
                }
                return true;
            }
        });
        return dependencies;
    }

    public static void resolveImports(CompilationUnit parentCU, CompilationUnit childCU, ASTRewrite rewriter, List<ASTClassInfo> classHierarchy) {
        List<ImportDeclaration> parentImports = parentCU.imports();
        List<ImportDeclaration> childImports = childCU.imports();

        for (ImportDeclaration parentImport : parentImports) {
            boolean isAlreadyImported = false;
            for (ASTClassInfo classInfo : classHierarchy) {
                String className = new File(classInfo.getFilePath()).getName().replace(".java", "");
                if (parentImport.getName().toString().contains(className)) {
                    isAlreadyImported = true;
                    break;
                }
            }
            for (ImportDeclaration childImport : childImports) {
                if (childImport.getName().getFullyQualifiedName().equals(parentImport.getName().getFullyQualifiedName())) {
                    isAlreadyImported = true;
                    break;
                }
            }
            if (!isAlreadyImported) {
                AST ast = childCU.getAST();
                ImportDeclaration newImport = (ImportDeclaration) ASTNode.copySubtree(ast, parentImport);
                ListRewrite importRewrite = rewriter.getListRewrite(childCU, CompilationUnit.IMPORTS_PROPERTY);
                importRewrite.insertLast(newImport, null);
            }
        }
    }

    public static void replaceSuperCalls(ASTRewrite rewriter, MethodDeclaration method, String newMethodName) {
        method.accept(new ASTVisitor() {
            @Override
            public boolean visit(SuperMethodInvocation node) {
                AST ast = method.getAST();
                MethodInvocation newInvocation = ast.newMethodInvocation();
                newInvocation.setName(ast.newSimpleName(newMethodName));
                // Copy the arguments from the original super method invocation
                for (Object argument : node.arguments()) {
                    Expression copiedArgument = (Expression) ASTNode.copySubtree(ast, (ASTNode) argument);
                    newInvocation.arguments().add(copiedArgument);
                }
                rewriter.replace(node, newInvocation, null);
                return false;
            }
        });
    }

    public static void removeParentImports(CompilationUnit childCU, ASTRewrite rewriter, List<ASTClassInfo> classHierarchy) {
        // Remove the parent imports
        List<ImportDeclaration> childImports = childCU.imports();

        for (ImportDeclaration importDeclaration : childImports) {
            for (ASTClassInfo classInfo : classHierarchy) {
                String className = new File(classInfo.getFilePath()).getName().replace(".java", "");
                if (importDeclaration.getName().toString().contains(className)) {
                    rewriter.remove(importDeclaration, null);
                }
            }
        }
    }

    public static void removeOverrideAnnotation(ASTRewrite rewriter, MethodDeclaration copiedMethod, String annotationName) {
        // Remove the specified annotation
        ListRewrite listRewrite = rewriter.getListRewrite(copiedMethod, MethodDeclaration.MODIFIERS2_PROPERTY);
        List<IExtendedModifier> modifiers = copiedMethod.modifiers();

        for (IExtendedModifier modifier : modifiers) {
            if (modifier.isAnnotation()) {
                Annotation annotation = (Annotation) modifier;
                if (annotation.getTypeName().getFullyQualifiedName().equals(annotationName)) {
                    listRewrite.remove(annotation, null); // Remove the annotation
                }
            }
        }
    }

    public static void copyImplementedInterfaces(TypeDeclaration parentClass, TypeDeclaration childClass, ASTRewrite rewriter) {
        // Collect interfaces implemented by the child class
        Set<String> childInterfaces = new HashSet<>();
        for (Object obj : childClass.superInterfaceTypes()) {
            if (obj instanceof SimpleType) {
                SimpleType interfaceType = (SimpleType) obj;
                childInterfaces.add(interfaceType.getName().getFullyQualifiedName());
            }
        }

        // Collect interfaces implemented by the parent class
        for (Object obj : parentClass.superInterfaceTypes()) {
            if (obj instanceof SimpleType) {
                SimpleType interfaceType = (SimpleType) obj;
                String interfaceName = interfaceType.getName().getFullyQualifiedName();

                // Add the interface to the child class if it's not already implemented
                if (!childInterfaces.contains(interfaceName)) {
                    AST ast = childClass.getAST();
                    SimpleType copiedInterface = (SimpleType) ASTNode.copySubtree(ast, interfaceType);

                    ListRewrite listRewrite = rewriter.getListRewrite(childClass, TypeDeclaration.SUPER_INTERFACE_TYPES_PROPERTY);
                    listRewrite.insertLast(copiedInterface, null);
                }
            }
        }
    }
}
