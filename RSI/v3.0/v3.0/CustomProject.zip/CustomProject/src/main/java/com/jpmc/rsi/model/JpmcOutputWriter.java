package com.jpmc.rsi.model;

import com.hex.amaze.dbreplatforming.core.util.FunctionalUtils;
import com.hex.amaze.engine.core.dto.ReportGenerationDataDTO;
import com.hex.amaze.engine.core.util.*;
import com.hex.amaze.engine.core.util.writer.CloudLiteWriter;
import com.hex.amaze.engine.core.util.writer.ProgramWriter;
import com.hex.amaze.engine.reader.ProgramReader;
import com.hex.amaze.engine.util.SharedContext;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JpmcOutputWriter {

    private static final Logger logger = LogManager.getLogger(JpmcOutputWriter.class);

    public void generateJPMCWithRsiDependency(File serviceFile, File projectFile, String serviceFolder, String packageName, HashMap<String, EachProgram> programMap, HashMap<String, String> sessionStore,
                                              Properties libProperties, List<String> keyList,
                                              EJBMetaData ejbMetaData, ReportGenerationDataDTO reportGenerationDataDTO) throws IOException {
        String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
        String serviceProgramName = AmazeFileUtilRpt.getProgramName(serviceFile);
        Map<String, JpmcModelDto> jpmXmlVsClassMappings = reportGenerationDataDTO.getJpmXmlVsClassMappings();
//        reportGenerationDataDTO.getprogr

        HashMap<String, File> importedFileMap = new HashMap<>();
        for (Map.Entry<String, JpmcModelDto> pair : jpmXmlVsClassMappings.entrySet()) {
            String xmlProgramName = AmazeFileUtilRpt.getProgramName(new File(pair.getKey()));
            if (new File(pair.getValue().getJavaClassForXml()).getName().equalsIgnoreCase(serviceProgramName + ".java") && pair.getValue() != null && pair.getValue().getParentForAssociatedClasses() != null) {
                for (Map.Entry<String, Set<String>> parentClasses : pair.getValue().getParentForAssociatedClasses().entrySet()) {
                    logger.debug("JavaMacroServiceGenerator.generateJPMCWithRsiDependency() parent classess {} ", parentClasses);
                    if (parentClasses.getValue() != null) {
                        for (String depClass : parentClasses.getValue()) {
                            File depFile = new File(depClass);
                            if (depFile != null && depFile.exists())
                                importedFileMap.put(depFile.getPath(), depFile);
                        }
                    }

                }
            }
        }
        if (MapUtils.isNotEmpty(importedFileMap)) {
            String rootPath = projectFile.getPath();
            String servicePath = serviceFile.getPath();
            String currentProjectFolder = StringUtils.remove(servicePath, rootPath + File.separator);
            currentProjectFolder = currentProjectFolder.substring(0, currentProjectFolder.indexOf(File.separator));
            reportGenerationDataDTO.setComponentAnnotationRequired(true);
            new CloudLiteWriter().generateTempFile3(importedFileMap, serviceProgramName, programMap, projectFile, packageName,
                    serviceFolder, sessionStore, libProperties, keyList, ejbMetaData, reportGenerationDataDTO, currentProjectFolder);
        }
        new File(projectFolderPath + AmazeCoreConstants.OUTPUT_FOLDER_STRING + projectFile.getName()
                + File.separator + serviceFolder + File.separator + "Jenkinsfile");
    }

    public void generateJPMCDependency(File projectFile, String serviceFolder, String packageName, File serviceFile, ReportGenerationDataDTO reportGenerationDataDTO) throws IOException {
        String projectFolderPath = AmazeFileUtil.getCurrentDirectory();
        SharedContext sharedContext = SharedContext.getInstance();
        File srcDirectory = new File(projectFolderPath + AmazeCoreConstants.OUTPUT_FOLDER_STRING + projectFile.getName()
                + File.separator + serviceFolder + AmazeCoreConstants.MAIN_SRC_FOLDER_STRING);
        String templateLocation = projectFolderPath + File.separator + "lib" + File.separator + "templates"
                + File.separator + "JPMC";
        String packagePath = "";
        if (packageName != null && !packageName.isEmpty()) {
            packageName = packageName.replace("ejb", "service");
            StringTokenizer packageDirectories = new StringTokenizer(packageName, ".");
            while (packageDirectories.hasMoreTokens()) {
                packagePath = packagePath + File.separator + (String) packageDirectories.nextToken();
            }
        }

        //static folder copy from lib/template
        File staticTemplateFolder = new File(templateLocation + File.separator + "static");
        if (staticTemplateFolder.exists()) {
            File targetFolder = new File(srcDirectory + File.separator + packagePath);
            copyFile(staticTemplateFolder, targetFolder, serviceFolder, packageName);
        }
        //copy Files under resource folder
        File parentFile = serviceFile.getParentFile();
        while (parentFile != null) {
            if (parentFile.getName().endsWith("main"))
                break;
            parentFile = parentFile.getParentFile();
        }
        List<Path> pathList;
        try (Stream<Path> stream = Files.walk(Paths.get(projectFile.getAbsolutePath()))) {
            pathList = stream.map(Path::normalize).filter(Files::isRegularFile)
                    .collect(Collectors.toList());
        }
        File resourceTargetDir = new File(projectFolderPath + AmazeCoreConstants.OUTPUT_FOLDER_STRING + projectFile.getName()
                + File.separator + serviceFolder + AmazeCoreConstants.RESOURCES_FOLDER_STRING);
        if (!resourceTargetDir.exists())
            resourceTargetDir.mkdirs();

        String rsiXmlFile = reportGenerationDataDTO.getSourceClassVsXmlMap().get(serviceFile.getAbsolutePath()).getAbsolutePath();
        JpmcModelDto rsiModelDto = reportGenerationDataDTO.getJpmXmlVsClassMappings().get(rsiXmlFile);

        Set<File> filteredFiles = rsiModelDto.getFilesToBeCopiedToOutput();
        if (!filteredFiles.isEmpty() && resourceTargetDir != null) {
            for (File file : filteredFiles) {
                String fullFilePath = file.getAbsolutePath();
                String relativeFilePath = "";
                int indexOf = fullFilePath.indexOf("main" + File.separator + "resources");
                if (indexOf > -1)
                    relativeFilePath = fullFilePath.substring(indexOf + 15);
                else
                    relativeFilePath = file.getName();
                File destination = new File(resourceTargetDir.getAbsolutePath() + File.separator + relativeFilePath);
                String directory = destination.getAbsolutePath().substring(0, destination.getAbsolutePath().lastIndexOf(File.separator));
                if (!new File(directory).exists())
                    new File(directory).mkdirs();
                Files.copy(file.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        }

//        for (Map.Entry<String, JpmcModelDto> mapping : sharedContext.getJpmXmlVsClassMappings().entrySet()) {
//            String xmlName = mapping.getKey();
//            JpmcModelDto modelDto = mapping.getValue();
        if (rsiModelDto.getJavaClassForXml().equals(serviceFile.getAbsolutePath())) {
            String relativeFilePath = "";
            int indexOf = rsiXmlFile.indexOf("main" + File.separator + "resources");
            if (indexOf > -1)
                relativeFilePath = rsiXmlFile.substring(0, indexOf + 15);
            copyResourceFolder(new File(relativeFilePath), resourceTargetDir);
        }
//        }
//        List<File> resourceFolderList = new ArrayList<>();
//        AmazeFileUtilRpt.getResourceFolders(parentFile, resourceFolderList);
//        for (File file : resourceFolderList) {
//            copyResourceFolder(file, resourceTargetDir);
//		   AmazeFileUtilRpt.copyFile(file, resourceTargetDir);
//        }

        // SoapUOWProcess file copy generateSoapProcessClass
//        new ProcessConfigGenerator().generateSoapProcessClass(srcDirectory, soapMapList, reportGenerationDataDTO.getSoapUOWProcessStepList());
        Map<String, Map<String, String>> soapPropertyMap = rsiModelDto.getSoapPropertyMap();
        new ProcessConfigGenerator().generateSoapProcessClass(srcDirectory, soapPropertyMap, reportGenerationDataDTO);


        // Config Folder under templates
        File configLocation = new File(templateLocation + File.separator + "config");
        File targetConfigLoc = new File(srcDirectory + File.separator + packagePath + File.separator + "config");
        AmazeFileUtil.createDirectory(targetConfigLoc.getAbsolutePath());
        copyFile(configLocation, targetConfigLoc, serviceFolder, packageName);
        copyFile(new File(templateLocation + File.separator + "Dockerfile"), new File(projectFolderPath + AmazeCoreConstants.OUTPUT_FOLDER_STRING + projectFile.getName()
                + File.separator + serviceFolder + File.separator + "Dockerfile"), serviceFolder, packageName);
        copyFile(new File(templateLocation + File.separator + "Jenkinsfile"), new File(projectFolderPath + AmazeCoreConstants.OUTPUT_FOLDER_STRING + projectFile.getName()
                + File.separator + serviceFolder + File.separator + "Jenkinsfile"), serviceFolder, packageName);
    }

    /*
     * This method copies the files from template and replace the keywords with
     * dynamic values in the target file. This method would be moved as a common
     * implementation and once that is done this logic would be moved to common
     * location.
     */
    public void copyFile(File source, File destination, String appName, String packageName) throws IOException {
        if (source.isDirectory()) {
            if (!destination.exists()) {
                destination.mkdir();
            }
            String files[] = source.list();
            if (files != null && files.length > 0) {
                for (String file : files) {
                    File srcFile = new File(source, file);
                    File destFile = new File(destination, file);
                    // Recursive function call
                    copyFile(srcFile, destFile, appName, packageName);
                }
            }
        } else {
            copyAppFilesTotarget(source, destination, appName, packageName);
        }
    }

    private void copyAppFilesTotarget(File sourceFile, File destFile, String appName, String packageName) {
        if (sourceFile.exists()) {
            try (BufferedReader bufferedReader = new ProgramReader().getReader(sourceFile);
                 BufferedWriter reportGen = new ProgramWriter().genTemp(destFile)) {
                String line = "";
                StringBuilder sb = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null) {
                    if (line.contains("$APP_NAME$")) {
                        line = StringUtils.replace(line, "$APP_NAME$", appName);
                    }
                    if (line.contains("$PACKAGE_NAME$")) {
                        line = StringUtils.replace(line, "$PACKAGE_NAME$", packageName);
                    }
                    sb.append(line);
                    sb.append(System.lineSeparator());
                }
                reportGen.write(sb.toString());
            } catch (Exception e) {
                logger.error(FunctionalUtils.getExceptionStackTrace(e));
            }
        }
    }

    public static void copyResourceFolder(File source, File destination) throws IOException {
        if (source.isDirectory() && !source.getName().contains("-INF")) {
            if (!destination.exists()) {
                destination.mkdir();
            }

            String[] files = source.list();
            if (files != null && files.length > 0) {
                for (String file : files) {
                    File srcFile = new File(source, file);
                    File destFile = new File(destination, file);

                    // Recursive function call
                    copyResourceFolder(srcFile, destFile);
                }
            }
        } else {
            Files.copy(source.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
