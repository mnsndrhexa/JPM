package com.hex;

import com.hex.amaze.engine.core.dto.ReportGenerationDataDTO;
import com.hex.amaze.engine.core.serviceloader.GenericCustomizer;
import com.hex.amaze.engine.core.util.AmazeAssessmentCoreCnsts;
import com.hex.amaze.engine.core.util.AmazeFileUtil;
import com.hex.amaze.engine.core.util.EachProgram;
import com.hex.amaze.engine.util.SharedContext;
import com.jpmc.rsi.model.*;
import lombok.SneakyThrows;

import java.io.File;
import java.nio.file.Path;
import java.util.*;

public class JpmcCustomizer implements GenericCustomizer {
    @SneakyThrows
    @Override
    public void read() {
        SharedContext sharedContext = SharedContext.getInstance();
        List<Path> pathList = sharedContext.getPathList();
        Map<String, JpmcModelDto> jpmXmlVsClassMappings = new HashMap<>();
        XMLToPojoFr xmlToPojoFr = new XMLToPojoFr();
        for (Path path : pathList) {
            File fileName = path.toFile();
            if (fileName.getName().contains(".xml")) {
                xmlToPojoFr.findClassInFrXml(fileName, jpmXmlVsClassMappings);
            }
        }
        if (jpmXmlVsClassMappings != null && !jpmXmlVsClassMappings.isEmpty()) {
            String packageName = "com.chase";
            String packageToBeCreated = sharedContext.getProjectFile().getAbsolutePath() + AmazeAssessmentCoreCnsts.MAIN_SRC_FOLDER_STRING + packageName.replace(".", File.separator);
            AmazeFileUtil.createDirectory(packageToBeCreated);
            xmlToPojoFr.populateXmlData(jpmXmlVsClassMappings, sharedContext.getObjectHolder(), null, null);
            for (Map.Entry<String, JpmcModelDto> entry : jpmXmlVsClassMappings.entrySet()) {
                File file = new File(entry.getKey());
                JpmcModelDto dto = entry.getValue();
                String className = file.getName().replace(".xml", "").replace(".", "").replace("-", "");
                String targetLocation = packageToBeCreated + File.separator + className + ".java";
                sharedContext.getSourceClassVsXmlMap().put(targetLocation, file);
                dto.getSourceClassVsXmlMap().putAll(sharedContext.getSourceClassVsXmlMap());
                xmlToPojoFr.generateMicroServiceJPMC(file, packageToBeCreated, className, packageName, pathList, sharedContext.getObjectHolder());
//                new IdentifyJpmcCode().identifySoapPropertyPrefix(sharedContext);
                Set<File> filesToBeCopiedToOutput = new HashSet<>();
                Map<String, Map<String, String>> soapPropertiesMapping = new IdentifyJpmcCode().identifySoapProperty(file.getAbsolutePath(), sharedContext, filesToBeCopiedToOutput);
                for (Map.Entry<String, Set<String>> associatedClass : entry.getValue().getParentForAssociatedClasses().entrySet()) {
                    String associatedClassName = associatedClass.getKey().replace(".", File.separator) + ".java";
                    Set<String> associatedClassPaths = associatedClass.getValue();
                    for (String paths : associatedClassPaths) {
                        if (paths.contains(associatedClassName)) {
//								DenormalizeClass.denormalizeClass(pathList, paths);
                            JavaClassRefactor.denormalizeClass(pathList, paths);
                            break;
                        }
                    }
                }
//                dto.setSoapPropertyPrefixMap(sharedContext.getSoapPropertyPrefixMap());
//                dto.getSoapUOWProcessStepList().addAll(sharedContext.getObjectHolder().getSoapUOWProcessStepList());
                dto.setJavaClassForXml(targetLocation);
                dto.setFilesToBeCopiedToOutput(filesToBeCopiedToOutput);
                dto.setSoapPropertyMap(soapPropertiesMapping);
            }
        }
        sharedContext.getJpmXmlVsClassMappings().putAll(jpmXmlVsClassMappings);
    }

    @Override
    public void write() {
    }

    @SneakyThrows
    @Override
    public void write(String serviceFolder, String packagePathForModel, File serviceFile, HashMap<String, EachProgram> programMap, HashMap<String, String> sessionStore, Properties libProperties, List<String> keyList) {
        JpmcOutputWriter jpmcOutputWriter = new JpmcOutputWriter();
        SharedContext sharedContext = SharedContext.getInstance();
        ReportGenerationDataDTO reportGenerationDataDTO = sharedContext.getReportGenerationDataDTO();
        jpmcOutputWriter.generateJPMCDependency(sharedContext.getProjectFile(), serviceFolder, packagePathForModel, serviceFile,reportGenerationDataDTO);
		jpmcOutputWriter.generateJPMCWithRsiDependency(serviceFile, sharedContext.getProjectFile(), serviceFolder, packagePathForModel, programMap, sessionStore, libProperties, keyList, null, reportGenerationDataDTO);

    }
}
