package com.jpmc.rsi.model;

import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.io.Serializable;
import java.util.*;

//@Getter
//@Setter
//public class JpmcModelDto implements Serializable {
//
//	private static final long serialVersionUID = 1L;
//	private Map<String, Set<String>> parentForAssociatedClasses;
//	private Set<String> associatedClasses;
//	private String javaClassForXml;
//	private Map<String, File> sourceClassVsXmlMap = new HashMap<>();
//	private Map<String,Set<String>> uowProcessXmlMap= new HashMap<>();
//	private Map<String, List<String>> soapPropertyPrefixMap= new HashMap<>();
//	private Map<String,String> soapDataMap=new HashMap<>();
//	private List<String> soapUOWProcessStepList = new ArrayList<>();
//}
