
Note
add redis at rest and transit encryption


Reference
https://aws.amazon.com/blogs/database/managing-amazon-elasticache-with-terraform/
https://github.com/azavea/terraform-aws-redis-elasticache
https://www.terraform.io/docs/providers/aws/r/elasticache_cluster.html


https://github.com/hashicorp/terraform-elasticache-example/blob/master/elasticache.tf
https://github.com/cloudposse/terraform-aws-elasticache-redis/blob/master/main.tf
https://www.terraform.io/docs/providers/aws/r/elasticache_cluster.html
