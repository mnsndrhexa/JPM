﻿namespace Infrastructure.Common
{
    internal class DomainException
    {
    }
}