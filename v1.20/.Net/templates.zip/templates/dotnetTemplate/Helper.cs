﻿/******************************************************************************************************/
// Code Change History  :
// Date Modified        : 13 March 2024. Modified By: Hexaware Technologies                
// Summary of Change    : In Below code, File upgraded to .NET 8
/*******************************************************************************************************/
using CoreWCF.Configuration;
using CoreWCF;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using CoreWCF.Description;
$$USING$$;

namespace $$NAMESPACE$$;
{
	public static class CoreWCFExtensionMethod
	{
		var builder = WebApplication.CreateBuilder(args);

        builder.WebHost.UseIIS();

        // Add CoreWCF services
        builder.Services.AddServiceModelServices();

        // Load configuration from appsettings.development.json
        builder.Configuration.AddJsonFile("appsettings.development.json", optional: true, reloadOnChange: true);

        builder.Services.AddServiceModelMetadata();
        // Add custom service behavior
        builder.Services.AddSingleton<IServiceBehavior, UseRequestHeadersForMetadataAddressBehavior>();

        // Register the interface and Services class
        $$REGISTERSERVICES$$
        var app = builder.Build();

        // *** mexHttpBinding is not supported in .net core.

       // *** However, as the existing WCF project has WSDL files which are published which can be used by clients for creating proxies

       // *** Retaining same BasicHttpBinding with security mode as None. Not modified to Transport. 

       // *** HttpsGetEnabled attribute of servicemetadatabehavior is set to true as it was in existing WCF version

       // *** As no addition/deletion/modification on any service/operation/data contracts, we assume that there should not be any revision required for client proxies

       // Configure CoreWCF services
      app.UseServiceModel(serviceBuilder =>
      {
       // Add and configure each WCF service
       $$CONFIG$$
    
       // Enable HTTPS metadata retrieval
       var serviceMetadataBehavior = app.Services.GetRequiredService<ServiceMetadataBehavior>();
       serviceMetadataBehavior.HttpsGetEnabled = true;
      });

      app.Run();
 
	}
}



