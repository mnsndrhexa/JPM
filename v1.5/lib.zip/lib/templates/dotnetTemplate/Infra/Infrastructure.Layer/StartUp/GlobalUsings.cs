﻿namespace Infrastructure.Common
{
    class GlobalUsings
    {
    }
}
//for .net 6
//global using System.Threading.Tasks;
//global using System;