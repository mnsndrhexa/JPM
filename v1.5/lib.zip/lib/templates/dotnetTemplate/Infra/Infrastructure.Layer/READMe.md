﻿// AMAZE Added library with wrapper class

•	It is a Helper utility library that contains the below helper class.
•	Caching - In memory and Distributed Cache 
•	App Configuration - It will help to retrieve the values from appsetting.json
•	Event Bus - It will help to migrate the queue to the Event bus. 
•	Filter - Authorization Filter, Action filter, etc
•	HTTP Client - Request and Response format, Request builder
•	JSOn - Serialize and Deserialize
•	Startup - Startup helper methods
•	Storage - File storage helper class to import and export files.
