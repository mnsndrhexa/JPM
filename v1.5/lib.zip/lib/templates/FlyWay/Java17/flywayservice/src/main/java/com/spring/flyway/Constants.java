package com.spring.flyway;

public class Constants {
	public static final String HTML_CONT1= "<html<body><h4><b>Failure Reason:</b></h4>" + "\r\r\r" ;
	public static final String HTML_CONT2= "</body><br/><br>\r\n"
	+ "<b>****Please do not attempt to reply to this automated notification****.</b> Thank you. \r\n"
	+ "</html>";
	public static final String CONTENT_TYPE="text/html";
}
