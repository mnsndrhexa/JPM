package com.journaldev.spring.serv;

public interface QuickPaySvc {

    public String getUserName();
}
