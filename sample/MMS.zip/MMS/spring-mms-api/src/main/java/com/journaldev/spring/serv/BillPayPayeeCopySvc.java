package com.journaldev.spring.serv;

public interface BillPayPayeeCopySvc {

    public String getUserName();
}
