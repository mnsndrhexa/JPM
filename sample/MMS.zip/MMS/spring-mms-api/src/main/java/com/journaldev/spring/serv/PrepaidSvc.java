package com.journaldev.spring.serv;

public interface PrepaidSvc {

    public String getUserName();
}
