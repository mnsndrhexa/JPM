package com.journaldev.spring.serv;

public interface PaymentProfileSvc {

    public String getUserName();
}
