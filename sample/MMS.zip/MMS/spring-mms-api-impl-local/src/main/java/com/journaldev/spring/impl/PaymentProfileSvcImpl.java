package com.journaldev.spring.impl;

import com.journaldev.spring.serv.PaymentProfileSvc;

public class PaymentProfileSvcImpl implements PaymentProfileSvc {
    @Override
    public String getUserName() {
        return "";
    }
}
