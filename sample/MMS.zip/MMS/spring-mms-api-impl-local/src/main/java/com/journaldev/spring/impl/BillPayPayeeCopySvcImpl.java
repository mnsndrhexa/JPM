package com.journaldev.spring.impl;

import com.journaldev.spring.serv.BillPayPayeeCopySvc;

public class BillPayPayeeCopySvcImpl implements BillPayPayeeCopySvc {
    @Override
    public String getUserName() {
        return "";
    }
}
