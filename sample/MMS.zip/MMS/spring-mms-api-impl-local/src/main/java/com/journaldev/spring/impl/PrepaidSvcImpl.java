package com.journaldev.spring.impl;

import com.journaldev.spring.serv.PrepaidSvc;

public class PrepaidSvcImpl implements PrepaidSvc {
    @Override
    public String getUserName() {
        return "";
    }
}
