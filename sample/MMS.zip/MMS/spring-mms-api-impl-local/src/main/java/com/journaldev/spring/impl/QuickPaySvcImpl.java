package com.journaldev.spring.impl;

import com.journaldev.spring.serv.QuickPaySvc;

public class QuickPaySvcImpl implements QuickPaySvc {
    @Override
    public String getUserName() {
        return "";
    }
}
