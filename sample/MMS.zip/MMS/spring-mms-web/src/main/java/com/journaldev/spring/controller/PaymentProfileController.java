package com.journaldev.spring.controller;

import com.journaldev.spring.factory.MerchantProfileSvcFactory;
import com.journaldev.spring.factory.PaymentProfileSvcFactory;
import com.journaldev.spring.model.User;
import com.journaldev.spring.serv.DigitalPaymentProfileSvc;
import com.journaldev.spring.serv.MerchantProfileSvc;
import com.journaldev.spring.serv.PaymentProfileSvc;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.inject.Inject;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

@Controller
public class PaymentProfileController {

	private static final PaymentProfileSvc paymentProfileSvc = PaymentProfileSvcFactory.getService(PaymentProfileSvc.class, PaymentProfileSvcFactory.PaymentProfileSvc);

	private static final MerchantProfileSvc merchantProfileSvc = MerchantProfileSvcFactory.getService(MerchantProfileSvc.class, MerchantProfileSvcFactory.MerchantProfileSvc);

	private static final DigitalPaymentProfileSvc digitalPaymentProfileSvc = PaymentProfileSvcFactory
			.getService(DigitalPaymentProfileSvc.class, PaymentProfileSvcFactory.DigitalPaymentProfileSvc);

	@Inject
	User user;
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String user(Locale locale, Model model) {
		System.out.println("Home Page Requested, locale = " + locale);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate);
		String test = paymentProfileSvc.getUserName();
		return "home";
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String user(@Validated User user, Model model) {
		System.out.println("User Page Requested");
		model.addAttribute("userName", user.getUserName());
		String testValue = digitalPaymentProfileSvc.getUserName();
		String merchantValue = merchantProfileSvc.getUserName();
		return "user";
	}
}
