package com.journaldev.spring.constants;

import com.journaldev.spring.model.User;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class ServiceConfig {

    @Bean
    public ProxyFactoryBean paymentQuickPaySettingsSvc() {
        List<String> s = new ArrayList<>();
        s.add("quickpay receivible account_RemoveCacheConcern");
        s.add("QPSettingsPntDBTxConcern");
        s.add("QPSettingsProfileDbTxConcern");
        ProxyFactoryBean pf = new ProxyFactoryBean();
//        pf.setTarget(paymentQuickPaySettingsSvc_Base());
        pf.setInterceptorNames(new String[] {"a", "b"});
        return new ProxyFactoryBean();
    }

    @Bean
    public User user() {
        List<String> s = new ArrayList<>();
        s.add("quickpay receivible account_RemoveCacheConcern");
        User u = new User();
        u.setUsers(s);
        return u;
    }
}
