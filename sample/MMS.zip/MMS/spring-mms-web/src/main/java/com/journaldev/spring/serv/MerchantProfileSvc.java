package com.journaldev.spring.serv;

public interface MerchantProfileSvc {

    public String getUserName();
}
