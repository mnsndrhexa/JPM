package com.journaldev.spring.impl;

import com.journaldev.spring.serv.MerchantProfileSvc;

public class MerchantProfileSvcImpl implements MerchantProfileSvc {
    @Override
    public String getUserName() {
        return "";
    }
}
