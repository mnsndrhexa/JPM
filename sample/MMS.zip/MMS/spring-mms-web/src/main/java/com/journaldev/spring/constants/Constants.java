package com.journaldev.spring.constants;

public class Constants {

    public static final String HOME_SERVICE = "HomeService";
    public static final String USER_SERVICE = "UserService";
}
