package com.journaldev.spring.serv;

public interface DigitalPaymentProfileSvc {

    public String getUserName();
}
