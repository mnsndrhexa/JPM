package com.journaldev.spring.serv;

public interface DigitalBillPayPayeeCopySvc {

    public String getUserName();
}
