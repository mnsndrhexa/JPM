package com.journaldev.spring.impl;

import com.journaldev.spring.serv.DigitalBillPayPayeeCopySvc;

public class DigitalBillPayPayeeCopySvcImpl implements DigitalBillPayPayeeCopySvc {
    @Override
    public String getUserName() {
        return "";
    }
}
