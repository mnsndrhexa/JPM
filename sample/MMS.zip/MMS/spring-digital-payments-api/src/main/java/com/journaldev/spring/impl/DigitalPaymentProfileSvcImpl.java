package com.journaldev.spring.impl;

import com.journaldev.spring.factory.PrepaidSvcFactory;
import com.journaldev.spring.factory.QuickPaySvcFactory;
import com.journaldev.spring.serv.DigitalPaymentProfileSvc;
import com.journaldev.spring.serv.PrepaidSvc;
import com.journaldev.spring.serv.QuickPaySvc;

public class DigitalPaymentProfileSvcImpl implements DigitalPaymentProfileSvc {

    private QuickPaySvc quickPaySvc;

    private static final PrepaidSvc prepaidSvc = PrepaidSvcFactory
            .getService(PrepaidSvc.class, PrepaidSvcFactory.PrepaidSvc);

    public DigitalPaymentProfileSvcImpl() {
        this(QuickPaySvcFactory.getService(
                QuickPaySvc.class, QuickPaySvcFactory.QuickPaySvc
        ));
    }

    public DigitalPaymentProfileSvcImpl(QuickPaySvc service) {
        this.quickPaySvc = service;
    }

    @Override
    public String getUserName() {
        String value = prepaidSvc.getUserName();
        return quickPaySvc.getUserName();
    }
}
