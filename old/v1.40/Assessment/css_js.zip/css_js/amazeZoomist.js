function myZoomfun() {
  timeout = setTimeout(alertFunc, 1000);
}

function alertFunc() {
	
	 const zoomist = new Zoomist('.zoomist-container', {
  // Optional parameters
  maxScale: 4,
  bounds: true,
  // if you need slider
  slider: true,
  // if you need zoomer
  zoomer: true
})
}


function getDbGraphImg(selectObject) {
  var value = selectObject.value; 
 var displayGraphImg = document.getElementById("displayGraphImg");
 displayGraphImg.src = value;
}


